import Link from "next/link";
import { ArrowUpRight, Boxes, Rss, Satellite, Workflow } from "lucide-react";
import { RadarPanel, type RadarItem } from "@/components/radar";
import { ClusterCard, EventCard, StoryCard, type ClusterItem } from "@/components/story";
import { Reveal } from "@/components/reveal";
import {
  CategoryTag,
  DemoBadge,
  EmptyState,
  Pill,
  SectionLabel,
  Transparency,
  clock,
  timeAgo,
} from "@/components/ui";
import {
  AI_DISCLOSURE,
  CATEGORIES,
  DEMO_NOTE,
  FATO_SUBTITLE,
} from "@/lib/site";
import {
  getArticles,
  getDiscussions,
  getEventCluster,
  getInvestigations,
  getLiveEvent,
  getEvents,
} from "@/lib/data";

export const dynamic = "force-dynamic";

export default async function HomePage() {
  const [live, events, featured, investigations, discussions] = await Promise.all([
    getLiveEvent(),
    getEvents(7),
    getArticles({ featured: true, limit: 14 }),
    getInvestigations(3),
    getDiscussions(4),
  ]);

  const principals = events.slice(0, 5);
  const clusters = await Promise.all(principals.map((e) => getEventCluster(e.id)));

  const liveCluster = live ? clusters[principals.findIndex((p) => p.id === live.id)] : undefined;
  const liveLead = liveCluster?.[0]?.article ?? featured[0];

  const radarItems: RadarItem[] = events.map((e) => ({
    id: e.id,
    title: e.title,
    category: e.category,
    importanceScore: e.importanceScore,
    sourcesCount: e.sourcesCount,
    growth: e.growth,
    reach: e.reach,
    velocity: e.velocity,
    updatesCount: e.updatesCount,
    lastUpdate: e.lastUpdate,
  }));

  const principalStories = principals
    .map((e, i) => {
      const row = clusters[i].find((c) => c.article.isFeatured) ?? clusters[i][0];
      return row ? { event: e, article: row.article, cluster: e.sourcesCount } : null;
    })
    .filter(Boolean) as { event: (typeof principals)[number]; article: (typeof featured)[number]; cluster: number }[];

  const secondary = featured.filter(
    (a) => !principalStories.some((p) => p.article.id === a.id) && !principals.some((e) => e.id === a.eventId),
  );

  return (
    <div>
      {/* ---------------------------------------------------- ticker */}
      <div
        className="overflow-hidden border-b border-line"
        style={{ background: "#0d1014" }}
        aria-hidden
      >
        <div className="marquee flex whitespace-nowrap py-2">
          {[0, 1].map((k) => (
            <span key={k} className="flex shrink-0">
              {events.map((e) => (
                <span key={`${k}-${e.id}`} className="flex items-center gap-3 px-5 label" style={{ color: "#f4f1e9" }}>
                  <span className="tnum" style={{ color: "#ffc24b" }}>
                    {e.importanceScore}
                  </span>
                  {e.title}
                  <span style={{ color: "#ff4638" }}>◆</span>
                </span>
              ))}
            </span>
          ))}
        </div>
      </div>

      <div className="px-4 md:px-8">
        <div className="max-w-[1400px] mx-auto">
          {/* ------------------------------------------------ AGORA */}
          <section className="pt-6 md:pt-10">
            <SectionLabel
              n="00"
              right={
                <span className="flex items-center gap-2">
                  <span className="live-dot h-2 w-2 rounded-full inline-block" style={{ background: "var(--wire)" }} />
                  atualizado {live?.lastUpdate ? timeAgo(live.lastUpdate) : "agora"}
                </span>
              }
            >
              AGORA · ACONTECENDO AGORA
            </SectionLabel>

            {live && liveLead ? (
              <div className="grid lg:grid-cols-[1.5fr_1fr] gap-8 lg:gap-12 mt-6">
                <div>
                  <Link href={`/noticia/${liveLead.id}`} className="group block">
                    <div className="relative overflow-hidden bg-sunk aspect-[16/10] lg:aspect-[4/3]">
                      {liveLead.imageUrl ? (
                        <img
                          src={`/${liveLead.imageUrl}`}
                          alt=""
                          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-[1.03]"
                        />
                      ) : (
                        <div className="w-full h-full grid place-items-center label text-muted">SEM IMAGEM</div>
                      )}
                      <div
                        className="absolute inset-x-0 bottom-0 h-1/2"
                        style={{ background: "linear-gradient(to top, rgba(0,0,0,.68), transparent)" }}
                      />
                      <span
                        className="absolute left-0 top-0 label px-3 py-2.5 text-white inline-flex items-center gap-2"
                        style={{ background: "var(--wire)" }}
                      >
                        <span className="live-dot h-2 w-2 rounded-full inline-block bg-white" />
                        ACONTECENDO AGORA
                      </span>
                      <span
                        className="absolute right-0 top-0 label px-2.5 py-2.5"
                        style={{ background: "#0d1014", color: "#f4f1e9" }}
                      >
                        {live.sourcesCount} FONTES
                      </span>
                    </div>

                    <div className="mt-3 flex flex-wrap items-baseline gap-x-5 gap-y-2 border-t border-line pt-3">
                      <span className="label text-muted shrink-0">LEITURA COMPLETA</span>
                      <span className="headline text-[17px] text-ink group-hover:underline-grow">{liveLead.title}</span>
                      <span className="label text-muted ml-auto shrink-0 tnum">
                        {liveLead.source} · {timeAgo(liveLead.publishedAt)}
                      </span>
                    </div>
                  </Link>
                </div>

                <aside className="lg:border-l lg:border-line lg:pl-10">
                  <div className="flex items-center gap-3">
                    <Pill tone="live">🔴 ACONTECENDO AGORA</Pill>
                    <CategoryTag name={live.category.replace("-", " ")} />
                  </div>

                  <h1 className="display-xl mt-4 text-ink">{live.title}</h1>
                  <p className="mt-4 text-ink2 leading-relaxed measure">{live.summary}</p>

                  <dl className="mt-6 grid grid-cols-2 gap-x-6 gap-y-4 border-t border-line pt-5">
                    {[
                      ["CATEGORIA", live.category.replace("-", " ")],
                      ["ÚLTIMA ATUALIZAÇÃO", live.lastUpdate ? `${clock(live.lastUpdate)} · ${timeAgo(live.lastUpdate)}` : "—"],
                      ["FONTES RELACIONADAS", `${live.sourcesCount}`],
                      ["ALCANCE INTERNACIONAL", `${live.reach}%`],
                    ].map(([k, v]) => (
                      <div key={k}>
                        <dt className="label text-muted" style={{ fontSize: 9.5 }}>
                          {k}
                        </dt>
                        <dd className="tnum text-ink mt-1.5" style={{ fontSize: 15 }}>
                          {v}
                        </dd>
                      </div>
                    ))}
                  </dl>

                  <Link
                    href={`/acontecimento/${live.id}`}
                    className="mt-6 inline-flex items-center justify-between gap-4 w-full px-5 py-4 text-white transition-transform duration-200 hover:-translate-y-0.5"
                    style={{ background: "var(--wire)" }}
                  >
                    <span className="label">VER COBERTURA COMPLETA</span>
                    <ArrowUpRight size={16} />
                  </Link>

                  <div className="mt-4">
                    <Transparency note={`${AI_DISCLOSURE} ${live.sourcesCount} fontes distintas foram agrupadas nesta cobertura.`} />
                  </div>
                </aside>
              </div>
            ) : (
              <div className="mt-6">
                <EmptyState
                  eyebrow="SEM ACONTECIMENTO EM DESTAQUE"
                  title="Nada reúne intensidade suficiente agora."
                  hint="O Radar continua monitorando novas publicações. Quando um acontecimento atingir o limiar, ele aparece aqui."
                />
              </div>
            )}
          </section>

          {/* ------------------------------------------------ RADAR */}
          <section id="radar" className="pt-14 md:pt-20">
            <SectionLabel n="02" right="indicador interno · não é medida de verdade">
              RADAR ESON
            </SectionLabel>
            <div className="mt-6">
              {radarItems.length ? (
                <RadarPanel items={radarItems} />
              ) : (
                <EmptyState
                  eyebrow="RADAR"
                  title="Ainda não há sinais suficientes."
                  hint="O índice aparece quando ao menos três fontes independentes cobrem o mesmo acontecimento."
                />
              )}
            </div>
          </section>

          {/* -------------------------------------------- PRINCIPAIS */}
          <section className="pt-14 md:pt-20">
            <SectionLabel n="03" right="sem duplicação do mesmo acontecimento">
              PRINCIPAIS
            </SectionLabel>

            <div className="grid lg:grid-cols-[1.3fr_1fr] gap-8 lg:gap-12 mt-6">
              <div className="space-y-10">
                {principalStories.length ? (
                  principalStories.slice(0, 3).map(({ event, article, cluster }, i) => (
                    <Reveal key={event.id} delay={i * 0.05}>
                      <article>
                        <div className="flex items-center gap-3 mb-3">
                          <span className="label tnum text-muted">{String(i + 1).padStart(2, "0")}</span>
                          <span className="label" style={{ color: "var(--heat)" }}>
                            {event.importanceScore} · RADAR
                          </span>
                          <span className="label text-muted">{event.category.replace("-", " ")}</span>
                        </div>
                        <StoryCard article={article} variant="lead" cluster={cluster} />
                        <div className="mt-5">
                          <ClusterCard
                            event={{
                              id: event.id,
                              title: event.title,
                              summary: event.summary,
                              sourcesCount: event.sourcesCount,
                              category: event.category,
                              lastUpdate: event.lastUpdate,
                            }}
                            items={clusters[principals.findIndex((p) => p.id === event.id)].map((c) => ({
                              id: c.article.id,
                              title: c.article.title,
                              source: c.article.source,
                              domain: c.article.domain,
                            })) as ClusterItem[]}
                          />
                        </div>
                      </article>
                    </Reveal>
                  ))
                ) : (
                  <EmptyState
                    eyebrow="PRINCIPAIS"
                    title="Nenhum acontecimento reúne sinais agora."
                    hint="A seção é preenchida quando o coletor encontra cobertura convergente entre fontes independentes."
                  />
                )}
              </div>

              <aside className="lg:border-l lg:border-line lg:pl-10">
                <div className="label text-muted mb-4">OUTROS ACONTECIMENTOS EM ALTA</div>
                <div>
                  {principals.slice(2, 6).map((e, i) => (
                    <EventCard key={e.id} event={e} rank={i + 4} />
                  ))}
                </div>

                <div className="mt-8 border border-line bg-panel p-4">
                  <div className="label text-muted mb-3">TITULARES RECENTES</div>
                  <div className="space-y-3">
                    {featured.slice(0, 5).map((a) => (
                      <Link key={a.id} href={`/noticia/${a.id}`} className="group block">
                        <div className="flex gap-3 items-baseline">
                          <span className="tnum text-muted text-xs">{clock(a.publishedAt)}</span>
                          <span className="text-sm text-ink2 group-hover:text-ink transition-colors leading-snug">
                            {a.title}
                          </span>
                        </div>
                      </Link>
                    ))}
                  </div>
                </div>
              </aside>
            </div>
          </section>

          {/* ---------------------------------------------- SECUNDÁRIAS */}
          {secondary.length ? (
            <section className="pt-14 md:pt-20">
              <SectionLabel n="04" right={`${secondary.length} matérias`}>MAIS RECENTES</SectionLabel>
              <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-x-8 gap-y-10 mt-6">
                {secondary.slice(0, 8).map((a, i) => (
                  <Reveal key={a.id} delay={i * 0.04}>
                    <StoryCard article={a} variant="card" />
                  </Reveal>
                ))}
              </div>
            </section>
          ) : null}

          {/* ----------------------------------------------- CATEGORIAS */}
          <section className="pt-14 md:pt-20">
            <SectionLabel n="05" right="páginas próprias por pauta">CATEGORIAS</SectionLabel>
            <div className="mt-6 grid sm:grid-cols-2 lg:grid-cols-5 gap-x-8">
              {CATEGORIES.map((c, i) => (
                <Link key={c.slug} href={`/categoria/${c.slug}`} className="group block border-t border-line py-5">
                  <div className="flex items-baseline justify-between">
                    <span className="label tnum text-muted">{String(i + 1).padStart(2, "0")}</span>
                    <ArrowUpRight size={15} className="text-muted group-hover:text-ink transition-colors" />
                  </div>
                  <h3 className="headline text-[22px] mt-3 text-ink group-hover:underline-grow inline-block">{c.name}</h3>
                  <p className="text-[13px] text-muted mt-2 leading-relaxed">{c.blurb}</p>
                  <div className="mt-3 flex flex-wrap gap-x-3 gap-y-1">
                    {c.sub.slice(0, 3).map((s) => (
                      <span key={s} className="label text-muted" style={{ fontSize: 9.5 }}>
                        {s}
                      </span>
                    ))}
                  </div>
                </Link>
              ))}
            </div>
          </section>

          {/* --------------------------------------------------- FATО */}
          <section className="pt-14 md:pt-20">
            <SectionLabel n="06" right={FATO_SUBTITLE}>FATО — INVESTIGAÇÕES</SectionLabel>
            <div className="grid lg:grid-cols-3 gap-8 mt-6">
              {investigations.length ? (
                investigations.map((inv, i) => (
                  <Reveal key={inv.id} delay={i * 0.05}>
                    <Link href={`/fato/${inv.id}`} className="group block border border-line bg-panel h-full">
                      <div className="relative aspect-[16/9] overflow-hidden bg-sunk">
                        {inv.coverImage ? (
                          <img
                            src={`/${inv.coverImage}`}
                            alt=""
                            loading="lazy"
                            className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-[1.04]"
                          />
                        ) : null}
                        <span
                          className="absolute left-0 top-0 label px-2.5 py-2 text-white"
                          style={{ background: "var(--wire)" }}
                        >
                          FATО
                        </span>
                      </div>
                      <div className="p-4">
                        <div className="flex items-center justify-between gap-3">
                          <span className="label tnum text-muted">{inv.ref}</span>
                          <span className="label text-muted">v{inv.versions?.length ?? 1}</span>
                        </div>
                        <h3 className="display-md mt-3 text-ink group-hover:underline-grow">{inv.title}</h3>
                        <p className="text-sm text-ink2 mt-2 leading-relaxed line-clamp-3">{inv.summary}</p>
                        <div className="mt-4 flex items-center justify-between gap-3">
                          <span className="label" style={{ color: "#3f9c4d" }}>
                            {inv.status === "atualizada" ? "● INVESTIGAÇÃO ATUALIZADA" : "● INVESTIGAÇÃO ABERTA"}
                          </span>
                          <span className="label text-muted">{inv.sourcesAnalyzed} FONTES</span>
                        </div>
                      </div>
                    </Link>
                  </Reveal>
                ))
              ) : (
                <div className="lg:col-span-3">
                  <EmptyState
                    eyebrow="FATО"
                    title="Nenhuma investigação publicada."
                    hint="As investigações surgem a partir de perguntas da comunidade que circulam sem resposta verificável."
                    action={
                      <Link href="/fato" className="label px-4 py-3 text-white" style={{ background: "var(--wire)" }}>
                        ABRIR UMA INVESTIGAÇÃO
                      </Link>
                    }
                  />
                </div>
              )}
            </div>
          </section>

          {/* ------------------------------------------------- PRAÇA */}
          <section className="pt-14 md:pt-20">
            <SectionLabel n="07" right="comunidade integrada às notícias">PRAÇA GLOBAL</SectionLabel>
            <div className="grid lg:grid-cols-[1fr_1fr] gap-8 mt-6">
              <div className="border border-line overflow-hidden bg-sunk">
                <img src="/images/praca.jpg" alt="" className="w-full h-56 object-cover" />
                <div className="p-5 bg-panel">
                  <h3 className="display-md text-ink">Converse sobre o que está acontecendo no mundo.</h3>
                  <p className="text-sm text-ink2 mt-2 leading-relaxed measure">
                    Discussões vinculadas a notícias, acontecimentos e investigações FATО — com etiquetas que
                    separam opinião, fonte, pergunta, dado e alegação.
                  </p>
                  <Link href="/praca" className="mt-4 inline-flex items-center gap-2 label" style={{ color: "var(--cyano)" }}>
                    ENTRAR NA PRAÇA <ArrowUpRight size={13} />
                  </Link>
                </div>
              </div>

              <div>
                <div className="label text-muted mb-3">AGORA NA PRAÇA</div>
                <ul className="divide-y divide-line">
                  {discussions.map(({ discussion: d, author }) => (
                    <li key={d.id}>
                      <Link href="/praca" className="group block py-4">
                        <div className="flex items-center gap-3">
                          <span className="label" style={{ color: "var(--heat)" }}>
                            {d.heat} MOVIMENTO
                          </span>
                          <span className="label text-muted">{d.contextType}</span>
                          <span className="label text-muted ml-auto tnum">{timeAgo(d.lastActivity)}</span>
                        </div>
                        <h4 className="headline text-[16px] mt-2 text-ink group-hover:underline-grow">{d.title}</h4>
                        <p className="text-sm text-muted mt-1.5 line-clamp-2">{d.contextText}</p>
                        <div className="label text-muted mt-2">
                          {author?.name ?? "Comunidade"} · {d.comments} comentários
                        </div>
                      </Link>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </section>

          {/* --------------------------------------------- AGREGAÇÃO */}
          <section className="pt-14 md:pt-20 pb-8">
            <SectionLabel n="08" right="arquitetura de coleta">COMO O ESON RECEBE A INFORMAÇÃO</SectionLabel>
            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6 mt-6">
              {[
                { icon: Satellite, t: "APIs (GDELT, NewsAPI)", d: "Descoberta e cobertura. GDELT localiza o que está sendo dito — nunca prova que algo é verdade." },
                { icon: Rss, t: "RSS e feeds permitidos", d: "Título, metadados, trechos permitidos e link para a publicação original." },
                { icon: Boxes, t: "Fontes oficiais", d: "Documentos, atas, dados abertos e comunicados de órgãos públicos." },
                { icon: Workflow, t: "Normalização + agrupamento", d: "Título, URL, fonte, domínio, idioma, datas, imagem, categoria, entidades e evento." },
              ].map((c, i) => (
                <div key={c.t} className="border-t border-line pt-4">
                  <div className="flex items-center justify-between">
                    <c.icon size={18} className="text-ink" />
                    <span className="label tnum text-muted">{String(i + 1).padStart(2, "0")}</span>
                  </div>
                  <h4 className="headline text-[16px] mt-3 text-ink">{c.t}</h4>
                  <p className="text-[13px] text-muted mt-2 leading-relaxed">{c.d}</p>
                </div>
              ))}
            </div>

            <div className="mt-6 flex flex-wrap items-center gap-3">
              <DemoBadge />
              <span className="label text-muted">{DEMO_NOTE}</span>
            </div>
          </section>
        </div>
      </div>
    </div>
  );
}
