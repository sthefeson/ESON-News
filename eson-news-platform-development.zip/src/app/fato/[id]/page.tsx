import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowUpRight, History, Layers, Share2 } from "lucide-react";
import { Discussion } from "@/components/discussion";
import { SaveButton, ShareButton } from "@/components/actions";
import {
  DemoBadge,
  EmptyState,
  SectionLabel,
  StatusChip,
  statusMeta,
  Transparency,
  fullStamp,
  timeAgo,
} from "@/components/ui";
import { AI_DISCLOSURE, RUMOR_NOTE, UNCERTAINTY_NOTE } from "@/lib/site";
import {
  DEMO_USER_ID,
  getClaims,
  getComments,
  getInvestigation,
  getInvestigationSources,
  getReplies,
  getSaved,
} from "@/lib/data";

export const dynamic = "force-dynamic";

export async function generateMetadata({ params }: { params: Promise<{ id: string }> }): Promise<Metadata> {
  const { id } = await params;
  const inv = await getInvestigation(Number(id));
  if (!inv) return { title: "FATО" };
  return { title: `${inv.ref} — ${inv.title}`, description: inv.summary };
}

function Block({
  n,
  icon,
  title,
  items,
  empty,
  tone,
}: {
  n: string;
  icon: string;
  title: string;
  items: string[];
  empty: string;
  tone: string;
}) {
  return (
    <section className="mt-12">
      <div className="rule pt-3 flex items-baseline gap-3">
        <span className="label tnum text-muted">{n}</span>
        <span className="label" style={{ color: tone }}>
          {icon} {title}
        </span>
      </div>
      {items.length ? (
        <ul className="mt-5 space-y-4 measure">
          {items.map((t) => (
            <li key={t} className="flex gap-3.5">
              <span className="mt-2 h-2 w-2 shrink-0" style={{ background: tone }} />
              <span className="text-[16px] leading-[1.68] text-ink2">{t}</span>
            </li>
          ))}
        </ul>
      ) : (
        <div className="mt-5">
          <EmptyState eyebrow="SEM REGISTROS" title={empty} hint="Nada foi encontrado nesta categoria para esta investigação." />
        </div>
      )}
    </section>
  );
}

export default async function InvestigationPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const inv = await getInvestigation(Number(id));
  if (!inv) notFound();

  const [claimRows, sourceRows, comments, saved] = await Promise.all([
    getClaims(inv.id),
    getInvestigationSources(inv.id),
    getComments({ investigationId: inv.id }),
    getSaved(DEMO_USER_ID),
  ]);
  const replies = await getReplies(comments.map((c) => c.id));
  const repliesBy = new Map<number, typeof replies>();
  replies.forEach((r) => {
    const arr = repliesBy.get(r.commentId) ?? [];
    arr.push(r);
    repliesBy.set(r.commentId, arr);
  });

  const savedIds = new Set(saved.map((s) => `${s.itemType}:${s.itemId}`));
  const methodology = (inv.methodology ?? {}) as Record<string, unknown>;
  const rumor = (inv.rumor ?? {}) as Record<string, unknown>;
  const evolution = (rumor.evolucao as number[] | undefined) ?? [];
  const timeline = (inv.timeline ?? []) as { at: string; text: string }[];
  const versions = (inv.versions ?? []) as { v: number; at: string; text: string }[];
  const maxEvo = Math.max(1, ...evolution);

  const typeBreakdown = (methodology.tipos as Record<string, number> | undefined) ?? {};

  return (
    <div>
      {/* ------------------------------------------------ cover */}
      <header className="border-b border-line">
        <div className="relative">
          <div className="aspect-[21/9] md:aspect-[2.6/1] overflow-hidden bg-sunk">
            {inv.coverImage ? (
              <img src={`/${inv.coverImage}`} alt="" className="w-full h-full object-cover" />
            ) : null}
            <div
              className="absolute inset-0"
              style={{
                background:
                  "linear-gradient(to top, color-mix(in srgb, var(--paper) 92%, transparent) 0%, color-mix(in srgb, var(--paper) 30%, transparent) 55%, transparent 100%)",
              }}
            />
          </div>

          <div className="absolute left-0 top-0 flex">
            <span className="label px-3 py-2.5 text-white" style={{ background: "var(--wire)" }}>
              FATО
            </span>
            <span className="label px-3 py-2.5" style={{ background: "var(--heat2)", color: "#101318" }}>
              {inv.category.replace("-", " ")}
            </span>
          </div>
        </div>

        <div className="px-4 md:px-8 -mt-16 md:-mt-24 relative">
          <div className="max-w-[1400px] mx-auto">
            <div className="rule pt-3 flex flex-wrap items-center justify-between gap-3">
              <span className="label tnum text-muted">{inv.ref}</span>
              <span className="label text-muted">INVESTIGAÇÃO ESON NEWS · {inv.sourcesAnalyzed} FONTES</span>
            </div>

            <div className="grid lg:grid-cols-[1.5fr_1fr] gap-8 lg:gap-12 mt-5">
              <div>
                <p className="label" style={{ color: "var(--wire)" }}>
                  O QUE REALMENTE SABEMOS SOBRE
                </p>
                <h1 className="display-xl text-ink mt-3">{inv.title}</h1>
                <p className="label text-muted mt-4">Última atualização: {fullStamp(inv.updatedAt)}</p>
              </div>

              <div className="lg:border-l lg:border-line lg:pl-10 flex flex-col justify-end">
                <div className="flex flex-wrap items-center gap-3">
                  <span
                    className="label px-3 py-2.5"
                    style={{
                      color: inv.status === "atualizada" ? "#3f9c4d" : "var(--ink)",
                      background: inv.status === "atualizada" ? "rgba(63,156,77,.14)" : "var(--sunk)",
                    }}
                  >
                    ● {inv.status === "atualizada" ? "INVESTIGAÇÃO ATUALIZADA" : "INVESTIGAÇÃO ABERTA"}
                  </span>
                  <span className="label px-3 py-2.5 bg-sunk text-ink2">v{versions.length || 1}</span>
                </div>

                <p className="display-md mt-4" style={{ fontStyle: "italic", color: "var(--ink2)" }}>
                  «{inv.question}»
                </p>

                <div className="mt-5 flex flex-wrap gap-3">
                  <SaveButton itemType="fato" itemId={inv.id} initial={savedIds.has(`fato:${inv.id}`)} />
                  <ShareButton title={`${inv.ref} — ${inv.title}`} text={inv.summary} />
                </div>
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="px-4 md:px-8">
        <div className="max-w-[1400px] mx-auto grid lg:grid-cols-[minmax(0,1fr)_330px] gap-10 lg:gap-14 pt-10">
          <div className="min-w-0">
            {/* intro */}
            <p className="text-[18px] leading-[1.7] text-ink measure">{inv.intro ?? inv.summary}</p>

            <div className="mt-6">
              <Transparency note={`${AI_DISCLOSURE} As lacunas estão indicadas explicitamente abaixo.`} />
            </div>

            <Block
              n="01"
              icon="🟢"
              title="O QUE ESTÁ CONFIRMADO"
              tone="#3f9c4d"
              items={(inv.confirmed ?? []) as string[]}
              empty="Nada confirmado até aqui."
            />
            <Block
              n="02"
              icon="🟡"
              title="O QUE AINDA NÃO FOI CONFIRMADO"
              tone="#a1760c"
              items={(inv.unconfirmed ?? []) as string[]}
              empty="Nenhum ponto em aberto registrado."
            />
            <Block
              n="03"
              icon="🔴"
              title="INFORMAÇÕES CONTTESTADAS"
              tone="#d1342a"
              items={(inv.contested ?? []) as string[]}
              empty="Nenhuma contradição relevante encontrada."
            />
            <Block
              n="04"
              icon="📈"
              title="O QUE ESTÁ CIRCULANDO"
              tone="var(--heat)"
              items={(inv.circulating ?? []) as string[]}
              empty="Nenhuma narrativa circulante mapeada."
            />

            {/* timeline */}
            <section className="mt-12">
              <div className="rule pt-3 flex items-baseline gap-3">
                <span className="label tnum text-muted">05</span>
                <span className="label">🕐 LINHA DO TEMPO</span>
              </div>
              {timeline.length ? (
                <ol className="mt-5 border-l border-line pl-5 space-y-5">
                  {timeline.map((t) => (
                    <li key={t.at + t.text} className="relative">
                      <span
                        className="absolute -left-[26px] top-1.5 h-2 w-2 rounded-full"
                        style={{ background: "var(--wire)" }}
                      />
                      <span className="label tnum text-muted">{t.at}</span>
                      <p className="text-[15.5px] text-ink2 leading-relaxed mt-1.5">{t.text}</p>
                    </li>
                  ))}
                </ol>
              ) : (
                <div className="mt-5">
                  <EmptyState eyebrow="LINHA DO TEMPO" title="Ainda não há marcos registrados." />
                </div>
              )}
            </section>

            {/* evidences table */}
            <section className="mt-12">
              <div className="rule pt-3 flex items-baseline gap-3">
                <span className="label tnum text-muted">06</span>
                <span className="label">📋 EVIDÊNCIAS</span>
              </div>

              {claimRows.length ? (
                <div className="mt-5 overflow-x-auto">
                  <table className="w-full text-left border-collapse min-w-[640px]">
                    <thead>
                      <tr className="border-b border-line">
                        {["AFIRMAÇÃO", "EVIDÊNCIA", "SITUAÇÃO"].map((h) => (
                          <th key={h} className="label text-muted py-3 pr-4 font-medium">
                            {h}
                          </th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {claimRows.map((c) => (
                        <tr key={c.id} className="border-b border-line align-top">
                          <td className="py-4 pr-4 text-[15px] text-ink max-w-[260px]">{c.claim}</td>
                          <td className="py-4 pr-4 text-[14.5px] text-ink2 leading-relaxed">
                            {c.evidenceSummary}
                          </td>
                          <td className="py-4 pr-4">
                            <StatusChip status={c.status} />
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              ) : (
                <div className="mt-5">
                  <EmptyState
                    eyebrow="EVIDÊNCIAS"
                    title="Nenhuma afirmação classificada ainda."
                    hint="A investigação está em coleta: as afirmações entram na tabela quando há evidência para avaliar."
                  />
                </div>
              )}
              <p className="label text-muted mt-3 leading-[1.8]">
                Classificação é atribuída a cada afirmação individualmente — nunca a uma narrativa inteira.
              </p>
            </section>

            {/* sources */}
            <section className="mt-12">
              <div className="rule pt-3 flex items-baseline gap-3">
                <span className="label tnum text-muted">07</span>
                <span className="label">🔗 FONTES CONSULTADAS</span>
              </div>
              {sourceRows.length ? (
                <ul className="mt-5 divide-y divide-line">
                  {sourceRows.map((s) => (
                    <li key={s.id} className="py-4 flex flex-wrap items-start gap-x-4 gap-y-2">
                      <span
                        className="label px-2 py-1.5 shrink-0"
                        style={{
                          background: "var(--sunk)",
                          color:
                            s.relevance === "contradiz"
                              ? "var(--wire)"
                              : s.relevance === "apoio"
                                ? "#3f9c4d"
                                : "var(--muted)",
                        }}
                      >
                        {s.relevance === "contradiz" ? "CONTRADIZ" : s.relevance === "apoio" ? "APOIO" : "NEUTRO"}
                      </span>
                      <div className="min-w-0 flex-1">
                        <a
                          href={s.url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-[15.5px] text-ink hover:underline underline-offset-4 decoration-dotted inline-flex items-center gap-1.5"
                        >
                          {s.title ?? s.name}
                          <ArrowUpRight size={13} />
                        </a>
                        <div className="label text-muted mt-1.5">{s.name}</div>
                        {s.note ? <p className="text-sm text-ink2 mt-1.5 leading-relaxed">{s.note}</p> : null}
                      </div>
                    </li>
                  ))}
                </ul>
              ) : (
                <div className="mt-5">
                  <EmptyState
                    eyebrow="FONTES"
                    title="Nenhuma fonte consultada registrada."
                    hint="A lista aparece assim que o motor concluir a primeira varredura de documentos e cobertura."
                  />
                </div>
              )}
            </section>

            {/* methodology */}
            <section className="mt-12">
              <div className="rule pt-3 flex items-baseline gap-3">
                <span className="label tnum text-muted">08</span>
                <span className="label">🧠 COMO O ESON CHEGOU A ESTA CONCLUSÃO</span>
              </div>

              <div className="mt-5 grid sm:grid-cols-3 gap-6">
                {[
                  ["FONTES ANALISADAS", inv.sourcesAnalyzed],
                  ["DOCUMENTOS ENCONTRADOS", Number(methodology.documentos ?? 0)],
                  ["PONTOS DE CONCORDÂNCIA", Number(methodology.concordancias ?? 0)],
                  ["PONTOS DE DIVERGÊNCIA", Number(methodology.divergencias ?? 0)],
                  ["INVESTIGAÇÃO ABERTA DESDE", fullStamp(inv.createdAt).split(" · ")[0]],
                  ["ATUALIZAÇÕES", versions.length || 1],
                ].map(([k, v]) => (
                  <div key={k as string} className="border-t border-line pt-3">
                    <div className="label text-muted" style={{ fontSize: 9.5 }}>
                      {k}
                    </div>
                    <div className="tnum text-ink mt-2" style={{ fontSize: 26, letterSpacing: "-0.03em" }}>
                      {v}
                    </div>
                  </div>
                ))}
              </div>

              {Object.keys(typeBreakdown).length ? (
                <div className="mt-6">
                  <div className="label text-muted mb-3">TIPOS DE FONTE</div>
                  <ul className="grid sm:grid-cols-2 gap-x-8">
                    {Object.entries(typeBreakdown).map(([k, v]) => (
                      <li key={k} className="flex items-baseline justify-between gap-4 border-t border-line py-2.5">
                        <span className="text-sm text-ink2">{k.replace(/_/g, " ")}</span>
                        <span className="tnum text-sm text-ink">{v}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              ) : null}

              <div className="mt-6 border-l-2 pl-4" style={{ borderColor: "var(--wire)" }}>
                <p className="text-[15.5px] leading-relaxed text-ink2 measure">
                  <strong className="text-ink">Limitações da investigação:</strong>{" "}
                  {String(methodology.limitacoes ?? UNCERTAINTY_NOTE)}
                </p>
              </div>

              <p className="label text-muted mt-4 leading-[1.8]">{UNCERTAINTY_NOTE}</p>
            </section>

            {/* versions */}
            <section className="mt-12">
              <div className="rule pt-3 flex items-baseline gap-3">
                <span className="label tnum text-muted">09</span>
                <span className="label">
                  <History size={12} className="inline mr-1.5 -mt-0.5" />
                  HISTÓRICO DE VERSÕES
                </span>
              </div>
              {versions.length ? (
                <ol className="mt-5 divide-y divide-line">
                  {[...versions].reverse().map((v, i) => (
                    <li key={v.v} className="py-4">
                      <div className="flex flex-wrap gap-x-5 gap-y-2 items-baseline">
                        <span className="tnum text-ink" style={{ fontSize: 22 }}>
                          v{v.v}
                        </span>
                        <span className="label text-muted tnum">{v.at}</span>
                        {i === 0 ? (
                          <span className="label px-2 py-1.5 text-white" style={{ background: "var(--wire)" }}>
                            VERSÃO ATUAL
                          </span>
                        ) : (
                          <span className="label text-muted">
                            alterações em relação à v{Math.max(1, v.v - 1)}
                          </span>
                        )}
                      </div>

                      {i === 0 ? (
                        <p className="text-[15.5px] text-ink2 leading-relaxed mt-2 measure">{v.text}</p>
                      ) : (
                        <details className="mt-2 measure">
                          <summary className="label px-2 py-1.5 border border-line text-muted hover:text-ink hover:border-ink transition-colors cursor-pointer inline-block">
                            VER O QUE MUDOU
                          </summary>
                          <p className="text-[15.5px] text-ink2 leading-relaxed mt-2">{v.text}</p>
                        </details>
                      )}
                    </li>
                  ))}
                </ol>
              ) : (
                <div className="mt-5">
                  <EmptyState eyebrow="VERSÕES" title="Somente a versão inicial está publicada." />
                </div>
              )}
            </section>

            {/* discussion */}
            <div className="mt-14">
              <Discussion
                comments={comments.map((c) => ({
                  ...c,
                  createdAt: c.createdAt as Date,
                  replies: (repliesBy.get(c.id) ?? []).map((r) => ({
                    id: r.id,
                    content: r.content,
                    type: r.type,
                    likes: r.likes,
                    createdAt: r.createdAt as Date,
                    user: r.user ? { name: r.user.name, username: r.user.username } : null,
                  })),
                }))}
                scope={{ investigationId: inv.id }}
                heading="DISCUSSÃO DA COMUNIDADE"
              />
            </div>
          </div>

          {/* ----------------------------------------------- aside */}
          <aside className="lg:border-l lg:border-line lg:pl-8 space-y-8">
            {/* share card */}
            <div className="border border-line">
              <div className="label px-4 py-2.5 border-b border-line text-muted">CARD PARA COMPARTILHAR</div>
              <div className="p-4" style={{ background: "var(--panel)" }}>
                <div className="flex items-center justify-between">
                  <span className="font-sans font-extrabold tracking-[-0.045em] text-ink" style={{ fontSize: 15 }}>
                    ESON<span style={{ color: "var(--wire)" }}>NEWS</span>
                  </span>
                  <span className="label px-1.5 py-1 text-white" style={{ background: "var(--wire)", fontSize: 9 }}>
                    FATО
                  </span>
                </div>
                <div className="mt-3 aspect-[1.9/1] relative overflow-hidden bg-sunk">
                  {inv.coverImage ? (
                    <img src={`/${inv.coverImage}`} alt="" className="w-full h-full object-cover opacity-70" />
                  ) : null}
                  <div className="absolute inset-0 grid content-end p-3" style={{ background: "linear-gradient(to top, rgba(0,0,0,.78), transparent 70%)" }}>
                    <span className="label text-white/70 tnum">{inv.ref}</span>
                    <span className="display-md text-white leading-tight line-clamp-3" style={{ fontSize: 20 }}>
                      {inv.title}
                    </span>
                  </div>
                </div>
                <div className="mt-3 flex items-center justify-between">
                  <span className="label text-muted tnum">{fullStamp(inv.updatedAt)}</span>
                  <span className="label text-muted">{inv.category.replace("-", " ")}</span>
                </div>
                <ShareButton
                  title={`${inv.ref} — ${inv.title}`}
                  text={`${inv.summary} — Investigação Eson News`}
                />
              </div>
            </div>

            {/* rumour radar */}
            <div className="border border-line p-4">
              <div className="label text-ink mb-3">📈 RADAR DE RUMORES</div>
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="label text-muted">CIRCULAÇÃO</span>
                  <span
                    className="label"
                    style={{
                      color:
                        rumor.circulacao === "ALTA"
                          ? "var(--wire)"
                          : rumor.circulacao === "MÉDIA"
                            ? "var(--heat)"
                            : "var(--muted)",
                    }}
                  >
                    {String(rumor.circulacao ?? "—")}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="label text-muted">PUBLICAÇÕES APROX.</span>
                  <span className="tnum text-sm text-ink">{Number(rumor.aprox_fontes ?? 0)}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="label text-muted">EVIDÊNCIAS INDEPENDENTES</span>
                  <span className="tnum text-sm text-ink">
                    {Number(rumor.evidencias_independentes ?? 0)} encontradas
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="label text-muted">CONFIRMAÇÃO OFICIAL</span>
                  <span className="label text-ink">{String(rumor.confirmacao_oficial ?? "não localizada")}</span>
                </div>
                <div className="flex items-center justify-between border-t border-line pt-3">
                  <span className="label text-muted">STATUS</span>
                  <span className="label text-ink">{String(rumor.status ?? "não confirmado")}</span>
                </div>
              </div>

              {evolution.length ? (
                <div className="mt-4">
                  <div className="label text-muted mb-2">EVOLUÇÃO TEMPORAL</div>
                  <div className="flex items-end gap-1.5 h-16">
                    {evolution.map((v, i) => (
                      <div
                        key={i}
                        className="flex-1 grow-x origin-bottom"
                        style={{
                          height: `${(v / maxEvo) * 100}%`,
                          background: i === evolution.length - 1 ? "var(--wire)" : "var(--heat)",
                          opacity: i === evolution.length - 1 ? 1 : 0.55,
                          animationDelay: `${i * 60}ms`,
                        }}
                      />
                    ))}
                  </div>
                  <div className="flex justify-between mt-1.5">
                    <span className="label text-muted" style={{ fontSize: 9 }}>
                      7 DIAS ATRÁS
                    </span>
                    <span className="label text-muted" style={{ fontSize: 9 }}>
                      AGORA
                    </span>
                  </div>
                </div>
              ) : null}

              {Array.isArray(rumor.onde) && (rumor.onde as string[]).length ? (
                <div className="mt-4 flex flex-wrap gap-2">
                  {(rumor.onde as string[]).map((o) => (
                    <span key={o} className="label px-2 py-1.5 bg-sunk text-ink2">
                      {o}
                    </span>
                  ))}
                </div>
              ) : null}

              <p className="label mt-4 pt-3 border-t border-line" style={{ color: "var(--heat)" }}>
                {RUMOR_NOTE}
              </p>
            </div>

            {/* classifications legend */}
            <div className="border border-line p-4">
              <div className="label text-ink mb-3">LEGENDA DE CLASSIFICAÇÃO</div>
              <div className="space-y-2.5">
                {["confirmado", "bem_sustentado", "em_investigacao", "alegacao", "contradito", "nao_verificavel"].map(
                  (s) => (
                    <div key={s} className="flex items-center gap-3">
                      <StatusChip status={s} />
                      <span className="text-xs text-muted leading-snug flex-1">{statusMeta(s).desc ?? ""}</span>
                    </div>
                  ),
                )}
              </div>
            </div>

            <div className="border border-line p-4">
              <div className="flex items-center gap-2 mb-3">
                <Layers size={14} /> <span className="label">PRÓXIMOS PASSOS</span>
              </div>
              <p className="text-sm text-ink2 leading-relaxed">
                Esta investigação continua aberta. Quando uma nova evidência for localizada, uma nova versão é
                publicada e o histórico é mantido.
              </p>
              <Link href="/praca" className="label mt-3 inline-flex items-center gap-1.5" style={{ color: "var(--cyano)" }}>
                DISCUTIR NA PRAÇA <ArrowUpRight size={13} />
              </Link>
            </div>

            <div className="flex items-center gap-3">
              <DemoBadge />
              <span className="label text-muted tnum">{timeAgo(inv.updatedAt)}</span>
            </div>

            <Transparency />
          </aside>
        </div>

        <div className="h-10" />
      </div>
    </div>
  );
}
