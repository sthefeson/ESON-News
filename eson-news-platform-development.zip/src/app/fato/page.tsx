import type { Metadata } from "next";
import Link from "next/link";
import { ArrowUpRight, ShieldQuestion } from "lucide-react";
import { FatoQuery } from "@/components/fato-query";
import { Reveal } from "@/components/reveal";
import { DemoBadge, EmptyState, SectionLabel, timeAgo } from "@/components/ui";
import { FATO_CLASSES, FATO_STAGES, FATO_SUBTITLE, RUMOR_NOTE } from "@/lib/site";
import { getInvestigations } from "@/lib/data";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: `FATО — ${FATO_SUBTITLE}`,
  description:
    "FATО: investigação de afirmações com evidências, classificação explícita e fontes consultadas. Investigue antes de concluir.",
};

export default async function FatoIndex() {
  const investigations = await getInvestigations(20);

  return (
    <div className="px-4 md:px-8">
      <div className="max-w-[1400px] mx-auto">
        {/* ------------------------------------------------ hero */}
        <header className="pt-8 md:pt-14">
          <div className="rule pt-3 flex items-center justify-between gap-4">
            <span className="label" style={{ color: "var(--wire)" }}>
              FATО
            </span>
            <span className="label text-muted">{investigations.length} INVESTIGAÇÕES ABERTAS</span>
          </div>

          <div className="grid lg:grid-cols-[1.3fr_1fr] gap-8 items-end mt-6">
            <div>
              <h1 className="display-xl text-ink">FATО</h1>
              <p className="display-md mt-3" style={{ fontStyle: "italic", color: "var(--wire)" }}>
                {FATO_SUBTITLE}
              </p>
            </div>
            <p className="text-ink2 leading-relaxed lg:pb-4">
              Uma pergunta vira uma investigação: entendemos a afirmação, buscamos documentos e fontes,
              cruzamos quem diz o quê e classificamos cada afirmação — sem transformar volume de publicações
              em prova.
            </p>
          </div>

          <div className="mt-8">
            <FatoQuery />
          </div>
        </header>

        {/* ------------------------------------------------ engine */}
        <section className="pt-14">
          <SectionLabel n="01" right="motor de investigação">COMO O FATО INVESTIGA</SectionLabel>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6 mt-6">
            {FATO_STAGES.map((s, i) => (
              <Reveal key={s.n} delay={i * 0.05}>
                <div className="border-t border-line pt-4 h-full">
                  <div className="flex items-baseline justify-between">
                    <span className="tnum text-muted" style={{ fontSize: 13 }}>
                      ETAPA {s.n}
                    </span>
                    <ShieldQuestion size={16} className="text-ink" />
                  </div>
                  <h3 className="headline text-[18px] mt-3 text-ink">{s.t}</h3>
                  <p className="text-[13.5px] text-muted mt-2 leading-relaxed">{s.d}</p>
                </div>
              </Reveal>
            ))}
          </div>
        </section>

        {/* ------------------------------------------------ classes */}
        <section className="pt-14">
          <SectionLabel n="02" right="classificação de cada afirmação">SITUAÇÕES POSSÍVEIS</SectionLabel>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-x-8 mt-6">
            {FATO_CLASSES.map((c) => (
              <div key={c.key} className="border-t border-line py-4 flex gap-4">
                <span className="text-xl leading-none mt-0.5" aria-hidden>
                  {c.icon}
                </span>
                <div>
                  <div className="label text-ink">{c.name}</div>
                  <p className="text-[13.5px] text-muted mt-1.5 leading-relaxed">{c.desc}</p>
                </div>
              </div>
            ))}
          </div>
          <p className="label text-muted mt-5 leading-[1.8]">
            O volume de publicações nunca é tratado como prova. Ausência de evidência também não é evidência de
            ausência — quando não sabemos, dizemos que não sabemos.
          </p>
        </section>

        {/* ------------------------------------------------ rumours */}
        <section className="pt-14">
          <SectionLabel n="03" right="radar de rumores">📈 O QUE ESTÁ CIRCULANDO</SectionLabel>
          <div className="grid sm:grid-cols-3 gap-6 mt-6">
            {investigations.slice(0, 3).map((inv) => {
              const rumor = (inv.rumor ?? {}) as Record<string, unknown>;
              const circulacao = String(rumor.circulacao ?? "—");
              const evidencias = Number(rumor.evidencias_independentes ?? 0);
              const oficial = String(rumor.confirmacao_oficial ?? "não localizada");
              const status = String(rumor.status ?? "não confirmado");
              const tone =
                circulacao === "ALTA" ? "var(--wire)" : circulacao === "MÉDIA" ? "var(--heat)" : "var(--muted)";
              return (
                <Link key={inv.id} href={`/fato/${inv.id}`} className="group border border-line bg-panel p-5">
                  <div className="label text-muted flex items-center justify-between">
                    <span className="tnum">{inv.ref}</span>
                    <span style={{ color: "var(--wire)" }}>RUMOR</span>
                  </div>
                  <h3 className="headline text-[16px] mt-3 text-ink group-hover:underline-grow">{inv.title}</h3>

                  <div className="mt-4 space-y-2.5">
                    <div className="flex items-center justify-between">
                      <span className="label text-muted">CIRCULAÇÃO</span>
                      <span className="label" style={{ color: tone }}>
                        {circulacao}
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="label text-muted">FONTES APROX.</span>
                      <span className="tnum text-sm text-ink">{Number(rumor.aprox_fontes ?? 0)}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="label text-muted">EVIDÊNCIAS INDEP.</span>
                      <span className="tnum text-sm text-ink">{evidencias}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="label text-muted">CONFIRMAÇÃO OFICIAL</span>
                      <span className="label text-ink">{oficial}</span>
                    </div>
                    <div className="flex items-center justify-between border-t border-line pt-2.5">
                      <span className="label text-muted">STATUS</span>
                      <span className="label text-ink">{status}</span>
                    </div>
                  </div>

                  <p className="label mt-4 pt-3 border-t border-line" style={{ color: "var(--heat)" }}>
                    {RUMOR_NOTE}
                  </p>
                </Link>
              );
            })}
          </div>
        </section>

        {/* ------------------------------------------------ list */}
        <section className="pt-14 pb-12">
          <SectionLabel n="04" right="páginas editoriais geradas">INVESTIGAÇÕES PUBLICADAS</SectionLabel>

          {investigations.length ? (
            <div className="mt-6 space-y-8">
              {investigations.map((inv, i) => (
                <Reveal key={inv.id} delay={Math.min(i * 0.05, 0.3)}>
                  <Link
                    href={`/fato/${inv.id}`}
                    className="group grid md:grid-cols-[280px_1fr] gap-6 border border-line bg-panel p-4 md:p-5"
                  >
                    <div className="relative aspect-[16/10] overflow-hidden bg-sunk">
                      {inv.coverImage ? (
                        <img
                          src={`/${inv.coverImage}`}
                          alt=""
                          loading="lazy"
                          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-[1.05]"
                        />
                      ) : null}
                      <span
                        className="absolute left-0 top-0 label px-2.5 py-2 text-white"
                        style={{ background: "var(--wire)" }}
                      >
                        FATО
                      </span>
                      <span className="absolute right-0 bottom-0 label px-2 py-1.5" style={{ background: "var(--heat2)", color: "#101318" }}>
                        {inv.category.replace("-", " ")}
                      </span>
                    </div>

                    <div className="min-w-0">
                      <div className="flex flex-wrap items-center gap-x-4 gap-y-2">
                        <span className="label tnum text-muted">{inv.ref}</span>
                        <span className="label" style={{ color: "#3f9c4d" }}>
                          ● {inv.status === "atualizada" ? "INVESTIGAÇÃO ATUALIZADA" : "INVESTIGAÇÃO ABERTA"}
                        </span>
                        <span className="label text-muted">v{inv.versions?.length ?? 1}</span>
                        <span className="label text-muted ml-auto">
                          atualizada {timeAgo(inv.updatedAt)}
                        </span>
                      </div>

                      <h3 className="display-md mt-3 text-ink group-hover:underline-grow">{inv.title}</h3>
                      <p className="text-sm text-ink2 mt-2 leading-relaxed measure">{inv.summary}</p>

                      <div className="mt-4 flex flex-wrap items-center gap-x-6 gap-y-2">
                        <span className="label text-muted">{inv.sourcesAnalyzed} FONTES ANALISADAS</span>
                        <span className="label text-muted">{inv.versions?.length ?? 1} VERSÕES</span>
                        <span
                          className="label inline-flex items-center gap-1.5 ml-auto"
                          style={{ color: "var(--cyano)" }}
                        >
                          LER INVESTIGAÇÃO <ArrowUpRight size={13} />
                        </span>
                      </div>
                    </div>
                  </Link>
                </Reveal>
              ))}
            </div>
          ) : (
            <div className="mt-6">
              <EmptyState
                eyebrow="FATО"
                title="Nenhuma investigação publicada ainda."
                hint="Faça uma pergunta acima. Quando houver evidência suficiente para separar o confirmado do incerto, a página editorial é gerada."
              />
            </div>
          )}

          <div className="mt-8">
            <DemoBadge />
          </div>
        </section>
      </div>
    </div>
  );
}
