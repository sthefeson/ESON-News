import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowUpRight, Layers, Radar as RadarIcon } from "lucide-react";
import { Discussion } from "@/components/discussion";
import { SaveButton, ShareButton } from "@/components/actions";
import { StoryCard } from "@/components/story";
import {
  Avatar,
  CategoryTag,
  DemoBadge,
  EmptyState,
  Meter,
  Pill,
  SectionLabel,
  Transparency,
  clock,
  fullStamp,
  timeAgo,
} from "@/components/ui";
import { radarBand } from "@/lib/site";
import {
  DEMO_USER_ID,
  getArticle,
  getComments,
  getEvent,
  getEventCluster,
  getInvestigations,
  getRelatedArticles,
  getReplies,
  getSaved,
} from "@/lib/data";

export const dynamic = "force-dynamic";

export async function generateMetadata({ params }: { params: Promise<{ id: string }> }): Promise<Metadata> {
  const { id } = await params;
  const article = await getArticle(Number(id));
  if (!article) return { title: "Notícia" };
  return { title: article.title, description: article.description ?? undefined };
}

export default async function ArticlePage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const article = await getArticle(Number(id));
  if (!article) notFound();

  const [event, cluster, related, comments, investigations, saved] = await Promise.all([
    article.eventId ? getEvent(article.eventId) : null,
    article.eventId ? getEventCluster(article.eventId) : [],
    getRelatedArticles(article),
    getComments({ articleId: article.id, eventId: article.eventId ?? -1 }),
    getInvestigations(8),
    getSaved(DEMO_USER_ID),
  ]);

  const replies = await getReplies(comments.map((c) => c.id));
  const repliesBy = new Map<number, typeof replies>();
  replies.forEach((r) => {
    const arr = repliesBy.get(r.commentId) ?? [];
    arr.push(r);
    repliesBy.set(r.commentId, arr);
  });

  const savedIds = new Set(saved.map((s) => `${s.itemType}:${s.itemId}`));
  const band = event ? radarBand(event.importanceScore) : null;
  const paragraphs = (article.body ?? "").split(/\n\s*\n/).filter(Boolean);
  const timeline = [...cluster].sort(
    (a, b) => new Date(b.article.publishedAt).getTime() - new Date(a.article.publishedAt).getTime(),
  );
  const relatedInv = investigations.filter((i) => i.category === article.category).slice(0, 2);

  return (
    <div className="px-4 md:px-8">
      <div className="max-w-[1400px] mx-auto">
        {/* ---------------------------------------------- header */}
        <header className="pt-8 md:pt-12">
          <div className="rule pt-3 flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-4">
              <Link href={`/categoria/${article.category}`} className="label" style={{ color: "var(--wire)" }}>
                {article.category.replace("-", " ")}
              </Link>
              <span className="label text-muted tnum">{fullStamp(article.publishedAt)}</span>
              {article.author ? <span className="label text-muted">POR {article.author.toUpperCase()}</span> : null}
            </div>
            <DemoBadge />
          </div>

          <div className="grid lg:grid-cols-[1.5fr_1fr] gap-8 lg:gap-12 mt-6">
            <div>
              <h1 className="display-xl text-ink">{article.title}</h1>
              {article.subtitle ? (
                <p className="display-md mt-4" style={{ fontStyle: "italic", color: "var(--ink2)" }}>
                  {article.subtitle}
                </p>
              ) : null}
            </div>

            <div className="lg:border-l lg:border-line lg:pl-10 flex flex-col justify-end">
              <div className="flex flex-wrap items-center gap-3">
                <SaveButton
                  itemType="noticia"
                  itemId={article.id}
                  initial={savedIds.has(`noticia:${article.id}`)}
                />
                <ShareButton title={article.title} text={article.description ?? ""} />
              </div>
              <dl className="mt-5 grid grid-cols-2 gap-x-6 gap-y-4 border-t border-line pt-5">
                {[
                  ["FONTE", article.source],
                  ["DOMÍNIO", article.domain ?? "—"],
                  ["PUBLICADO", `${clock(article.publishedAt)} · ${timeAgo(article.publishedAt)}`],
                  ["DESCOBERTO", `${clock(article.discoveredAt)} · ${timeAgo(article.discoveredAt)}`],
                ].map(([k, v]) => (
                  <div key={k}>
                    <dt className="label text-muted" style={{ fontSize: 9.5 }}>
                      {k}
                    </dt>
                    <dd className="text-sm text-ink mt-1.5 break-words">{v}</dd>
                  </div>
                ))}
              </dl>
              <a
                href={article.url}
                target="_blank"
                rel="noopener noreferrer"
                className="label mt-5 inline-flex items-center gap-2"
                style={{ color: "var(--cyano)" }}
              >
                IR PARA A PUBLICAÇÃO ORIGINAL <ArrowUpRight size={13} />
              </a>
            </div>
          </div>

          {article.imageUrl ? (
            <figure className="mt-8">
              <div className="aspect-[16/9] overflow-hidden bg-sunk">
                <img src={`/${article.imageUrl}`} alt="" className="w-full h-full object-cover" />
              </div>
              <figcaption className="label text-muted mt-2">
                IMAGEM DE ILUSTRAÇÃO DO DADO DEMONSTRATIVO · {article.source}
              </figcaption>
            </figure>
          ) : null}
        </header>

        {/* ---------------------------------------------- body */}
        <div className="grid lg:grid-cols-[minmax(0,1fr)_330px] gap-10 lg:gap-14 pt-10">
          <div className="min-w-0">
            {/* resumo */}
            <SectionLabel n="01" right="síntese editorial">RESUMO</SectionLabel>
            <p className="text-[17px] leading-[1.7] text-ink mt-5 measure">
              {article.description ?? article.title}
            </p>

            {/* o que sabemos */}
            <SectionLabel n="02" right="verificável">O QUE SABEMOS</SectionLabel>
            <ul className="mt-5 space-y-3 measure">
              {[
                event
                  ? `O acontecimento foi agrupado pelo Eson e reúne ${event.sourcesCount} fontes distintas relacionadas.`
                  : "Esta matéria não está vinculada a um acontecimento agrupado no momento.",
                `A publicação original é de ${article.source}${article.author ? `, assinada por ${article.author}` : ""}, e o link está no topo desta página.`,
                event
                  ? `Segundo a cobertura reunida: ${event.summary}`
                  : "Não há resumo de acontecimento agregado disponível para esta matéria.",
                "Esta página é uma síntese de metadados e trechos permitidos — não reproduz o texto integral de terceiros.",
              ].map((t) => (
                <li key={t} className="flex gap-3 text-[15.5px] leading-relaxed text-ink2">
                  <span className="mt-2 h-1.5 w-1.5 shrink-0" style={{ background: "var(--wire)" }} />
                  {t}
                </li>
              ))}
            </ul>

            {/* conteúdo */}
            <SectionLabel n="03" right={`${paragraphs.length} parágrafos`}>CONTEÚDO</SectionLabel>
            <div className="prose-eson mt-5 measure">
              {event ? <p>{event.summary}</p> : null}
              {paragraphs.map((p) => (
                <p key={p.slice(0, 40)}>{p}</p>
              ))}
            </div>

            <div className="mt-6 border-l-2 pl-4" style={{ borderColor: "var(--cyano)" }}>
              <p className="label text-muted leading-[1.8]">
                Conteúdo sintetizado pelo Eson News a partir das fontes indicadas.
                <br />
                As informações disponíveis ainda não permitem uma conclusão definitiva além do que está declarado
                nas fontes.
              </p>
            </div>

            {/* atualizações */}
            <SectionLabel n="04" right={`${timeline.length} registros`} className="mt-12">
              ATUALIZAÇÕES
            </SectionLabel>
            <ol className="mt-5 border-l border-line pl-5 space-y-5">
              {timeline.map((row) => (
                <li key={row.article.id} className="relative">
                  <span
                    className="absolute -left-[26px] top-1.5 h-2 w-2 rounded-full"
                    style={{ background: row.article.id === article.id ? "var(--wire)" : "var(--line)" }}
                  />
                  <div className="flex flex-wrap items-center gap-3">
                    <span className="label tnum text-muted">{clock(row.article.publishedAt)}</span>
                    <span className="label text-muted">{row.article.source}</span>
                    {row.article.id === article.id ? (
                      <span className="label px-2 py-1 text-white" style={{ background: "var(--wire)" }}>
                        VOCÊ ESTÁ LENDO
                      </span>
                    ) : null}
                  </div>
                  <Link href={`/noticia/${row.article.id}`} className="group block mt-1.5">
                    <span className="text-[15.5px] text-ink2 group-hover:text-ink transition-colors leading-snug">
                      {row.article.title}
                    </span>
                  </Link>
                </li>
              ))}
            </ol>

            {/* fontes */}
            <SectionLabel n="05" right={`${cluster.length} publicações`} className="mt-12">
              FONTES
            </SectionLabel>
            <div className="mt-5 overflow-x-auto">
              <table className="w-full text-left border-collapse min-w-[560px]">
                <thead>
                  <tr className="border-b border-line">
                    {["FONTE", "DOMÍNIO", "PUBLICADO", "TIPO"].map((h) => (
                      <th key={h} className="label text-muted py-3 pr-4 font-medium">
                        {h}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {cluster.map((row) => (
                    <tr key={row.article.id} className="border-b border-line align-top">
                      <td className="py-3 pr-4">
                        <a
                          href={row.article.url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-sm text-ink hover:underline underline-offset-4 decoration-dotted inline-flex items-center gap-1.5"
                        >
                          {row.sourceName ?? row.article.source}
                          <ArrowUpRight size={12} />
                        </a>
                      </td>
                      <td className="py-3 pr-4 text-sm text-ink2">{row.sourceDomain ?? row.article.domain ?? "—"}</td>
                      <td className="py-3 pr-4 tnum text-sm text-ink2">{clock(row.article.publishedAt)}</td>
                      <td className="py-3 pr-4 label text-muted">{row.sourceType ?? "—"}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <p className="label text-muted mt-3">
              Fontes exibidas com título, metadados e link para a publicação original. Nenhum texto integral de
              terceiros é reproduzido aqui.
            </p>

            {/* relacionados */}
            <SectionLabel n="06" right="mesma pauta" className="mt-12">
              NOTÍCIAS RELACIONADAS
            </SectionLabel>
            <div className="grid sm:grid-cols-2 gap-x-8 gap-y-8 mt-5">
              {related.map((a) => (
                <StoryCard key={a.id} article={a} variant="card" />
              ))}
            </div>

            {/* discussão */}
            <div className="mt-14">
              <Discussion
                comments={comments.map((c) => ({
                  ...c,
                  createdAt: c.createdAt as Date,
                  replies: (repliesBy.get(c.id) ?? []).map((r) => ({
                    id: r.id,
                    content: r.content,
                    type: r.type,
                    likes: r.likes,
                    createdAt: r.createdAt as Date,
                    user: r.user ? { name: r.user.name, username: r.user.username } : null,
                  })),
                }))}
                scope={{ articleId: article.id }}
              />
            </div>
          </div>

          {/* ------------------------------------------------- aside */}
          <aside className="lg:border-l lg:border-line lg:pl-8 space-y-8">
            {event && band ? (
              <div className="border border-line bg-panel p-4">
                <div className="flex items-center gap-2">
                  <RadarIcon size={14} className="text-ink" />
                  <span className="label text-ink">RADAR ESON</span>
                </div>
                <div className="flex items-baseline gap-3 mt-3">
                  <span className="tnum leading-none" style={{ fontSize: 52, color: band.color, letterSpacing: "-0.04em" }}>
                    {event.importanceScore}
                  </span>
                  <span className="label" style={{ color: band.color }}>
                    {band.label}
                  </span>
                </div>
                <div className="mt-4 space-y-3">
                  {[
                    ["FONTES", event.sourcesCount],
                    ["VELOCIDADE", event.velocity],
                    ["ALCANCE INT.", event.reach],
                    ["CRESCIMENTO", event.growth],
                  ].map(([k, v]) => (
                    <div key={k as string}>
                      <div className="flex items-center justify-between">
                        <span className="label text-muted" style={{ fontSize: 9.5 }}>
                          {k}
                        </span>
                        <span className="tnum text-sm text-ink">{v}</span>
                      </div>
                      <div className="mt-1.5">
                        <Meter value={Number(v)} color={band.color} height={2} />
                      </div>
                    </div>
                  ))}
                </div>
                <Link
                  href={`/acontecimento/${event.id}`}
                  className="label mt-4 inline-flex items-center gap-1.5"
                  style={{ color: "var(--cyano)" }}
                >
                  VER O ACONTECIMENTO <ArrowUpRight size={13} />
                </Link>
              </div>
            ) : null}

            <div className="border border-line p-4">
              <div className="flex items-center gap-2 mb-3">
                <Layers size={14} className="text-ink" />
                <span className="label text-ink">AGRUPAMENTO</span>
              </div>
              <p className="text-sm text-ink2 leading-relaxed">
                {cluster.length > 1
                  ? `Este acontecimento tem ${cluster.length} publicações diferentes. O Eson evita repetir a mesma notícia na home e reúne tudo em uma única história.`
                  : "Ainda não há outras publicações agrupadas para este acontecimento."}
              </p>
            </div>

            {relatedInv.length ? (
              <div className="border border-line p-4">
                <div className="label text-ink mb-3">FATО · INVESTIGAÇÕES</div>
                <ul className="space-y-3">
                  {relatedInv.map((i) => (
                    <li key={i.id}>
                      <Link href={`/fato/${i.id}`} className="group block">
                        <span className="label tnum text-muted">{i.ref}</span>
                        <span className="block headline text-[15px] mt-1 text-ink group-hover:underline-grow">
                          {i.title}
                        </span>
                      </Link>
                    </li>
                  ))}
                </ul>
              </div>
            ) : null}

            <div className="border border-line p-4">
              <div className="label text-ink mb-3">AUTORIA E TRANSPARÊNCIA</div>
              <div className="flex items-center gap-3">
                <Avatar name={article.author ?? article.source} size={40} />
                <div className="min-w-0">
                  <div className="text-sm font-semibold text-ink">{article.author ?? article.source}</div>
                  <div className="label text-muted mt-1">{article.language.toUpperCase()} · {article.source}</div>
                </div>
              </div>
              <div className="mt-4 flex flex-wrap gap-2">
                <Pill tone="outline">{article.category.replace("-", " ")}</Pill>
                <CategoryTag name={`ID ${article.id}`} />
              </div>
              <Transparency className="mt-4" />
            </div>
          </aside>
        </div>

        {related.length === 0 && !event ? (
          <div className="mt-12">
            <EmptyState
              eyebrow="ESTADO VAZIO"
              title="Sem conteúdo relacionado."
              hint="Assim que outras fontes cobrirem este acontecimento, as matérias relacionadas aparecem aqui."
            />
          </div>
        ) : null}

        <div className="h-10" />
      </div>
    </div>
  );
}
