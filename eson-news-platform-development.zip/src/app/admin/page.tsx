import type { Metadata } from "next";
import Link from "next/link";
import { cookies } from "next/headers";
import { AlertTriangle, Database, Layers, ListChecks, Newspaper, Puzzle, Rss, ShieldHalf, Users } from "lucide-react";
import { AdminLogin } from "@/components/admin-login";
import { AdminActions } from "@/components/admin-actions";
import { DemoBadge, EmptyState, SectionLabel, StatusChip, clock, timeAgo } from "@/components/ui";
import { CATEGORIES } from "@/lib/site";
import {
  getAdminArticles,
  getAdminInvestigations,
  getAdminReports,
  getAdminSources,
  getAdminStats,
  getAdminUsers,
} from "@/lib/data";

export const dynamic = "force-dynamic";

export const metadata: Metadata = { title: "Painel administrativo" };

const TABS = [
  { key: "dashboard", label: "Dashboard", icon: Puzzle },
  { key: "fontes", label: "Fontes", icon: Rss },
  { key: "categorias", label: "Categorias", icon: ListChecks },
  { key: "noticias", label: "Notícias", icon: Newspaper },
  { key: "investigacoes", label: "Investigações", icon: ShieldHalf },
  { key: "usuarios", label: "Usuários", icon: Users },
  { key: "denuncias", label: "Denúncias", icon: AlertTriangle },
  { key: "pipeline", label: "Fila & erros", icon: Database },
];

export default async function AdminPage({ searchParams }: { searchParams: Promise<{ tab?: string }> }) {
  const store = await cookies();
  const authed = store.get("eson_admin")?.value === "1";
  const { tab = "dashboard" } = await searchParams;

  if (!authed) {
    return (
      <div className="px-4 md:px-8 pt-12 pb-20">
        <div className="max-w-md mx-auto">
          <div className="rule pt-3 mb-6 flex items-center justify-between">
            <span className="label text-ink">/ADMIN</span>
            <span className="label text-muted">ACESSO RESTRITO</span>
          </div>
          <AdminLogin />
          <p className="label text-muted mt-6 leading-[1.8]">
            Autenticação verificada no servidor. Nenhuma credencial é exposta ao navegador e nenhuma chave de API
            é executada no cliente.
          </p>
        </div>
      </div>
    );
  }

  const [stats, sourceList, articleList, investigationList, userList, reportList] = await Promise.all([
    getAdminStats(),
    getAdminSources(),
    getAdminArticles(24),
    getAdminInvestigations(),
    getAdminUsers(),
    getAdminReports(),
  ]);

  const active = TABS.some((t) => t.key === tab) ? tab : "dashboard";

  return (
    <div className="px-4 md:px-8">
      <div className="max-w-[1400px] mx-auto">
        <header className="pt-8 md:pt-10">
          <div className="rule pt-3 flex flex-wrap items-center justify-between gap-3">
            <span className="label text-ink flex items-center gap-2">
              <ShieldHalf size={13} /> PAINEL ADMINISTRATIVO
            </span>
            <span className="label text-muted">SESSÃO AUTENTICADA · <Link href="/api/admin/logout" className="underline underline-offset-4">SAIR</Link></span>
          </div>
          <h1 className="display-lg text-ink mt-5">Operação Eson News</h1>
        </header>

        <nav className="mt-6 flex flex-wrap gap-2 border-t border-line pt-4">
          {TABS.map((t) => (
            <Link
              key={t.key}
              href={`/admin?tab=${t.key}`}
              className="label px-3.5 py-2.5 border inline-flex items-center gap-2 transition-colors"
              style={
                active === t.key
                  ? { background: "var(--ink)", color: "var(--paper)", borderColor: "var(--ink)" }
                  : { borderColor: "var(--line)", color: "var(--muted)" }
              }
            >
              <t.icon size={13} />
              {t.label}
            </Link>
          ))}
        </nav>

        <div className="pt-8 pb-16">
          {/* ------------------------------------------------ dashboard */}
          {active === "dashboard" ? (
            <section>
              <SectionLabel n="01" right="tempo real">INDICADORES</SectionLabel>
              <div className="grid grid-cols-2 md:grid-cols-5 gap-px mt-5 bg-[var(--line)] border border-[var(--line)]">
                {[
                  ["NOTÍCIAS COLETADAS", stats.collected],
                  ["NOTÍCIAS PUBLICADAS", stats.published],
                  ["ACONTECIMENTOS ATIVOS", stats.activeEvents],
                  ["INVESTIGAÇÕES FATO", stats.investigations],
                  ["USUÁRIOS", stats.users],
                  ["COMENTÁRIOS", stats.comments],
                  ["DENÚNCIAS ABERTAS", stats.openReports],
                  ["FONTES", stats.sources],
                  ["ERROS DE API", stats.apiErrors],
                  ["FILA DE PROCESSAMENTO", stats.queue],
                ].map(([k, v]) => (
                  <div key={k as string} className="bg-panel p-4">
                    <div className="label text-muted" style={{ fontSize: 9.5 }}>
                      {k}
                    </div>
                    <div
                      className="tnum mt-2"
                      style={{
                        fontSize: 34,
                        letterSpacing: "-0.04em",
                        color: String(k).includes("ERROS") && Number(v) > 0 ? "var(--wire)" : "var(--ink)",
                      }}
                    >
                      {v}
                    </div>
                  </div>
                ))}
              </div>

              <div className="mt-6 flex flex-wrap gap-3">
                <AdminActions actions={[{ label: "EXECUTAR COLETA AGORA", action: "collect" }]} />
                <DemoBadge className="self-center" />
              </div>

              <div className="mt-10 grid lg:grid-cols-2 gap-8">
                <div>
                  <SectionLabel n="02" right="últimas execuções">PIPELINE DE COLETA</SectionLabel>
                  <ul className="mt-4 divide-y divide-line">
                    {stats.runs.map((r) => (
                      <li key={r.id} className="py-3">
                        <div className="flex flex-wrap items-center gap-3">
                          <span
                            className="label px-2 py-1.5"
                            style={{
                              background: r.status === "erro" ? "rgba(209,52,42,.14)" : "var(--sunk)",
                              color: r.status === "erro" ? "var(--wire)" : "var(--ink2)",
                            }}
                          >
                            {r.adapter.toUpperCase()}
                          </span>
                          <span className="label text-muted tnum">{clock(r.createdAt)}</span>
                          <span className="label text-muted">
                            {r.fetched} coletadas · {r.grouped} agrupadas · {r.published} publicadas
                          </span>
                        </div>
                        <p className="text-sm text-ink2 mt-1.5 leading-relaxed">{r.message}</p>
                      </li>
                    ))}
                  </ul>
                </div>

                <div>
                  <SectionLabel n="03" right="moderação">FILA DE REVISÃO</SectionLabel>
                  <ul className="mt-4 divide-y divide-line">
                    {reportList.slice(0, 6).map(({ report, user }) => (
                      <li key={report.id} className="py-3">
                        <div className="flex flex-wrap items-center gap-3">
                          <span className="label text-ink">{report.targetType}</span>
                          <span className="label text-muted">#{report.targetId}</span>
                          <span className="label" style={{ color: report.status === "rejeitada" ? "var(--muted)" : "var(--heat)" }}>
                            {report.status}
                          </span>
                          <span className="label text-muted ml-auto">{timeAgo(report.createdAt)}</span>
                        </div>
                        <p className="text-sm text-ink2 mt-1.5">
                          {report.reason} — denunciado por {user?.name ?? "anônimo"}
                          {report.detail ? ` · ${report.detail}` : ""}
                        </p>
                      </li>
                    ))}
                  </ul>
                  <div className="mt-4 border border-line p-4">
                    <div className="label text-ink mb-2">REGRAS DE MODERAÇÃO ATIVAS</div>
                    <p className="text-sm text-ink2 leading-relaxed">
                      Detecção de spam, flood, discurso abusivo, ameaças, links suspeitos, manipulação, conteúdo
                      ilegal e contas automatizadas. Nenhum conteúdo é removido automaticamente por discordar de
                      uma opinião — toda remoção passa por revisão humana.
                    </p>
                  </div>
                </div>
              </div>
            </section>
          ) : null}

          {/* ------------------------------------------------ fontes */}
          {active === "fontes" ? (
            <section>
              <SectionLabel n="01" right={`${sourceList.length} fontes`}>FONTES CONECTADAS</SectionLabel>
              <div className="mt-5 overflow-x-auto">
                <table className="w-full border-collapse text-left min-w-[720px]">
                  <thead>
                    <tr className="border-b border-line">
                      {["FONTE", "DOMÍNIO", "TIPO", "IDIOMA", "PAÍS", "STATUS", ""].map((h) => (
                        <th key={h} className="label text-muted py-3 pr-4 font-medium">
                          {h}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {sourceList.map((s) => (
                      <tr key={s.id} className="border-b border-line">
                        <td className="py-3 pr-4 text-sm text-ink">{s.name}</td>
                        <td className="py-3 pr-4 text-sm text-ink2 break-all">{s.domain}</td>
                        <td className="py-3 pr-4 label text-muted">{s.type}</td>
                        <td className="py-3 pr-4 label text-muted">{s.language}</td>
                        <td className="py-3 pr-4 text-sm text-ink2">{s.country ?? "—"}</td>
                        <td className="py-3 pr-4">
                          <span className="label" style={{ color: s.active ? "#3f9c4d" : "var(--wire)" }}>
                            {s.active ? "ATIVA" : "PAUSADA"}
                          </span>
                        </td>
                        <td className="py-3 pr-4">
                          <AdminActions
                            actions={[{ label: s.active ? "PAUSAR" : "ATIVAR", action: "toggle_source", id: s.id }]}
                          />
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              <div className="mt-5 flex flex-wrap gap-3">
                <AdminActions actions={[{ label: "+ ADICIONAR FONTE", action: "add_source" }]} />
                <span className="label text-muted self-center">
                  Novas fontes entram sem alterar a estrutura do projeto: cada adaptador implementa a mesma
                  interface de normalização.
                </span>
              </div>
            </section>
          ) : null}

          {/* ------------------------------------------------ categorias */}
          {active === "categorias" ? (
            <section>
              <SectionLabel n="01" right={`${CATEGORIES.length} categorias`}>CATEGORIAS</SectionLabel>
              <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6 mt-5">
                {CATEGORIES.map((c) => (
                  <div key={c.slug} className="border border-line bg-panel p-4">
                    <div className="flex items-center justify-between">
                      <span className="headline text-[17px] text-ink">{c.name}</span>
                      <span className="label text-muted">/{c.slug}</span>
                    </div>
                    <p className="text-[13px] text-muted mt-2 leading-relaxed">{c.blurb}</p>
                    <div className="mt-3 flex flex-wrap gap-2">
                      {c.sub.map((s) => (
                        <span key={s} className="label px-2 py-1.5 bg-sunk text-ink2">
                          {s}
                        </span>
                      ))}
                    </div>
                    <div className="mt-4">
                      <AdminActions actions={[{ label: "EDITAR", action: "edit_category", id: c.slug }]} />
                    </div>
                  </div>
                ))}
              </div>
            </section>
          ) : null}

          {/* ------------------------------------------------ notícias */}
          {active === "noticias" ? (
            <section>
              <SectionLabel n="01" right={`${articleList.length} publicações`}>GERENCIAR NOTÍCIAS</SectionLabel>
              <div className="mt-5 overflow-x-auto">
                <table className="w-full border-collapse text-left min-w-[860px]">
                  <thead>
                    <tr className="border-b border-line">
                      {["#", "TÍTULO", "FONTE", "CATEGORIA", "PUBLICADO", "FLAGS", "AÇÕES"].map((h) => (
                        <th key={h} className="label text-muted py-3 pr-4 font-medium">
                          {h}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {articleList.map((a) => (
                      <tr key={a.id} className="border-b border-line align-top">
                        <td className="py-3 pr-4 tnum text-sm text-muted">{a.id}</td>
                        <td className="py-3 pr-4 text-sm text-ink max-w-[360px]">
                          <Link href={`/noticia/${a.id}`} className="hover:underline underline-offset-4 decoration-dotted">
                            {a.title}
                          </Link>
                        </td>
                        <td className="py-3 pr-4 text-sm text-ink2">{a.source}</td>
                        <td className="py-3 pr-4 label text-muted">{a.category}</td>
                        <td className="py-3 pr-4 tnum text-sm text-ink2">{clock(a.publishedAt)}</td>
                        <td className="py-3 pr-4">
                          <div className="flex flex-wrap gap-1.5">
                            {a.isFeatured ? <span className="label px-2 py-1 bg-sunk" style={{ color: "var(--heat)" }}>DESTAQUE</span> : null}
                            {a.isHidden ? (
                              <span className="label px-2 py-1" style={{ background: "rgba(209,52,42,.14)", color: "var(--wire)" }}>
                                OCULTA
                              </span>
                            ) : null}
                            {a.demo ? <span className="label px-2 py-1 bg-sunk text-muted">DEMO</span> : null}
                          </div>
                        </td>
                        <td className="py-3 pr-4">
                          <AdminActions
                            actions={[
                              { label: "DESTACAR", action: "feature_article", id: a.id },
                              { label: a.isHidden ? "MOSTRAR" : "OCULTAR", action: "hide_article", id: a.id },
                            ]}
                          />
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </section>
          ) : null}

          {/* ------------------------------------------------ investigações */}
          {active === "investigacoes" ? (
            <section>
              <SectionLabel n="01" right="revisão editorial">INVESTIGAÇÕES FATО</SectionLabel>
              <div className="mt-5 space-y-4">
                {investigationList.length ? (
                  investigationList.map((i) => (
                    <div key={i.id} className="border border-line bg-panel p-4 flex flex-wrap gap-4 items-start">
                      <div className="min-w-0 flex-1">
                        <div className="flex flex-wrap items-center gap-3">
                          <span className="label tnum text-muted">{i.ref}</span>
                          <span className="label" style={{ color: "var(--wire)" }}>
                            {i.category.toUpperCase()}
                          </span>
                          <span className="label text-muted">v{(i.versions as unknown[] | null)?.length ?? 1}</span>
                          <span className="label text-muted">{i.sourcesAnalyzed} fontes</span>
                        </div>
                        <Link href={`/fato/${i.id}`} className="headline text-[17px] text-ink mt-2 block hover:underline-grow">
                          {i.title}
                        </Link>
                        <p className="text-sm text-ink2 mt-1.5 leading-relaxed">{i.summary}</p>
                      </div>
                      <div className="flex flex-col gap-2 items-end">
                        <span
                          className="label px-2 py-1.5"
                          style={{
                            background: i.status === "atualizada" ? "rgba(63,156,77,.14)" : "var(--sunk)",
                            color: i.status === "atualizada" ? "#3f9c4d" : "var(--ink2)",
                          }}
                        >
                          {i.status === "atualizada" ? "ATUALIZADA" : "ABERTA"}
                        </span>
                        <AdminActions
                          actions={[
                            { label: "REVISAR", action: "review_investigation", id: i.id },
                            { label: "PUBLICAR", action: "publish_investigation", id: i.id },
                          ]}
                        />
                      </div>
                    </div>
                  ))
                ) : (
                  <EmptyState eyebrow="INVESTIGAÇÕES" title="Nenhuma investigação na fila." />
                )}
              </div>
            </section>
          ) : null}

          {/* ------------------------------------------------ usuários */}
          {active === "usuarios" ? (
            <section>
              <SectionLabel n="01" right={`${userList.length} contas`}>USUÁRIOS</SectionLabel>
              <div className="mt-5 overflow-x-auto">
                <table className="w-full border-collapse text-left min-w-[720px]">
                  <thead>
                    <tr className="border-b border-line">
                      {["NOME", "USUÁRIO", "PAPEL", "REPUTAÇÃO", "CADASTRO", "AÇÕES"].map((h) => (
                        <th key={h} className="label text-muted py-3 pr-4 font-medium">
                          {h}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {userList.map((u) => (
                      <tr key={u.id} className="border-b border-line">
                        <td className="py-3 pr-4 text-sm text-ink">{u.name}</td>
                        <td className="py-3 pr-4 text-sm text-ink2">@{u.username}</td>
                        <td className="py-3 pr-4 label text-muted">{u.role}</td>
                        <td className="py-3 pr-4 tnum text-sm text-ink">{u.reputation}</td>
                        <td className="py-3 pr-4 text-sm text-ink2">{timeAgo(u.createdAt)}</td>
                        <td className="py-3 pr-4">
                          <AdminActions
                            actions={[
                              { label: "SILENCIAR", action: "mute_user", id: u.id },
                              { label: "SUSPENDER", action: "suspend_user", id: u.id },
                            ]}
                          />
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </section>
          ) : null}

          {/* ------------------------------------------------ denúncias */}
          {active === "denuncias" ? (
            <section>
              <SectionLabel n="01" right={`${reportList.length} registros`}>DENÚNCIAS</SectionLabel>
              {reportList.length ? (
                <div className="mt-5 space-y-4">
                  {reportList.map(({ report, user }) => (
                    <div key={report.id} className="border border-line bg-panel p-4 flex flex-wrap gap-4 items-start">
                      <div className="min-w-0 flex-1">
                        <div className="flex flex-wrap items-center gap-3">
                          <span className="label" style={{ color: "var(--ink)" }}>
                            {report.targetType} #{report.targetId}
                          </span>
                          <span className="label text-muted">{report.reason}</span>
                          <span className="label text-muted">{timeAgo(report.createdAt)}</span>
                        </div>
                        <p className="text-sm text-ink2 mt-2 leading-relaxed">
                          {report.detail ?? "Sem detalhes informados."}
                        </p>
                        <p className="label text-muted mt-2">DENUNCIADO POR {user?.name ?? "anônimo"}</p>
                      </div>
                      <div className="flex flex-col gap-2 items-end">
                        <span
                          className="label px-2 py-1.5"
                          style={{
                            background:
                              report.status === "aberta"
                                ? "rgba(226,122,26,.14)"
                                : report.status === "rejeitada"
                                  ? "var(--sunk)"
                                  : "rgba(63,156,77,.14)",
                            color:
                              report.status === "aberta"
                                ? "var(--heat)"
                                : report.status === "rejeitada"
                                  ? "var(--muted)"
                                  : "#3f9c4d",
                          }}
                        >
                          {report.status.toUpperCase()}
                        </span>
                        <AdminActions
                          actions={[
                            { label: "APROVAR", action: "approve_report", id: report.id },
                            { label: "REJEITAR", action: "reject_report", id: report.id },
                          ]}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="mt-5">
                  <EmptyState eyebrow="DENÚNCIAS" title="Nenhuma denúncia aberta." hint="A fila de moderação está limpa." />
                </div>
              )}
            </section>
          ) : null}

          {/* ------------------------------------------------ pipeline */}
          {active === "pipeline" ? (
            <section>
              <SectionLabel n="01" right="integrações">ADAPTADORES E FILA</SectionLabel>
              <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6 mt-5">
                {[
                  ["GDELT", "descoberta", "Localiza cobertura mundial. Não é tratado como prova de veracidade."],
                  ["NEWSAPI", "cobertura", "Metadados de veículos parceiros, com normalização de idioma e domínio."],
                  ["RSS", "feeds", "Título, data, trecho permitido e link para o original."],
                  ["FONTES OFICIAIS", "primárias", "Documentos, atas e dados abertos de órgãos públicos."],
                ].map(([name, kind, desc]) => (
                  <div key={name} className="border-t border-line pt-4">
                    <div className="flex items-center justify-between">
                      <span className="label text-ink">{name}</span>
                      <span className="label" style={{ color: "var(--heat)" }}>
                        {kind}
                      </span>
                    </div>
                    <p className="text-[13px] text-muted mt-2 leading-relaxed">{desc}</p>
                  </div>
                ))}
              </div>

              <div className="mt-8 grid lg:grid-cols-2 gap-8">
                <div>
                  <SectionLabel n="02" right="erros recentes">REGISTRO DE EXECUÇÃO</SectionLabel>
                  <ul className="mt-4 divide-y divide-line">
                    {stats.runs.map((r) => (
                      <li key={r.id} className="py-3">
                        <div className="flex items-center gap-3">
                          <Layers size={13} className={r.status === "erro" ? "text-ink" : "text-muted"} />
                          <span className="label text-ink">{r.adapter}</span>
                          <span className="label" style={{ color: r.status === "erro" ? "var(--wire)" : "#3f9c4d" }}>
                            {r.status}
                          </span>
                          <span className="label text-muted ml-auto tnum">{timeAgo(r.createdAt)}</span>
                        </div>
                        <p className="text-sm text-ink2 mt-1.5">{r.message}</p>
                      </li>
                    ))}
                  </ul>
                </div>
                <div>
                  <SectionLabel n="03" right="limites ativos">SEGURANÇA</SectionLabel>
                  <ul className="mt-4 space-y-2 text-sm text-ink2">
                    {[
                      "Rate limiting por IP nas rotas de escrita (comentários, salvos, investigação).",
                      "Validação de entrada e limites de tamanho de texto em toda mutação.",
                      "Chaves de API lidas apenas no servidor; nenhum segredo no bundle do cliente.",
                      "Rota administrativa protegida por sessão verificada no servidor.",
                      "Proteção anti-spam: bloqueio temporário por volume de publicações.",
                      "Credenciais de terceiros fora do repositório, em variáveis de ambiente.",
                    ].map((t) => (
                      <li key={t} className="flex gap-3 border-t border-line pt-2">
                        <span className="mt-2 h-1.5 w-1.5 shrink-0" style={{ background: "var(--cyano)" }} />
                        {t}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </section>
          ) : null}
        </div>
      </div>
    </div>
  );
}
