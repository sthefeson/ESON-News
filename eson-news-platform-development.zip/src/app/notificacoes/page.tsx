import type { Metadata } from "next";
import Link from "next/link";
import { BellRing, Settings2 } from "lucide-react";
import { Avatar, DemoBadge, EmptyState, SectionLabel, timeAgo } from "@/components/ui";
import { DEMO_USER_ID, getCurrentUser, getNotifications } from "@/lib/data";

export const dynamic = "force-dynamic";

export const metadata: Metadata = { title: "Notificações" };

const KIND: Record<string, { icon: string; label: string; color: string }> = {
  atualizacao: { icon: "📈", label: "INVESTIGAÇÃO", color: "var(--heat)" },
  acontecimento: { icon: "🔴", label: "ACONTECIMENTO", color: "var(--wire)" },
  resposta: { icon: "💬", label: "RESPOSTA", color: "var(--cyano)" },
  mencao: { icon: "@", label: "MENÇÃO", color: "var(--ink)" },
  relevante: { icon: "⭐", label: "RELEVANTE", color: "var(--heat)" },
};

const SETTINGS = [
  { k: "noticias", label: "Notícias relevantes", hint: "acontecimentos que atingem o limiar do Radar" },
  { k: "investigacao", label: "Atualização de investigação salva", hint: "nova versão de uma FATО acompanhada" },
  { k: "resposta", label: "Resposta ao seu comentário", hint: "respostas diretas na Praça Global" },
  { k: "mencao", label: "Menção", hint: "quando seu nome é citado" },
  { k: "acontecimento", label: "Nova informação em acontecimento acompanhado", hint: "fonte nova no agrupamento" },
];

export default async function NotificationsPage() {
  const [user, list] = await Promise.all([getCurrentUser(), getNotifications(DEMO_USER_ID)]);

  return (
    <div className="px-4 md:px-8">
      <div className="max-w-[1400px] mx-auto">
        <header className="pt-8 md:pt-12">
          <div className="rule pt-3 flex items-center justify-between">
            <span className="label text-ink">NOTIFICAÇÕES</span>
            <DemoBadge />
          </div>
          <div className="grid lg:grid-cols-[1fr_auto] items-end gap-6 mt-5">
            <div>
              <h1 className="display-xl text-ink">O que mudou desde a sua última visita.</h1>
              <div className="flex items-center gap-3 mt-5">
                <Avatar name={user?.name ?? "Leitor"} size={40} />
                <div>
                  <div className="text-sm font-semibold text-ink">{user?.name ?? "Leitor"}</div>
                  <div className="label text-muted mt-1">@{user?.username ?? "leitor"}</div>
                </div>
              </div>
            </div>
            <div className="lg:text-right">
              <div className="tnum" style={{ fontSize: 64, letterSpacing: "-0.05em" }}>
                {list.filter((n) => !n.read).length}
              </div>
              <div className="label text-muted mt-1">NÃO LIDAS</div>
            </div>
          </div>
        </header>

        <div className="grid lg:grid-cols-[1.4fr_1fr] gap-10 pt-10 pb-14">
          <section>
            <SectionLabel n="01" right={`${list.length} notificações`}>RECENTES</SectionLabel>

            {list.length ? (
              <ul className="mt-5 divide-y divide-line">
                {list.map((n) => {
                  const kind = KIND[n.type] ?? KIND.relevante;
                  return (
                    <li key={n.id} className="py-4 flex gap-4" style={{ opacity: n.read ? 0.62 : 1 }}>
                      <span
                        className="mt-1 grid place-items-center h-8 w-8 shrink-0"
                        style={{ background: "var(--sunk)", color: kind.color }}
                        aria-hidden
                      >
                        {kind.icon}
                      </span>
                      <div className="min-w-0 flex-1">
                        <div className="flex flex-wrap items-center gap-x-3 gap-y-1">
                          <span className="label" style={{ color: kind.color }}>
                            {kind.label}
                          </span>
                          <span className="label text-muted tnum">{timeAgo(n.createdAt)}</span>
                          {!n.read ? (
                            <span className="label px-2 py-1 text-white" style={{ background: "var(--wire)" }}>
                              NOVA
                            </span>
                          ) : null}
                        </div>
                        <div className="headline text-[16px] text-ink mt-1.5">{n.title}</div>
                        <p className="text-sm text-ink2 mt-1.5 leading-relaxed">{n.content}</p>
                      </div>
                    </li>
                  );
                })}
              </ul>
            ) : (
              <div className="mt-5">
                <EmptyState
                  eyebrow="ESTADO VAZIO"
                  title="Nenhuma notificação."
                  hint="Você será avisado quando uma investigação salva for atualizada ou quando um acontecimento acompanhado mudar."
                />
              </div>
            )}
          </section>

          <aside className="lg:border-l lg:border-line lg:pl-8">
            <SectionLabel n="02" right="individual">CONFIGURAR NOTIFICAÇÕES</SectionLabel>
            <ul className="mt-5 divide-y divide-line">
              {SETTINGS.map((s, i) => (
                <li key={s.k} className="py-4 flex items-start justify-between gap-4">
                  <div className="min-w-0">
                    <div className="text-[15px] text-ink font-medium">{s.label}</div>
                    <div className="text-xs text-muted mt-1 leading-relaxed">{s.hint}</div>
                  </div>
                  <label className="inline-flex items-center gap-2 shrink-0 cursor-pointer">
                    <input
                      type="checkbox"
                      defaultChecked={i < 4}
                      className="h-4 w-4 accent-[var(--wire)]"
                      aria-label={s.label}
                    />
                    <span className="label text-muted" style={{ fontSize: 9.5 }}>
                      {i < 4 ? "ON" : "OFF"}
                    </span>
                  </label>
                </li>
              ))}
            </ul>

            <div className="mt-6 border border-line p-4">
              <div className="flex items-center gap-2 mb-2">
                <Settings2 size={14} /> <span className="label">RESUMO</span>
              </div>
              <p className="text-sm text-ink2 leading-relaxed">
                Notificações são enviadas apenas para conteúdo salvo ou acompanhado por você. Nada é enviado por
                popularidade sozinha.
              </p>
            </div>

            <div className="mt-4 flex items-center gap-2 text-muted">
              <BellRing size={14} />
              <Link href="/perfil" className="label hover:text-ink transition-colors">
                VER PERFIL E REPUTAÇÃO
              </Link>
            </div>
          </aside>
        </div>
      </div>
    </div>
  );
}
