import Link from "next/link";
import { Compass, Home } from "lucide-react";

export default function NotFound() {
  return (
    <div className="px-4 md:px-8 pt-16 pb-24">
      <div className="max-w-3xl mx-auto text-center">
        <div className="rule pt-3 label text-muted mb-8">ERRO 404 · PÁGINA NÃO ENCONTRADA</div>
        <div
          className="tnum mx-auto"
          style={{ fontSize: "clamp(4rem, 16vw, 9rem)", lineHeight: 1, letterSpacing: "-0.05em", color: "var(--wire)" }}
        >
          404
        </div>
        <h1 className="display-lg text-ink mt-6">Este endereço não existe no Eson News.</h1>
        <p className="text-ink2 mt-4 leading-relaxed mx-auto" style={{ maxWidth: "56ch" }}>
          O link pode ter sido movido ou a matéria foi ocultada. Você pode voltar ao início ou explorar o que o
          Radar está acompanhando agora.
        </p>
        <div className="mt-8 flex flex-wrap gap-3 justify-center">
          <Link
            href="/"
            className="label px-5 py-3.5 text-white inline-flex items-center gap-2"
            style={{ background: "var(--wire)" }}
          >
            <Home size={14} /> VOLTAR AO INÍCIO
          </Link>
          <Link
            href="/explorar"
            className="label px-5 py-3.5 border border-line text-ink hover:border-ink transition-colors inline-flex items-center gap-2"
          >
            <Compass size={14} /> EXPLORAR
          </Link>
          <Link
            href="/pesquisa"
            className="label px-5 py-3.5 border border-line text-ink hover:border-ink transition-colors"
          >
            PESQUISAR
          </Link>
        </div>
      </div>
    </div>
  );
}
