import type { Metadata } from "next";
import Link from "next/link";
import { ArrowUpRight, Flag, Globe2, MessageSquare, Newspaper, ThumbsUp } from "lucide-react";
import { Discussion } from "@/components/discussion";
import { Avatar, DemoBadge, EmptyState, SectionLabel, timeAgo } from "@/components/ui";
import { COMMENT_TYPES, MODERATION_ACTIONS, MODERATION_RULE } from "@/lib/site";
import { getDiscussions, getInvestigations, getRecentComments } from "@/lib/data";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Praça Global",
  description: "Praça Global — converse sobre o que está acontecendo no mundo, com fontes e etiquetas claras.",
};

export default async function PracaPage() {
  const [discussions, posts, investigations] = await Promise.all([
    getDiscussions(12),
    getRecentComments(16),
    getInvestigations(4),
  ]);

  const hot = posts.slice(0, 6);
  const rest = posts.slice(6);

  return (
    <div>
      {/* hero */}
      <header className="relative border-b border-line">
        <div className="absolute inset-0">
          <img src="/images/praca.jpg" alt="" className="w-full h-full object-cover" />
          <div
            className="absolute inset-0"
            style={{
              background:
                "linear-gradient(to top, color-mix(in srgb, var(--paper) 94%, transparent), color-mix(in srgb, var(--paper) 55%, transparent))",
            }}
          />
        </div>
        <div className="relative px-4 md:px-8 py-12 md:py-16">
          <div className="max-w-[1400px] mx-auto">
            <div className="flex items-center gap-3">
              <Globe2 size={16} className="text-ink" />
              <span className="label text-ink">PRAÇA GLOBAL</span>
            </div>
            <h1 className="display-xl mt-4 text-ink max-w-3xl">
              Converse sobre o que está acontecendo no mundo.
            </h1>
            <p className="mt-4 text-ink2 measure leading-relaxed">
              Discussões vinculadas a notícias, acontecimentos e investigações FATО. Cada comentário pode ser
              marcado como opinião, fonte, pergunta, dado ou alegação — a etiqueta descreve o tipo de afirmação,
              nunca a sua verdade.
            </p>
            <div className="mt-5 flex flex-wrap gap-3">
              <Link
                href="#chat"
                className="label px-5 py-3.5 text-white"
                style={{ background: "var(--wire)" }}
              >
                ABRIR O CHAT GLOBAL
              </Link>
              <Link href="#discussoes" className="label px-5 py-3.5 border border-line text-ink hover:border-ink transition-colors">
                VER DISCUSSÕES
              </Link>
              <DemoBadge className="self-center" />
            </div>
          </div>
        </div>
      </header>

      <div className="px-4 md:px-8">
        <div className="max-w-[1400px] mx-auto">
          {/* ------------------------------------------------ chat */}
          <section id="chat" className="pt-12">
            <SectionLabel n="01" right="conversa em tempo real">AGORA NA PRAÇA</SectionLabel>

            <div className="grid lg:grid-cols-[1.35fr_1fr] gap-10 mt-6">
              <div>
                {hot.length ? (
                  <ul className="divide-y divide-line">
                    {hot.map(({ comment, user, article, investigation, event }) => (
                      <li key={comment.id} className="py-5">
                        <div className="flex gap-3">
                          <Avatar name={user?.name ?? "Leitor"} size={38} />
                          <div className="min-w-0 flex-1">
                            <div className="flex flex-wrap items-center gap-x-3 gap-y-1">
                              <span className="text-sm font-semibold text-ink">{user?.name ?? "Leitor"}</span>
                              <span className="label text-muted">@{user?.username ?? "leitor"}</span>
                              <span className="label text-muted tnum">{timeAgo(comment.createdAt)}</span>
                              <span className="label px-2 py-1 bg-sunk text-ink2">
                                {COMMENT_TYPES[comment.type]?.icon} {COMMENT_TYPES[comment.type]?.label}
                              </span>
                            </div>

                            <p className="text-[15.5px] text-ink2 leading-relaxed mt-2">{comment.content}</p>

                            {article || event || investigation ? (
                              <div className="mt-3 border-l-2 pl-3" style={{ borderColor: "var(--line)" }}>
                                <span className="label text-muted">CONTEXTO</span>
                                {article ? (
                                  <Link
                                    href={`/noticia/${article.id}`}
                                    className="group block mt-2 border border-line bg-panel p-3 hover:border-ink transition-colors"
                                  >
                                    <span className="label flex items-center justify-between gap-3">
                                      <span style={{ color: "var(--wire)" }}>📰 ESON NEWS</span>
                                      <span className="text-muted">{article.source}</span>
                                    </span>
                                    <span className="headline text-[15.5px] text-ink group-hover:underline-grow block mt-2">
                                      {article.title}
                                    </span>
                                    <span className="text-sm text-ink2 block mt-1.5 leading-relaxed line-clamp-2">
                                      {article.description}
                                    </span>
                                    <span
                                      className="label inline-flex items-center gap-1.5 mt-3"
                                      style={{ color: "var(--cyano)" }}
                                    >
                                      ABRIR ARTIGO →
                                    </span>
                                  </Link>
                                ) : null}
                                {event && !article ? (
                                  <Link href={`/acontecimento/${event.id}`} className="group block mt-1">
                                    <span className="text-sm text-ink group-hover:underline-grow">{event.title}</span>
                                    <span className="label text-muted block mt-1">
                                      acontecimento · {event.sourcesCount} fontes
                                    </span>
                                  </Link>
                                ) : null}
                                {investigation && !article && !event ? (
                                  <Link href={`/fato/${investigation.id}`} className="group block mt-1">
                                    <span className="text-sm text-ink group-hover:underline-grow">
                                      {investigation.title}
                                    </span>
                                    <span className="label text-muted block mt-1">{investigation.ref}</span>
                                  </Link>
                                ) : null}
                              </div>
                            ) : null}

                            <div className="mt-3 flex flex-wrap items-center gap-x-5 gap-y-2">
                              <button className="label inline-flex items-center gap-1.5 text-muted hover:text-ink transition-colors">
                                <ThumbsUp size={12} /> {comment.likes}
                              </button>
                              <button className="label inline-flex items-center gap-1.5 text-muted hover:text-ink transition-colors">
                                <MessageSquare size={12} /> RESPONDER
                              </button>
                              <button className="label inline-flex items-center gap-1.5 text-muted hover:text-ink transition-colors">
                                <Newspaper size={12} /> CITAR FONTE
                              </button>
                              <button className="label inline-flex items-center gap-1.5 text-muted hover:text-ink transition-colors">
                                <Flag size={12} /> DENUNCIAR
                              </button>
                            </div>
                          </div>
                        </div>
                      </li>
                    ))}
                  </ul>
                ) : (
                  <EmptyState
                    eyebrow="AGORA NA PRAÇA"
                    title="Nenhuma conversa no momento."
                    hint="Abra uma discussão a partir de uma notícia ou investigação para começar."
                  />
                )}
              </div>

              <aside className="lg:border-l lg:border-line lg:pl-8 space-y-8">
                <div className="border border-line bg-panel p-4">
                  <div className="label text-muted mb-3">ETIQUETAS DE AFIRMAÇÃO</div>
                  <ul className="space-y-2.5">
                    {Object.entries(COMMENT_TYPES).map(([key, meta]) => (
                      <li key={key} className="flex items-center justify-between border-t border-line pt-2.5">
                        <span className="text-sm text-ink2">
                          {meta.icon} {meta.label.charAt(0) + meta.label.slice(1).toLowerCase()}
                        </span>
                        <span className="label text-muted" style={{ fontSize: 9.5 }}>
                          {key === "fonte"
                            ? "link verificável"
                            : key === "dado"
                              ? "número com origem"
                              : key === "alegacao"
                                ? "sem evidência suficiente"
                                : key === "pergunta"
                                  ? "busca contexto"
                                  : "posição pessoal"}
                        </span>
                      </li>
                    ))}
                  </ul>
                  <p className="label text-muted mt-3 leading-[1.8]">
                    A etiqueta não determina automaticamente a verdade do comentário.
                  </p>
                </div>

                <div className="border border-line p-4">
                  <div className="label text-muted mb-3">INVESTIGAÇÕES EM DISCUSSÃO</div>
                  <ul className="space-y-4">
                    {investigations.map((i) => (
                      <li key={i.id}>
                        <Link href={`/fato/${i.id}`} className="group block">
                          <span className="label tnum text-muted">{i.ref}</span>
                          <span className="block headline text-[15px] mt-1 text-ink group-hover:underline-grow">
                            {i.title}
                          </span>
                        </Link>
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="border border-line p-4">
                  <div className="label text-muted mb-3">MODERAÇÃO</div>
                  <div className="flex flex-wrap gap-2 mb-3">
                    {MODERATION_ACTIONS.map((a) => (
                      <span key={a} className="label px-2 py-1.5 bg-sunk text-ink2">
                        {a}
                      </span>
                    ))}
                  </div>
                  <p className="text-sm text-ink2 leading-relaxed">{MODERATION_RULE}</p>
                </div>
              </aside>
            </div>
          </section>

          {/* ------------------------------------------ discussões */}
          <section id="discussoes" className="pt-14">
            <SectionLabel n="02" right={`${discussions.length} discussões`}>DISCUSSÕES VINCULADAS</SectionLabel>

            {discussions.length ? (
              <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6 mt-6">
                {discussions.map(({ discussion: d, author }) => (
                  <article key={d.id} className="border border-line bg-panel p-5 flex flex-col">
                    <div className="flex items-center justify-between gap-3">
                      <span className="label px-2 py-1.5 bg-sunk text-ink2">
                        {d.contextType === "fato" ? "FATО" : d.contextType === "noticia" ? "NOTÍCIA" : "ACONTECIMENTO"}
                      </span>
                      <span className="label" style={{ color: "var(--heat)" }}>
                        {d.heat} MOVIMENTO
                      </span>
                    </div>

                    <h3 className="headline text-[18px] mt-3 text-ink">{d.title}</h3>
                    <p className="text-sm text-ink2 mt-2 leading-relaxed flex-1">{d.contextText}</p>

                    <div className="mt-4 pt-3 border-t border-line flex items-center gap-3">
                      <Avatar name={author?.name ?? "Comunidade"} size={28} />
                      <div className="min-w-0">
                        <div className="label text-ink truncate">{author?.name ?? "Comunidade"}</div>
                        <div className="label text-muted mt-1">
                          {d.comments} comentários · {d.participants} participantes · {timeAgo(d.lastActivity)}
                        </div>
                      </div>
                    </div>
                  </article>
                ))}
              </div>
            ) : (
              <div className="mt-6">
                <EmptyState
                  eyebrow="DISCUSSÕES"
                  title="Nenhuma discussão aberta."
                  hint="Discussions nascem quando alguém comenta uma notícia ou investigação."
                />
              </div>
            )}
          </section>

          {/* ------------------------------------------ comentários */}
          {rest.length ? (
            <section className="pt-14">
              <SectionLabel n="03" right={`${rest.length} comentários recentes`}>FLUXO DA COMUNIDADE</SectionLabel>
              <div className="mt-6 grid sm:grid-cols-2 gap-x-10">
                {rest.map(({ comment, user }) => (
                  <div key={comment.id} className="py-4 border-b border-line flex gap-3">
                    <Avatar name={user?.name ?? "Leitor"} size={30} />
                    <div className="min-w-0">
                      <div className="flex flex-wrap items-center gap-x-3">
                        <span className="text-sm font-semibold text-ink">{user?.name ?? "Leitor"}</span>
                        <span className="label text-muted tnum">{timeAgo(comment.createdAt)}</span>
                        <span className="label text-muted">
                          {COMMENT_TYPES[comment.type]?.icon} {COMMENT_TYPES[comment.type]?.label}
                        </span>
                      </div>
                      <p className="text-sm text-ink2 leading-relaxed mt-1.5">{comment.content}</p>
                    </div>
                  </div>
                ))}
              </div>
            </section>
          ) : null}

          <section className="pt-14 pb-8">
            <SectionLabel n="04" right="escreva no fluxo">PARTICIPE</SectionLabel>
            <div className="mt-6 max-w-3xl">
              <Discussion comments={[]} scope={{ eventId: 1 }} heading="COMENTAR NA PRAÇA GLOBAL" />
            </div>
            <p className="label text-muted mt-4 inline-flex items-center gap-2">
              <ArrowUpRight size={13} /> Respostas e etiquetas aparecem no fluxo assim que forem publicadas.
            </p>
          </section>
        </div>
      </div>
    </div>
  );
}
