import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowUpRight } from "lucide-react";
import { EventCard, StoryCard } from "@/components/story";
import { Reveal } from "@/components/reveal";
import { DemoBadge, EmptyState, SectionLabel, Transparency } from "@/components/ui";
import { CATEGORIES } from "@/lib/site";
import { getArticles, getEvents, getInvestigations } from "@/lib/data";

export const dynamic = "force-dynamic";

const SLUGS = CATEGORIES.map((c) => c.slug);

export function generateStaticParams() {
  return SLUGS.map((slug) => ({ slug }));
}

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> {
  const { slug } = await params;
  const cat = CATEGORIES.find((c) => c.slug === slug);
  if (!cat) return { title: "Categoria" };
  return { title: cat.name, description: cat.blurb };
}

export default async function CategoryPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const cat = CATEGORIES.find((c) => c.slug === slug);
  if (!cat) notFound();

  const [events, articles, investigations] = await Promise.all([
    getEvents(5, cat.slug),
    getArticles({ category: cat.slug, limit: 14 }),
    getInvestigations(6),
  ]);

  const related = investigations.filter((i) => i.category === cat.slug);
  const lead = articles[0];
  const rest = articles.slice(1);

  return (
    <div className="px-4 md:px-8">
      <div className="max-w-[1400px] mx-auto">
        {/* header */}
        <header className="pt-8 md:pt-12">
          <div className="rule pt-3 flex items-center justify-between gap-4">
            <span className="label text-muted">CATEGORIA · {cat.slug.toUpperCase()}</span>
            <span className="label text-muted tnum">{articles.length} MATÉRIAS</span>
          </div>

          <div className="grid lg:grid-cols-[1fr_1fr] gap-6 items-end mt-5">
            <h1 className="display-xl text-ink">{cat.name}</h1>
            <p className="text-ink2 leading-relaxed lg:pb-3">{cat.blurb}</p>
          </div>

          <div className="mt-6 flex flex-wrap gap-2">
            {cat.sub.map((s) => (
              <Link
                key={s}
                href={`/pesquisa?q=${encodeURIComponent(s)}`}
                className="label px-3 py-2 border border-line text-ink2 hover:text-ink hover:border-ink transition-colors"
              >
                {s}
              </Link>
            ))}
          </div>
        </header>

        {/* lead */}
        {lead ? (
          <section className="pt-10">
            <SectionLabel n="01" right="última publicação">DESTAQUE DA CATEGORIA</SectionLabel>
            <div className="grid lg:grid-cols-[1.5fr_1fr] gap-8 lg:gap-12 mt-6">
              <StoryCard article={lead} variant="lead" cluster={lead.eventId ? events[0]?.sourcesCount : undefined} />
              <div className="lg:border-l lg:border-line lg:pl-10">
                <div className="label text-muted mb-4">ACONTECIMENTOS RELACIONADOS</div>
                {events.length ? (
                  <div>
                    {events.map((e, i) => (
                      <EventCard key={e.id} event={e} rank={i + 1} />
                    ))}
                  </div>
                ) : (
                  <p className="text-sm text-muted">
                    Nenhum acontecimento agrupado nesta pauta. O agrupamento exige cobertura de fontes distintas.
                  </p>
                )}
              </div>
            </div>
          </section>
        ) : (
          <section className="pt-10">
            <EmptyState
              eyebrow="ESTADO VAZIO"
              title={`Nenhuma matéria publicada em ${cat.name} ainda.`}
              hint="Quando o coletor encontrar cobertura nesta pauta, ela aparece aqui com as fontes agrupadas."
              action={
                <Link href="/" className="label px-4 py-3 text-white" style={{ background: "var(--wire)" }}>
                  VOLTAR AO INÍCIO
                </Link>
              }
            />
          </section>
        )}

        {/* grid */}
        {rest.length ? (
          <section className="pt-12">
            <SectionLabel n="02" right={`${rest.length} matérias`}>TODAS AS PUBLICAÇÕES</SectionLabel>
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-x-8 gap-y-10 mt-6">
              {rest.map((a, i) => (
                <Reveal key={a.id} delay={Math.min(i * 0.04, 0.3)}>
                  <StoryCard article={a} variant="card" />
                </Reveal>
              ))}
            </div>
          </section>
        ) : null}

        {/* investigations */}
        <section className="pt-14 pb-10">
          <SectionLabel n="03" right="FATО">INVESTIGAÇÕES DESTA PAUTA</SectionLabel>
          <div className="mt-6">
            {related.length ? (
              <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {related.map((inv) => (
                  <Link key={inv.id} href={`/fato/${inv.id}`} className="group border border-line bg-panel p-5">
                    <div className="flex items-center justify-between">
                      <span className="label tnum text-muted">{inv.ref}</span>
                      <span className="label" style={{ color: "var(--wire)" }}>
                        FATО
                      </span>
                    </div>
                    <h3 className="display-md mt-3 text-ink group-hover:underline-grow">{inv.title}</h3>
                    <p className="text-sm text-ink2 mt-2 line-clamp-3 leading-relaxed">{inv.summary}</p>
                    <span className="label mt-4 inline-flex items-center gap-1.5" style={{ color: "var(--cyano)" }}>
                      LER INVESTIGAÇÃO <ArrowUpRight size={13} />
                    </span>
                  </Link>
                ))}
              </div>
            ) : (
              <p className="text-sm text-muted measure">
                Nenhuma investigação FATO aberta nesta pauta. Você pode sugerir uma pergunta na Praça Global.
              </p>
            )}
          </div>

          <div className="mt-8 flex flex-wrap items-center gap-3">
            <DemoBadge />
            <Transparency />
          </div>
        </section>
      </div>
    </div>
  );
}
