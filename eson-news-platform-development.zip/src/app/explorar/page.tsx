import type { Metadata } from "next";
import Link from "next/link";
import { ArrowUpRight, Compass, Globe2, Radar, ShieldQuestion } from "lucide-react";
import { RadarPanel, type RadarItem } from "@/components/radar";
import { Reveal } from "@/components/reveal";
import { DemoBadge, SectionLabel } from "@/components/ui";
import { CATEGORIES } from "@/lib/site";
import { getEvents, getInvestigations } from "@/lib/data";

export const dynamic = "force-dynamic";

export const metadata: Metadata = { title: "Explorar" };

export default async function ExplorePage() {
  const [events, investigations] = await Promise.all([getEvents(6), getInvestigations(3)]);

  const radarItems: RadarItem[] = events.map((e) => ({
    id: e.id,
    title: e.title,
    category: e.category,
    importanceScore: e.importanceScore,
    sourcesCount: e.sourcesCount,
    growth: e.growth,
    reach: e.reach,
    velocity: e.velocity,
    updatesCount: e.updatesCount,
    lastUpdate: e.lastUpdate,
  }));

  return (
    <div className="px-4 md:px-8">
      <div className="max-w-[1400px] mx-auto">
        <header className="pt-8 md:pt-12">
          <div className="rule pt-3 flex items-center justify-between">
            <span className="label text-ink flex items-center gap-2">
              <Compass size={13} /> EXPLORAR
            </span>
            <DemoBadge />
          </div>
          <div className="grid lg:grid-cols-[1.2fr_1fr] gap-6 items-end mt-5">
            <h1 className="display-xl text-ink">Tudo o que o Eson está acompanhando.</h1>
            <p className="text-ink2 leading-relaxed lg:pb-3">
              Categorias, Radar Eson, investigações FATО e a Praça Global — em um único painel de navegação.
            </p>
          </div>
        </header>

        <section className="pt-10">
          <SectionLabel n="01" right={`${CATEGORIES.length} páginas próprias`}>CATEGORIAS</SectionLabel>
          <div className="grid sm:grid-cols-2 lg:grid-cols-5 gap-x-8 mt-4">
            {CATEGORIES.map((c, i) => (
              <Reveal key={c.slug} delay={i * 0.03}>
                <Link href={`/categoria/${c.slug}`} className="group block border-t border-line py-5">
                  <div className="flex items-baseline justify-between">
                    <span className="label tnum text-muted">{String(i + 1).padStart(2, "0")}</span>
                    <ArrowUpRight size={15} className="text-muted group-hover:text-ink transition-colors" />
                  </div>
                  <h3 className="headline text-[21px] mt-3 text-ink group-hover:underline-grow inline-block">
                    {c.name}
                  </h3>
                  <p className="text-[13px] text-muted mt-2 leading-relaxed">{c.blurb}</p>
                </Link>
              </Reveal>
            ))}
          </div>
        </section>

        <section className="pt-12">
          <SectionLabel n="02" right="indicador interno">RADAR ESON</SectionLabel>
          <div className="mt-6">
            <RadarPanel items={radarItems} />
          </div>
        </section>

        <section className="pt-12 pb-14 grid md:grid-cols-2 gap-6">
          <Link href="/fato" className="group border border-line bg-panel p-6">
            <ShieldQuestion size={18} className="text-ink" />
            <h2 className="display-lg mt-4 text-ink group-hover:underline-grow inline-block">FATО</h2>
            <p className="text-sm text-ink2 mt-3 leading-relaxed measure">
              Investigue antes de concluir: classificação explícita, evidências, linha do tempo e todas as fontes
              consultadas.
            </p>
            {investigations.length ? (
              <ul className="mt-4 space-y-2">
                {investigations.map((i) => (
                  <li key={i.id} className="label text-muted border-t border-line pt-2">
                    {i.ref} · {i.title.slice(0, 54)}
                  </li>
                ))}
              </ul>
            ) : null}
            <span className="label mt-4 inline-flex items-center gap-1.5" style={{ color: "var(--cyano)" }}>
              ABRIR FATО <ArrowUpRight size={13} />
            </span>
          </Link>

          <Link href="/praca" className="group border border-line bg-panel p-6">
            <Globe2 size={18} className="text-ink" />
            <h2 className="display-lg mt-4 text-ink group-hover:underline-grow inline-block">PRAÇA GLOBAL</h2>
            <p className="text-sm text-ink2 mt-3 leading-relaxed measure">
              Converse sobre o que está acontecendo no mundo com etiquetas que separam opinião, fonte, pergunta,
              dado e alegação.
            </p>
            <span className="label mt-4 inline-flex items-center gap-1.5" style={{ color: "var(--cyano)" }}>
              ENTRAR NA PRAÇA <ArrowUpRight size={13} />
            </span>
          </Link>

          <div className="md:col-span-2 flex items-center gap-3">
            <Radar size={15} className="text-ink" />
            <span className="label text-muted">
              Índices do Radar são sinais internos de organização — não medida de verdade.
            </span>
          </div>
        </section>
      </div>
    </div>
  );
}
