import type { Metadata } from "next";
import Link from "next/link";
import { ArrowUpRight, SearchX } from "lucide-react";
import { StoryCard } from "@/components/story";
import { DemoBadge, EmptyState, SectionLabel, timeAgo } from "@/components/ui";
import { searchAll } from "@/lib/data";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Pesquisa",
  description: "Pesquisa global no Eson News: notícias, acontecimentos, investigações FATО e discussões.",
};

type Tab = "tudo" | "noticias" | "fato" | "comunidade";

const TABS: { key: Tab; label: string }[] = [
  { key: "tudo", label: "Tudo" },
  { key: "noticias", label: "Notícias" },
  { key: "fato", label: "Fato" },
  { key: "comunidade", label: "Comunidade" },
];

export default async function SearchPage({
  searchParams,
}: {
  searchParams: Promise<{ q?: string; tab?: string }>;
}) {
  const { q = "", tab = "tudo" } = await searchParams;
  const results = await searchAll(q);
  const active = (TABS.some((t) => t.key === tab) ? tab : "tudo") as Tab;

  const total =
    results.articles.length + results.events.length + results.investigations.length + results.discussionsList.length;

  const counts: Record<Tab, number> = {
    tudo: total,
    noticias: results.articles.length + results.events.length,
    fato: results.investigations.length,
    comunidade: results.discussionsList.length,
  };

  return (
    <div className="px-4 md:px-8">
      <div className="max-w-[1400px] mx-auto">
        <header className="pt-8 md:pt-12">
          <div className="rule pt-3 flex items-center justify-between gap-4">
            <span className="label text-ink">PESQUISA GLOBAL</span>
            <DemoBadge />
          </div>

          <div className="grid lg:grid-cols-[1fr_auto] gap-6 items-end mt-5">
            <div>
              <h1 className="display-xl text-ink">{q ? `“${q}”` : "Pesquise no Eson News"}</h1>
              <p className="text-ink2 mt-3 measure leading-relaxed">
                A busca cobre notícias, acontecimentos agrupados, pessoas e organizações citadas, investigações
                FATО e discussões da Praça Global.
              </p>
            </div>
            <div className="lg:text-right">
              <div className="tnum text-ink" style={{ fontSize: 64, letterSpacing: "-0.05em" }}>
                {counts[active]}
              </div>
              <div className="label text-muted mt-1">RESULTADOS</div>
            </div>
          </div>

          <form action="/pesquisa" className="mt-6 flex gap-3" method="get">
            <input
              type="search"
              name="q"
              defaultValue={q}
              placeholder="Digite um assunto, país, organização ou pessoa"
              className="flex-1 h-12 px-4 bg-panel border border-line text-ink placeholder:text-muted outline-none focus:border-ink transition-colors text-[15px]"
            />
            <input type="hidden" name="tab" value={active} />
            <button className="label px-5 text-white" style={{ background: "var(--wire)" }}>
              BUSCAR
            </button>
          </form>

          <nav className="mt-5 flex flex-wrap gap-2 border-t border-line pt-4">
            {TABS.map((t) => (
              <Link
                key={t.key}
                href={`/pesquisa?q=${encodeURIComponent(q)}&tab=${t.key}`}
                className="label px-3.5 py-2.5 border transition-colors"
                style={
                  active === t.key
                    ? { background: "var(--ink)", color: "var(--paper)", borderColor: "var(--ink)" }
                    : { borderColor: "var(--line)", color: "var(--muted)" }
                }
              >
                {t.label} · {counts[t.key]}
              </Link>
            ))}
          </nav>
        </header>

        <div className="pt-10 pb-12">
          {total === 0 ? (
            <EmptyState
              eyebrow="SEM RESULTADOS"
              title={q ? `Nada encontrado para “${q}”.` : "Comece digitando uma pergunta."}
              hint={
                q
                  ? "Tente outro termo, o nome de uma organização ou o país. Você também pode abrir uma investigação FATО com essa pergunta."
                  : "A pesquisa varre notícias, acontecimentos, investigações e discussões."
              }
              action={
                <Link href="/fato" className="label px-4 py-3 text-white" style={{ background: "var(--wire)" }}>
                  INVESTIGAR COM O FATО
                </Link>
              }
            />
          ) : (
            <div className="space-y-12">
              {(active === "tudo" || active === "noticias") && (
                <section>
                  <SectionLabel n="01" right={`${results.articles.length + results.events.length} resultados`}>
                    NOTÍCIAS E ACONTECIMENTOS
                  </SectionLabel>

                  {results.events.length ? (
                    <div className="mt-5 space-y-4">
                      {results.events.map((e) => (
                        <Link
                          key={e.id}
                          href={`/acontecimento/${e.id}`}
                          className="group flex items-start gap-4 border border-line bg-panel p-4"
                        >
                          <span
                            className="tnum leading-none shrink-0"
                            style={{ fontSize: 34, color: "var(--heat)", letterSpacing: "-0.04em" }}
                          >
                            {e.importanceScore}
                          </span>
                          <span className="min-w-0">
                            <span className="label text-muted block">
                              ACONTECIMENTO · {e.sourcesCount} fontes · {timeAgo(e.updatedAt)}
                            </span>
                            <span className="headline text-[17px] text-ink group-hover:underline-grow block mt-1.5">
                              {e.title}
                            </span>
                            <span className="text-sm text-ink2 block mt-1.5 leading-relaxed">{e.summary}</span>
                          </span>
                        </Link>
                      ))}
                    </div>
                  ) : null}

                  {results.articles.length ? (
                    <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-x-8 gap-y-8 mt-6">
                      {results.articles.map((a) => (
                        <StoryCard key={a.id} article={a} variant="card" />
                      ))}
                    </div>
                  ) : results.events.length === 0 ? (
                    <p className="label text-muted mt-5">Nenhuma notícia encontrada.</p>
                  ) : null}
                </section>
              )}

              {(active === "tudo" || active === "fato") && (
                <section>
                  <SectionLabel n="02" right={`${results.investigations.length} investigações`}>FATО</SectionLabel>
                  {results.investigations.length ? (
                    <div className="mt-5 grid sm:grid-cols-2 gap-6">
                      {results.investigations.map((i) => (
                        <Link key={i.id} href={`/fato/${i.id}`} className="group border border-line bg-panel p-5">
                          <div className="flex items-center justify-between">
                            <span className="label tnum text-muted">{i.ref}</span>
                            <span className="label" style={{ color: "var(--wire)" }}>
                              FATО
                            </span>
                          </div>
                          <h3 className="display-md mt-3 text-ink group-hover:underline-grow">{i.title}</h3>
                          <p className="text-sm text-ink2 mt-2 leading-relaxed line-clamp-3">{i.summary}</p>
                          <span className="label mt-4 inline-flex items-center gap-1.5" style={{ color: "var(--cyano)" }}>
                            ABRIR <ArrowUpRight size={13} />
                          </span>
                        </Link>
                      ))}
                    </div>
                  ) : (
                    <p className="label text-muted mt-5">Nenhuma investigação encontrada.</p>
                  )}
                </section>
              )}

              {(active === "tudo" || active === "comunidade") && (
                <section>
                  <SectionLabel n="03" right={`${results.discussionsList.length} discussões`}>
                    COMUNIDADE
                  </SectionLabel>
                  {results.discussionsList.length ? (
                    <ul className="mt-5 divide-y divide-line">
                      {results.discussionsList.map(({ discussion: d, author }) => (
                        <li key={d.id}>
                          <Link href="/praca" className="group block py-4">
                            <span className="label text-muted">
                              {d.contextType} · {author?.name ?? "Comunidade"} · {timeAgo(d.lastActivity)}
                            </span>
                            <span className="headline text-[16px] text-ink group-hover:underline-grow block mt-1.5">
                              {d.title}
                            </span>
                            <span className="text-sm text-ink2 block mt-1">{d.contextText}</span>
                          </Link>
                        </li>
                      ))}
                    </ul>
                  ) : (
                    <p className="label text-muted mt-5">Nenhuma discussão encontrada.</p>
                  )}
                </section>
              )}
            </div>
          )}

          {q && total === 0 ? (
            <div className="mt-8 flex items-center gap-3 text-muted">
              <SearchX size={16} />
              <span className="label">A busca não encontra o que procura? O motor de investigação aceita perguntas completas.</span>
            </div>
          ) : null}
        </div>
      </div>
    </div>
  );
}
