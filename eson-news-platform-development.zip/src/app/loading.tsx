import { Skeleton } from "@/components/ui";

export default function Loading() {
  return (
    <div className="px-4 md:px-8" aria-busy="true" aria-live="polite">
      <div className="max-w-[1400px] mx-auto pt-8">
        <div className="rule pt-3 flex items-center justify-between">
          <Skeleton className="h-3 w-40" />
          <Skeleton className="h-3 w-24" />
        </div>

        <div className="grid lg:grid-cols-[1.5fr_1fr] gap-10 mt-6">
          <div>
            <Skeleton className="aspect-[4/3] w-full" />
            <Skeleton className="h-3 w-32 mt-4" />
            <Skeleton className="h-6 w-4/5 mt-3" />
          </div>
          <div>
            <Skeleton className="h-4 w-40" />
            <Skeleton className="h-14 w-full mt-4" />
            <Skeleton className="h-4 w-full mt-3" />
            <Skeleton className="h-4 w-5/6 mt-2" />
            <div className="grid grid-cols-2 gap-4 mt-6">
              <Skeleton className="h-14 w-full" />
              <Skeleton className="h-14 w-full" />
            </div>
            <Skeleton className="h-14 w-full mt-4" />
          </div>
        </div>

        <div className="rule pt-3 mt-14">
          <Skeleton className="h-3 w-32" />
        </div>
        <div className="grid lg:grid-cols-2 gap-8 mt-6">
          {Array.from({ length: 4 }).map((_, i) => (
            <div key={i} className="border border-line p-4">
              <Skeleton className="h-10 w-24" />
              <Skeleton className="h-5 w-4/5 mt-4" />
              <Skeleton className="h-3 w-full mt-4" />
              <Skeleton className="h-3 w-2/3 mt-2" />
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
