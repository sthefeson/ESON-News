import { count, eq } from "drizzle-orm";
import { db } from "@/db";
import { investigations } from "@/db/schema";
import { clientIp, jsonError, rateLimit, sanitizeText } from "@/lib/server";

/** ETAPA 01 do motor FATО: extrair assunto e hipótese da pergunta. */
function parseQuestion(question: string) {
  const clean = question.replace(/\s+/g, " ").trim();
  const subject = clean
    .replace(/^(é verdade que|o que realmente está acontecendo em|de onde surgiu o rumor|o que sabemos sobre|quais são as evidências de|existe prova de)\s*/i, "")
    .replace(/[?!.]+$/, "")
    .trim();
  const normalized = subject.length > 3 ? subject : clean;
  return {
    subject: normalized,
    title: `O que realmente sabemos sobre ${normalized.toLowerCase()}`,
    summary: `Investigação aberta a partir da pergunta “${clean}”. As etapas de busca, cruzamento e classificação estão em andamento: ainda não há evidência suficiente para classificar as afirmações.`,
  };
}

export async function POST(req: Request) {
  const ip = clientIp(req);
  const gate = rateLimit(`fato:${ip}`, 4, 300_000);
  if (!gate.ok) return jsonError("Aguarde alguns minutos antes de abrir outra investigação.", 429);

  let payload: Record<string, unknown>;
  try {
    payload = await req.json();
  } catch {
    return jsonError("Corpo inválido.");
  }

  const question = sanitizeText(payload.question, 300);
  if (question.length < 8) return jsonError("A pergunta precisa de pelo menos 8 caracteres.");
  if (question.length > 300) return jsonError("A pergunta excede 300 caracteres.");

  const parsed = parseQuestion(question);

  let seq = "000184";
  let row: { id: number } | undefined;
  try {
    const counted = await db.select({ n: count() }).from(investigations);
    seq = String(Number(counted[0]?.n ?? 0) + 184).padStart(6, "0");
    row = await insertInvestigation(seq, question, parsed);
  } catch (err) {
    console.error("[fato] falha ao abrir investigação:", err);
    const cause = (err as { cause?: unknown }).cause;
    const detail =
      cause instanceof Error
        ? cause.message
        : err instanceof Error
          ? err.message
          : String(err);
    return jsonError(`Não foi possível abrir a investigação agora. [${detail}]`, 500);
  }

  if (!row) return jsonError("Não foi possível abrir a investigação agora.", 500);
  return Response.json({ ok: true, id: row.id });
}

async function insertInvestigation(
  seq: string,
  question: string,
  parsed: { subject: string; title: string; summary: string },
) {
  const [created] = await db
    .insert(investigations)
    .values({
      ref: `FATО #${seq}`,
      question,
      title: parsed.title,
      summary: parsed.summary,
      status: "aberta",
      category: "geral",
      coverImage: "images/fato-cover.jpg",
      intro: `Esta investigação foi aberta a partir da pergunta “${question}”. A coleta de documentos e fontes está em andamento — até que haja evidência suficiente, nenhuma afirmação será classificada.`,
      confirmed: [],
      unconfirmed: [parsed.summary],
      contested: [],
      circulating: [],
      timeline: [{ at: "agora", text: "Investigação criada. Etapa 01 — entendimento da pergunta concluída." }],
      methodology: {
        fontes_analisadas: 0,
        tipos: {},
        documentos: 0,
        concordancias: 0,
        divergencias: 0,
        limitacoes:
          "Coleta em andamento. Não há base suficiente para concluir: as informações disponíveis ainda não permitem uma conclusão definitiva.",
      },
      rumor: {
        circulacao: "—",
        approx_fontes: 0,
        evolucao: [],
        onde: [],
        versoes: 0,
        evidencias_independentes: 0,
        confirmacao_oficial: "não localizada",
        status: "não confirmado",
      },
      versions: [{ v: 1, at: "agora", text: "Publicação inicial — investigação aberta." }],
      sourcesAnalyzed: 0,
    })
    .returning({ id: investigations.id });
  return created;
}
