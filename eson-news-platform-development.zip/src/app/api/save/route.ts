import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { savedItems } from "@/db/schema";
import { DEMO_USER_ID } from "@/lib/data";
import { clientIp, jsonError, rateLimit } from "@/lib/server";

const ALLOWED = ["noticia", "acontecimento", "fato", "discussao"];

export async function POST(req: Request) {
  const gate = rateLimit(`save:${clientIp(req)}`, 30, 60_000);
  if (!gate.ok) return jsonError("Muitas solicitações.", 429);

  let payload: Record<string, unknown>;
  try {
    payload = await req.json();
  } catch {
    return jsonError("Corpo inválido.");
  }

  const itemType = typeof payload.itemType === "string" ? payload.itemType : "";
  const itemId = Number(payload.itemId);
  if (!ALLOWED.includes(itemType) || !Number.isInteger(itemId) || itemId <= 0) {
    return jsonError("Item inválido.");
  }

  const key = and(eq(savedItems.userId, DEMO_USER_ID), eq(savedItems.itemType, itemType), eq(savedItems.itemId, itemId));

  if (payload.remove) {
    await db.delete(savedItems).where(key);
    return Response.json({ ok: true, saved: false });
  }

  const existing = await db.select({ id: savedItems.id }).from(savedItems).where(key).limit(1);
  if (existing.length) {
    await db.delete(savedItems).where(key);
    return Response.json({ ok: true, saved: false });
  }

  await db.insert(savedItems).values({ userId: DEMO_USER_ID, itemType, itemId });
  return Response.json({ ok: true, saved: true });
}
