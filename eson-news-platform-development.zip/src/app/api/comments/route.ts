import { eq } from "drizzle-orm";
import { db } from "@/db";
import { articles, comments, users } from "@/db/schema";
import { DEMO_USER_ID } from "@/lib/data";
import { clientIp, jsonError, rateLimit, sanitizeText } from "@/lib/server";

export async function POST(req: Request) {
  const ip = clientIp(req);
  const gate = rateLimit(`comment:${ip}`, 10, 60_000);
  if (!gate.ok) return jsonError("Muitas publicações em um minuto. Aguarde um instante.", 429);

  let payload: Record<string, unknown>;
  try {
    payload = await req.json();
  } catch {
    return jsonError("Corpo inválido.");
  }

  const content = sanitizeText(payload.content, 2000);
  const type = typeof payload.type === "string" ? payload.type : "opiniao";
  const allowedTypes = ["opiniao", "fonte", "pergunta", "dado", "alegacao"];
  if (!allowedTypes.includes(type)) return jsonError("Etiqueta inválida.");
  if (content.length < 3) return jsonError("Comentário muito curto.");
  if (content.length > 2000) return jsonError("Comentário acima do limite de 2000 caracteres.");

  const articleId = typeof payload.articleId === "number" ? payload.articleId : null;
  const eventId = typeof payload.eventId === "number" ? payload.eventId : null;
  const investigationId = typeof payload.investigationId === "number" ? payload.investigationId : null;

  if (articleId) {
    const [art] = await db.select({ id: articles.id }).from(articles).where(eq(articles.id, articleId)).limit(1);
    if (!art) return jsonError("Notícia inexistente.", 404);
  }

  const [user] = await db.select().from(users).where(eq(users.id, DEMO_USER_ID)).limit(1);
  if (!user) return jsonError("Sessão de demonstração indisponível.", 401);

  // proteção anti-spam: bloqueia sequência muito rápida de publicações
  const recent = await db
    .select({ createdAt: comments.createdAt })
    .from(comments)
    .where(eq(comments.userId, user.id))
    .limit(5);
  const last = recent[0]?.createdAt ? new Date(recent[0].createdAt).getTime() : 0;
  if (Date.now() - last < 15_000) return jsonError("Aguarde 15 segundos entre publicações.", 429);

  const [row] = await db
    .insert(comments)
    .values({
      userId: user.id,
      articleId,
      eventId,
      investigationId,
      content,
      type,
    })
    .returning({ id: comments.id });

  return Response.json({ ok: true, id: row.id });
}
