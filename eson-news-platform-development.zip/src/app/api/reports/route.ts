import { db } from "@/db";
import { reports } from "@/db/schema";
import { DEMO_USER_ID } from "@/lib/data";
import { clientIp, jsonError, rateLimit, sanitizeText } from "@/lib/server";

const REASONS = [
  "spam",
  "flood",
  "discurso_abusivo",
  "ameaca",
  "link_suspeito",
  "manipulacao",
  "conteudo_ilegal",
  "conta_automatizada",
  "conteudo_suspeito",
  "alegacao_sem_fonte",
  "divergencia_de_opiniao",
];

export async function POST(req: Request) {
  const gate = rateLimit(`report:${clientIp(req)}`, 8, 60_000);
  if (!gate.ok) return jsonError("Muitas denúncias em um minuto.", 429);

  let payload: Record<string, unknown>;
  try {
    payload = await req.json();
  } catch {
    return jsonError("Corpo inválido.");
  }

  const targetType = ["comentario", "usuario", "noticia", "discussao"].includes(String(payload.targetType))
    ? String(payload.targetType)
    : "";
  const targetId = Number(payload.targetId);
  const reason = REASONS.includes(String(payload.reason)) ? String(payload.reason) : "conteudo_suspeito";

  if (!targetType || !Number.isInteger(targetId) || targetId <= 0) return jsonError("Alvo inválido.");

  const [row] = await db
    .insert(reports)
    .values({
      userId: DEMO_USER_ID,
      targetType,
      targetId,
      reason,
      detail: sanitizeText(payload.detail, 500) || null,
      status: "aberta",
    })
    .returning({ id: reports.id });

  return Response.json({ ok: true, id: row.id, status: "aberta" });
}
