import { eq } from "drizzle-orm";
import { db } from "@/db";
import {
  articles,
  collectionRuns,
  events,
  investigations,
  reports,
  sources,
  users,
} from "@/db/schema";
import { clientIp, jsonError, rateLimit } from "@/lib/server";

async function isAdmin() {
  const { cookies } = await import("next/headers");
  const store = await cookies();
  return store.get("eson_admin")?.value === "1";
}

export async function POST(req: Request) {
  const gate = rateLimit(`admin:${clientIp(req)}`, 60, 60_000);
  if (!gate.ok) return jsonError("Muitas solicitações.", 429);
  if (!(await isAdmin())) return jsonError("Sessão administrativa inválida.", 401);

  let payload: Record<string, unknown>;
  try {
    payload = await req.json();
  } catch {
    return jsonError("Corpo inválido.");
  }

  const action = typeof payload.action === "string" ? payload.action : "";
  const id = Number(payload.id);
  const hasId = Number.isInteger(id) && id > 0;

  switch (action) {
    case "collect": {
      const [active] = await db
        .select({ domain: sources.domain })
        .from(sources)
        .where(eq(sources.active, true))
        .limit(1);
      const run = await db
        .insert(collectionRuns)
        .values({
          adapter: "manual",
          status: "ok",
          fetched: 0,
          grouped: 0,
          published: 0,
          message: `Coleta manual disparada pelo painel (${active?.domain ?? "sem fonte ativa"}). GDELT é usado apenas para descoberta de cobertura.`,
        })
        .returning({ id: collectionRuns.id });
      return Response.json({ ok: true, message: `Coleta #${run[0].id} enfileirada.`, id: run[0].id });
    }

    case "toggle_source": {
      if (!hasId) return jsonError("Fonte inválida.");
      const [row] = await db.select().from(sources).where(eq(sources.id, id)).limit(1);
      if (!row) return jsonError("Fonte não encontrada.", 404);
      await db.update(sources).set({ active: !row.active }).where(eq(sources.id, id));
      return Response.json({ ok: true, message: row.active ? "Fonte pausada." : "Fonte ativada." });
    }

    case "feature_article": {
      if (!hasId) return jsonError("Notícia inválida.");
      const [row] = await db.select().from(articles).where(eq(articles.id, id)).limit(1);
      if (!row) return jsonError("Notícia não encontrada.", 404);
      await db.update(articles).set({ isFeatured: !row.isFeatured }).where(eq(articles.id, id));
      return Response.json({ ok: true, message: row.isFeatured ? "Destaque removido." : "Notícia destacada." });
    }

    case "hide_article": {
      if (!hasId) return jsonError("Notícia inválida.");
      const [row] = await db.select().from(articles).where(eq(articles.id, id)).limit(1);
      if (!row) return jsonError("Notícia não encontrada.", 404);
      await db.update(articles).set({ isHidden: !row.isHidden }).where(eq(articles.id, id));
      return Response.json({ ok: true, message: row.isHidden ? "Notícia restaurada." : "Notícia ocultada." });
    }

    case "review_investigation": {
      if (!hasId) return jsonError("Investigação inválida.");
      await db.update(investigations).set({ status: "em_revisao", updatedAt: new Date() }).where(eq(investigations.id, id));
      return Response.json({ ok: true, message: "Investigação enviada para revisão editorial." });
    }

    case "publish_investigation": {
      if (!hasId) return jsonError("Investigação inválida.");
      await db
        .update(investigations)
        .set({ status: "publicada", updatedAt: new Date() })
        .where(eq(investigations.id, id));
      return Response.json({ ok: true, message: "Investigação publicada." });
    }

    case "mute_user":
    case "suspend_user": {
      if (!hasId) return jsonError("Usuário inválido.");
      const [row] = await db.select().from(users).where(eq(users.id, id)).limit(1);
      if (!row) return jsonError("Usuário não encontrado.", 404);
      const next = action === "mute_user" ? "silenciado" : "suspenso";
      await db.update(users).set({ role: next }).where(eq(users.id, id));
      return Response.json({ ok: true, message: `Usuário ${next}.` });
    }

    case "approve_report": {
      if (!hasId) return jsonError("Denúncia inválida.");
      await db.update(reports).set({ status: "aceita" }).where(eq(reports.id, id));
      return Response.json({ ok: true, message: "Denúncia aceita — revisão humana registrada." });
    }

    case "reject_report": {
      if (!hasId) return jsonError("Denúncia inválida.");
      await db.update(reports).set({ status: "rejeitada" }).where(eq(reports.id, id));
      return Response.json({ ok: true, message: "Denúncia rejeitada — conteúdo mantido." });
    }

    case "add_source":
      return Response.json({
        ok: true,
        message: "Formulário de nova fonte disponível: nome, domínio, tipo, idioma e adaptador.",
      });

    case "edit_category":
      return Response.json({
        ok: true,
        message: `Categoria ${String(payload.id)} em modo de edição (demonstração).`,
      });

    default:
      return jsonError("Ação desconhecida.", 400);
  }
}

export async function GET() {
  if (!(await isAdmin())) return jsonError("Sessão administrativa inválida.", 401);
  return Response.json({ ok: true });
}

// evita cache de respostas administrativas
export const dynamic = "force-dynamic";
