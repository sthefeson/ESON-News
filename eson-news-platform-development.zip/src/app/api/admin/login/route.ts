import { cookies } from "next/headers";
import { clientIp, jsonError, rateLimit, sanitizeText } from "@/lib/server";

export const ADMIN_COOKIE = "eson_admin";

export async function POST(req: Request) {
  const gate = rateLimit(`admin-login:${clientIp(req)}`, 5, 60_000);
  if (!gate.ok) return jsonError("Muitas tentativas. Aguarde um minuto.", 429);

  let payload: Record<string, unknown>;
  try {
    payload = await req.json();
  } catch {
    return jsonError("Corpo inválido.");
  }

  const password = sanitizeText(payload.password, 128);
  const expected = process.env.ADMIN_PASSWORD ?? "eson";
  if (!password || password !== expected) {
    return jsonError("Senha incorreta.", 401);
  }

  const store = await cookies();
  store.set(ADMIN_COOKIE, "1", {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    path: "/",
    maxAge: 60 * 60 * 8,
  });

  return Response.json({ ok: true });
}
