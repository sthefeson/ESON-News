import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowUpRight, Clock3, Layers } from "lucide-react";
import { Discussion } from "@/components/discussion";
import { SaveButton, ShareButton } from "@/components/actions";
import { ClusterCard, StoryCard } from "@/components/story";
import { DemoBadge, EmptyState, Meter, SectionLabel, StatusChip, Transparency, clock, timeAgo } from "@/components/ui";
import { radarBand } from "@/lib/site";
import {
  DEMO_USER_ID,
  getComments,
  getEvent,
  getEventCluster,
  getInvestigations,
  getReplies,
  getSaved,
} from "@/lib/data";

export const dynamic = "force-dynamic";

export async function generateMetadata({ params }: { params: Promise<{ id: string }> }): Promise<Metadata> {
  const { id } = await params;
  const event = await getEvent(Number(id));
  if (!event) return { title: "Acontecimento" };
  return { title: event.title, description: event.summary };
}

export default async function EventPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const event = await getEvent(Number(id));
  if (!event) notFound();

  const [cluster, comments, investigations, saved] = await Promise.all([
    getEventCluster(event.id),
    getComments({ eventId: event.id }),
    getInvestigations(8),
    getSaved(DEMO_USER_ID),
  ]);
  const replies = await getReplies(comments.map((c) => c.id));
  const repliesBy = new Map<number, typeof replies>();
  replies.forEach((r) => {
    const arr = repliesBy.get(r.commentId) ?? [];
    arr.push(r);
    repliesBy.set(r.commentId, arr);
  });

  const band = radarBand(event.importanceScore);
  const savedIds = new Set(saved.map((s) => `${s.itemType}:${s.itemId}`));
  const timeline = [...cluster].sort(
    (a, b) => new Date(a.article.publishedAt).getTime() - new Date(b.article.publishedAt).getTime(),
  );
  const relatedInv = investigations.filter((i) => i.category === event.category).slice(0, 3);
  const domains = Array.from(new Set(cluster.map((c) => c.sourceDomain ?? c.article.domain).filter(Boolean)));

  return (
    <div className="px-4 md:px-8">
      <div className="max-w-[1400px] mx-auto">
        <header className="pt-8 md:pt-12">
          <div className="rule pt-3 flex flex-wrap items-center justify-between gap-3">
            <span className="label text-muted">ACONTECIMENTO · {event.category.replace("-", " ")}</span>
            <span className="label text-muted">
              {event.isLive ? (
                <span className="inline-flex items-center gap-2" style={{ color: "var(--wire)" }}>
                  <span className="live-dot h-2 w-2 rounded-full inline-block" style={{ background: "var(--wire)" }} />
                  AO VIVO
                </span>
              ) : (
                `status: ${event.status}`
              )}
            </span>
          </div>

          <div className="grid lg:grid-cols-[1.4fr_1fr] gap-8 lg:gap-12 mt-6">
            <div>
              <div className="flex flex-wrap items-center gap-3 mb-4">
                <span className="label px-2 py-1.5" style={{ background: "var(--heat2)", color: "#101318" }}>
                  {band.cls} {band.label}
                </span>
                <span className="label text-muted">MESMO ACONTECIMENTO</span>
                <DemoBadge />
              </div>
              <h1 className="display-xl text-ink">{event.title}</h1>
              <p className="mt-5 text-[17px] leading-[1.7] text-ink2 measure">{event.summary}</p>

              <div className="mt-6 flex flex-wrap gap-3">
                <SaveButton itemType="acontecimento" itemId={event.id} initial={savedIds.has(`acontecimento:${event.id}`)} />
                <ShareButton title={event.title} text={event.summary} />
              </div>
            </div>

            <div className="lg:border-l lg:border-line lg:pl-10">
              <div className="flex items-end gap-4">
                <span className="tnum leading-none" style={{ fontSize: 96, letterSpacing: "-0.05em", color: band.color }}>
                  {event.importanceScore}
                </span>
                <div className="pb-3">
                  <div className="label" style={{ color: band.color }}>
                    {band.label}
                  </div>
                  <div className="label text-muted mt-1.5">INDICADOR INTERNO RADAR ESON</div>
                </div>
              </div>

              <dl className="mt-6 grid grid-cols-2 gap-x-6 gap-y-5 border-t border-line pt-5">
                {[
                  ["FONTES RELACIONADAS", event.sourcesCount],
                  ["DOMÍNIOS DISTINTOS", domains.length],
                  ["VELOCIDADE DE CRESCIMENTO", `${event.velocity}%`],
                  ["ALCANCE INTERNACIONAL", `${event.reach}%`],
                  ["ATUALIZAÇÕES RECENTES", event.updatesCount],
                  ["FONTES PRIMÁRIAS", event.primarySourceCount],
                ].map(([k, v]) => (
                  <div key={k as string}>
                    <dt className="label text-muted" style={{ fontSize: 9.5 }}>
                      {k}
                    </dt>
                    <dd className="tnum text-ink mt-1.5" style={{ fontSize: 17 }}>
                      {v}
                    </dd>
                  </div>
                ))}
              </dl>

              <div className="mt-5">
                <Meter value={event.importanceScore} color={band.color} />
              </div>
              <p className="label text-muted mt-3 leading-[1.8]">
                O Radar combina cobertura, atualização, diversidade de fontes e alcance. Não representa a verdade
                ou importância absoluta da notícia.
              </p>
            </div>
          </div>
        </header>

        <section className="pt-12">
          <SectionLabel n="01" right="agrupamento inteligente">COMO O ESON AGRUPOU ESTA HISTÓRIA</SectionLabel>
          <div className="mt-6 max-w-4xl">
            <ClusterCard
              event={{
                id: event.id,
                title: event.title,
                summary: event.summary,
                sourcesCount: event.sourcesCount,
                category: event.category,
                lastUpdate: event.lastUpdate,
              }}
              items={cluster.slice(0, 3).map((c) => ({
                id: c.article.id,
                title: c.article.title,
                source: c.article.source,
                domain: c.article.domain,
              }))}
            />
          </div>
        </section>

        <div className="grid lg:grid-cols-[minmax(0,1fr)_330px] gap-10 lg:gap-14 pt-12">
          <div className="min-w-0">
            <SectionLabel n="02" right={`${cluster.length} publicações`}>COBERTURA COMPLETA</SectionLabel>
            <div className="mt-4">
              {cluster.length ? (
                cluster.map((row) => (
                  <a
                    key={row.article.id}
                    href={row.article.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="group flex gap-4 py-4 border-b border-line"
                  >
                    <div className="min-w-0 flex-1">
                      <div className="flex flex-wrap items-center gap-3">
                        <span className="label" style={{ color: "var(--cyano)" }}>
                          {row.sourceName ?? row.article.source}
                        </span>
                        <span className="label text-muted tnum">{clock(row.article.publishedAt)}</span>
                        <span className="label text-muted">{row.sourceType ?? "—"}</span>
                      </div>
                      <h3 className="headline text-[16px] mt-2 text-ink group-hover:underline-grow inline">
                        {row.article.title}
                      </h3>
                      <p className="text-sm text-ink2 mt-1.5 leading-relaxed line-clamp-2">
                        {row.article.description}
                      </p>
                    </div>
                    <ArrowUpRight size={16} className="text-muted shrink-0 mt-1 group-hover:text-ink transition-colors" />
                  </a>
                ))
              ) : (
                <EmptyState
                  eyebrow="ESTADO VAZIO"
                  title="Nenhuma publicação agrupada."
                  hint="O agrupamento começa quando duas fontes independentes descrevem o mesmo fato."
                />
              )}
            </div>

            <SectionLabel n="03" right={`${timeline.length} registros`} className="mt-12">
              CRONOLOGIA
            </SectionLabel>
            <ol className="mt-5 border-l border-line pl-5 space-y-5">
              {timeline.map((row) => (
                <li key={row.article.id} className="relative">
                  <span
                    className="absolute -left-[26px] top-1.5 h-2 w-2 rounded-full"
                    style={{ background: "var(--heat)" }}
                  />
                  <div className="flex flex-wrap items-center gap-3">
                    <span className="label tnum text-muted">{clock(row.article.publishedAt)}</span>
                    <span className="label text-muted">{row.article.source}</span>
                    <span className="label text-muted tnum">{timeAgo(row.article.publishedAt)}</span>
                  </div>
                  <Link href={`/noticia/${row.article.id}`} className="group block mt-1.5">
                    <span className="text-[15.5px] text-ink2 group-hover:text-ink transition-colors">
                      {row.article.title}
                    </span>
                  </Link>
                </li>
              ))}
            </ol>

            <div className="mt-14">
              <Discussion
                comments={comments.map((c) => ({
                  ...c,
                  createdAt: c.createdAt as Date,
                  replies: (repliesBy.get(c.id) ?? []).map((r) => ({
                    id: r.id,
                    content: r.content,
                    type: r.type,
                    likes: r.likes,
                    createdAt: r.createdAt as Date,
                    user: r.user ? { name: r.user.name, username: r.user.username } : null,
                  })),
                }))}
                scope={{ eventId: event.id }}
                heading="DISCUSSÃO DO ACONTECIMENTO"
              />
            </div>
          </div>

          <aside className="lg:border-l lg:border-line lg:pl-8 space-y-8">
            <div className="border border-line p-4">
              <div className="flex items-center gap-2 mb-3">
                <Layers size={14} /> <span className="label">DOMÍNIOS ENVOLVIDOS</span>
              </div>
              <ul className="space-y-2">
                {domains.map((d) => (
                  <li key={d as string} className="text-sm text-ink2 border-t border-line pt-2 break-words">
                    {d}
                  </li>
                ))}
              </ul>
              <p className="label text-muted mt-3 leading-[1.8]">
                Fontes independentes são contadas por domínio e proprietário editorial, não por volume de posts.
              </p>
            </div>

            {relatedInv.length ? (
              <div className="border border-line p-4">
                <div className="flex items-center gap-2 mb-3">
                  <Clock3 size={14} /> <span className="label">FATО · INVESTIGAÇÕES</span>
                </div>
                <ul className="space-y-4">
                  {relatedInv.map((i) => (
                    <li key={i.id}>
                      <Link href={`/fato/${i.id}`} className="group block">
                        <span className="label tnum text-muted">{i.ref}</span>
                        <span className="block headline text-[15px] mt-1 text-ink group-hover:underline-grow">
                          {i.title}
                        </span>
                      </Link>
                    </li>
                  ))}
                </ul>
              </div>
            ) : null}

            <div className="border border-line p-4">
              <div className="label mb-3">CLASSIFICAÇÃO DAS AFIRMAÇÕES</div>
              <div className="flex flex-wrap gap-2">
                <StatusChip status="confirmado" />
                <StatusChip status="em_investigacao" />
                <StatusChip status="contradito" />
                <StatusChip status="nao_verificavel" />
              </div>
            </div>

            <Transparency />
          </aside>
        </div>

        <div className="h-10" />
      </div>
    </div>
  );
}
