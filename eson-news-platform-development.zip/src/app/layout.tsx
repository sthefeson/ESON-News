import type { Metadata } from "next";
import Link from "next/link";
import { Suspense } from "react";
import "./globals.css";
import { MobileNav, SiteHeader, WireRail } from "@/components/header";
import { DemoBadge, Transparency } from "@/components/ui";
import { CATEGORIES, SLOGAN } from "@/lib/site";
import { getLiveEvent, getUnreadCount, DEMO_USER_ID } from "@/lib/data";

export const metadata: Metadata = {
  title: {
    default: "ESON NEWS EN — O mundo em um só lugar.",
    template: "%s · ESON NEWS EN",
  },
  description:
    "ESON NEWS EN — plataforma global de notícias com Radar Eson, agrupamento inteligente de acontecimentos, investigações FATO e Praça Global.",
};

const THEME_SCRIPT = `
try {
  var s = localStorage.getItem('eson-theme');
  var d = s ? s === 'dark' : window.matchMedia('(prefers-color-scheme: dark)').matches;
  if (d) document.documentElement.classList.add('dark');
} catch (e) {}
`;

export default async function RootLayout({ children }: { children: React.ReactNode }) {
  const [live, unread] = await Promise.all([getLiveEvent(), getUnreadCount(DEMO_USER_ID)]);
  const radarIndex = live?.importanceScore ?? 0;

  return (
    <html lang="pt-BR" suppressHydrationWarning>
      <head>
        <script dangerouslySetInnerHTML={{ __html: THEME_SCRIPT }} />
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Archivo:wght@400;500;600;700;800&family=IBM+Plex+Mono:wght@400;500;600&family=Instrument+Serif:ital@0;1&display=swap"
          rel="stylesheet"
        />
      </head>
      <body className="grain min-h-screen">
        <WireRail radarIndex={radarIndex} />

        <div className="lg:pl-[72px]">
          <Suspense fallback={<div className="h-14 border-b border-line" />}>
            <SiteHeader unread={unread} />
          </Suspense>

          <main className="pb-28 md:pb-16">{children}</main>

          <footer className="border-t border-line bg-panel px-4 md:px-8 py-10">
            <div className="max-w-[1400px] mx-auto grid gap-8 md:grid-cols-[1.2fr_1fr_1fr]">
              <div>
                <span className="font-sans font-extrabold tracking-[-0.045em] text-ink" style={{ fontSize: 22 }}>
                  ESON<span style={{ color: "var(--wire)" }}>NEWS</span>
                </span>
                <p className="display-md mt-2" style={{ fontStyle: "italic" }}>
                  {SLOGAN}
                </p>
                <div className="mt-4">
                  <DemoBadge />
                </div>
                <Transparency className="mt-4 max-w-sm" />
              </div>

              <div>
                <div className="label text-muted mb-3">CATEGORIAS</div>
                <ul className="grid grid-cols-2 gap-y-1.5">
                  {CATEGORIES.map((c) => (
                    <li key={c.slug}>
                      <Link href={`/categoria/${c.slug}`} className="text-sm text-ink2 hover:text-ink transition-colors">
                        {c.name}
                      </Link>
                    </li>
                  ))}
                </ul>
              </div>

              <div>
                <div className="label text-muted mb-3">PLATAFORMA</div>
                <ul className="space-y-1.5 text-sm">
                  {[
                    ["Radar Eson", "/#radar"],
                    ["Investigações FATO", "/fato"],
                    ["Praça Global", "/praca"],
                    ["Pesquisa", "/pesquisa"],
                    ["Salvos", "/salvos"],
                    ["Notificações", "/notificacoes"],
                    ["Painel administrativo", "/admin"],
                  ].map(([label, href]) => (
                    <li key={label}>
                      <Link href={href} className="text-ink2 hover:text-ink transition-colors">
                        {label}
                      </Link>
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            <div className="max-w-[1400px] mx-auto mt-8 pt-5 border-t border-line flex flex-wrap gap-x-6 gap-y-2 justify-between">
              <span className="label text-muted">© {new Date().getFullYear()} ESON NEWS EN</span>
              <span className="label text-muted">
                Conteúdo sintetizado pelo Eson News a partir das fontes indicadas
              </span>
            </div>
          </footer>
        </div>

        <MobileNav />
      </body>
    </html>
  );
}
