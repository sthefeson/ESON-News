import type { Metadata } from "next";
import Link from "next/link";
import { Bookmark, BookmarkCheck } from "lucide-react";
import { DemoBadge, EmptyState, SectionLabel, timeAgo } from "@/components/ui";
import { DEMO_USER_ID, getSavedResolved } from "@/lib/data";

export const dynamic = "force-dynamic";

export const metadata: Metadata = { title: "Salvos" };

type Tab = "tudo" | "noticia" | "fato" | "discussao";

const TABS: { key: Tab; label: string }[] = [
  { key: "tudo", label: "Tudo" },
  { key: "noticia", label: "Notícias" },
  { key: "fato", label: "Fato" },
  { key: "discussao", label: "Discussões" },
];

const LABEL: Record<string, string> = {
  noticia: "NOTÍCIA",
  fato: "FATО",
  acontecimento: "ACONTECIMENTO",
  discussao: "DISCUSSÃO",
};

export default async function SavedPage({ searchParams }: { searchParams: Promise<{ tab?: string }> }) {
  const { tab = "tudo" } = await searchParams;
  const active = (TABS.some((t) => t.key === tab) ? tab : "tudo") as Tab;

  const all = await getSavedResolved(DEMO_USER_ID);
  const items = active === "tudo" ? all : all.filter((i) => i.itemType === (active === "noticia" ? "noticia" : active));

  const counts: Record<Tab, number> = {
    tudo: all.length,
    noticia: all.filter((i) => i.itemType === "noticia").length,
    fato: all.filter((i) => i.itemType === "fato").length,
    discussao: all.filter((i) => i.itemType === "discussao").length,
  };

  return (
    <div className="px-4 md:px-8">
      <div className="max-w-[1400px] mx-auto">
        <header className="pt-8 md:pt-12">
          <div className="rule pt-3 flex items-center justify-between">
            <span className="label text-ink">SALVOS</span>
            <DemoBadge />
          </div>
          <div className="grid lg:grid-cols-[1fr_auto] items-end gap-6 mt-5">
            <h1 className="display-xl text-ink">Sua pauta guardada.</h1>
            <div className="lg:text-right">
              <div className="tnum" style={{ fontSize: 64, letterSpacing: "-0.05em" }}>
                {counts[active]}
              </div>
              <div className="label text-muted mt-1">ITENS</div>
            </div>
          </div>

          <nav className="mt-6 flex flex-wrap gap-2 border-t border-line pt-4">
            {TABS.map((t) => (
              <Link
                key={t.key}
                href={`/salvos?tab=${t.key}`}
                className="label px-3.5 py-2.5 border transition-colors"
                style={
                  active === t.key
                    ? { background: "var(--ink)", color: "var(--paper)", borderColor: "var(--ink)" }
                    : { borderColor: "var(--line)", color: "var(--muted)" }
                }
              >
                {t.label} · {counts[t.key]}
              </Link>
            ))}
          </nav>
        </header>

        <section className="pt-10 pb-14">
          <SectionLabel n="01" right={`${items.length} itens`}>ITENS SALVOS</SectionLabel>

          {items.length ? (
            <ul className="mt-5 divide-y divide-line">
              {items.map((item) => (
                <li key={item.id}>
                  <Link href={item.href} className="group flex items-start gap-4 py-4">
                    <span className="mt-1 text-ink shrink-0">
                      <BookmarkCheck size={17} />
                    </span>
                    <span className="min-w-0 flex-1">
                      <span className="label text-muted block">
                        {LABEL[item.itemType] ?? item.itemType} · {item.meta}
                      </span>
                      <span className="headline text-[17px] text-ink group-hover:underline-grow block mt-1.5">
                        {item.title}
                      </span>
                    </span>
                    <span className="label text-muted tnum shrink-0 mt-1">{timeAgo(item.createdAt)}</span>
                  </Link>
                </li>
              ))}
            </ul>
          ) : (
            <div className="mt-5">
              <EmptyState
                eyebrow="ESTADO VAZIO"
                title="Nenhum item salvo neste filtro."
                hint="Salve notícias, acontecimentos, investigações e discussões para acompanhá-los aqui — inclusive quando uma investigação for atualizada."
                action={
                  <Link href="/" className="label px-4 py-3 text-white inline-flex items-center gap-2" style={{ background: "var(--wire)" }}>
                    <Bookmark size={13} /> EXPLORAR NOTÍCIAS
                  </Link>
                }
              />
            </div>
          )}
        </section>
      </div>
    </div>
  );
}
