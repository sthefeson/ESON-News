import type { Metadata } from "next";
import Link from "next/link";
import { ArrowUpRight, ShieldHalf } from "lucide-react";
import { Avatar, DemoBadge, EmptyState, SectionLabel, timeAgo } from "@/components/ui";
import { COMMENT_TYPES, REPUTATION_RULE } from "@/lib/site";
import {
  DEMO_USER_ID,
  getCommentsByUser,
  getCurrentUser,
  getDiscussions,
  getSavedResolved,
} from "@/lib/data";

export const dynamic = "force-dynamic";

export const metadata: Metadata = { title: "Perfil" };

export default async function ProfilePage() {
  const [user, history, saved, discussions] = await Promise.all([
    getCurrentUser(),
    getCommentsByUser(DEMO_USER_ID),
    getSavedResolved(DEMO_USER_ID),
    getDiscussions(6),
  ]);

  if (!user) {
    return (
      <div className="px-4 md:px-8 pt-10">
        <div className="max-w-[1400px] mx-auto">
          <EmptyState eyebrow="PERFIL" title="Nenhum usuário ativo." hint="Faça login para ver seu perfil." />
        </div>
      </div>
    );
  }

  const level =
    user.reputation >= 800 ? "CONTRIBUIDOR SÊNIOR" : user.reputation >= 400 ? "CONTRIBUIDOR" : user.reputation >= 150 ? "PARTICIPANTE" : "LEITOR";

  return (
    <div className="px-4 md:px-8">
      <div className="max-w-[1400px] mx-auto">
        <header className="pt-8 md:pt-12">
          <div className="rule pt-3 flex items-center justify-between">
            <span className="label text-ink">PERFIL</span>
            <span className="label text-muted flex items-center gap-2">
              <ShieldHalf size={13} /> {user.role.toUpperCase()}
            </span>
          </div>

          <div className="grid lg:grid-cols-[auto_1fr_auto] gap-6 items-end mt-6">
            <Avatar name={user.name} size={96} />
            <div>
              <h1 className="display-xl text-ink">{user.name}</h1>
              <p className="label text-muted mt-3">@{user.username} · no Eson desde {timeAgo(user.createdAt)}</p>
              <p className="text-ink2 mt-3 measure leading-relaxed">{user.bio}</p>
            </div>
            <div className="lg:text-right">
              <div className="tnum" style={{ fontSize: 72, letterSpacing: "-0.05em", color: "var(--heat)" }}>
                {user.reputation}
              </div>
              <div className="label text-muted mt-1">{level}</div>
              <div className="mt-3">
                <DemoBadge />
              </div>
            </div>
          </div>

          <dl className="grid grid-cols-2 sm:grid-cols-4 gap-6 border-t border-line mt-8 pt-5">
            {[
              ["COMENTÁRIOS", history.length],
              ["DISCUSSÕES", discussions.length],
              ["ITENS SALVOS", saved.length],
              ["REPUTAÇÃO", user.reputation],
            ].map(([k, v]) => (
              <div key={k as string}>
                <dt className="label text-muted" style={{ fontSize: 9.5 }}>
                  {k}
                </dt>
                <dd className="tnum text-ink mt-1.5" style={{ fontSize: 24 }}>
                  {v}
                </dd>
              </div>
            ))}
          </dl>
        </header>

        <div className="grid lg:grid-cols-[1.4fr_1fr] gap-10 pt-10 pb-14">
          <section>
            <SectionLabel n="01" right="histórico de participação">COMENTÁRIOS</SectionLabel>
            {history.length ? (
              <ul className="mt-5 divide-y divide-line">
                {history.map(({ comment, article, investigation }) => (
                  <li key={comment.id} className="py-4">
                    <div className="flex flex-wrap items-center gap-3">
                      <span className="label px-2 py-1.5 bg-sunk text-ink2">
                        {COMMENT_TYPES[comment.type]?.icon} {COMMENT_TYPES[comment.type]?.label}
                      </span>
                      <span className="label text-muted tnum">{timeAgo(comment.createdAt)}</span>
                      <span className="label text-muted">▲ {comment.likes}</span>
                    </div>
                    <p className="text-[15.5px] text-ink2 leading-relaxed mt-2">{comment.content}</p>
                    {article ? (
                      <Link href={`/noticia/${article.id}`} className="label mt-2 inline-flex items-center gap-1.5" style={{ color: "var(--cyano)" }}>
                        EM: {article.title.slice(0, 64)}… <ArrowUpRight size={12} />
                      </Link>
                    ) : null}
                    {investigation ? (
                      <Link href={`/fato/${investigation.id}`} className="label mt-2 inline-flex items-center gap-1.5" style={{ color: "var(--cyano)" }}>
                        EM: {investigation.ref} <ArrowUpRight size={12} />
                      </Link>
                    ) : null}
                  </li>
                ))}
              </ul>
            ) : (
              <div className="mt-5">
                <EmptyState
                  eyebrow="ESTADO VAZIO"
                  title="Nenhum comentário publicado."
                  hint="Comentários com fonte e contexto ajudam a construir reputação na comunidade."
                  action={
                    <Link href="/praca" className="label px-4 py-3 text-white" style={{ background: "var(--wire)" }}>
                      IR PARA A PRAÇA
                    </Link>
                  }
                />
              </div>
            )}
          </section>

          <aside className="lg:border-l lg:border-line lg:pl-8 space-y-8">
            <div>
              <SectionLabel n="02" right={`${saved.length}`}>SALVOS</SectionLabel>
              {saved.length ? (
                <ul className="mt-4 divide-y divide-line">
                  {saved.slice(0, 6).map((s) => (
                    <li key={s.id}>
                      <Link href={s.href} className="group block py-3">
                        <span className="label text-muted block">{s.meta}</span>
                        <span className="text-sm text-ink group-hover:underline-grow block mt-1">{s.title}</span>
                      </Link>
                    </li>
                  ))}
                </ul>
              ) : (
                <p className="label text-muted mt-4">Nada salvo ainda.</p>
              )}
            </div>

            <div className="border border-line p-4">
              <div className="label text-ink mb-3">REPUTAÇÃO COMUNITÁRIA</div>
              <p className="text-sm text-ink2 leading-relaxed">{REPUTATION_RULE}</p>
              <ul className="mt-4 space-y-2">
                {[
                  ["Fonte citada em comentário", "+8"],
                  ["Resposta marcada como útil", "+4"],
                  ["Correção reconhecida", "+15"],
                  ["Denúncia aceita por moderação", "−20"],
                ].map(([k, v]) => (
                  <li key={k} className="flex items-center justify-between border-t border-line pt-2">
                    <span className="text-sm text-ink2">{k}</span>
                    <span className="tnum text-sm" style={{ color: v.startsWith("−") ? "var(--wire)" : "#3f9c4d" }}>
                      {v}
                    </span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="border border-line p-4">
              <div className="label text-ink mb-3">SEUS ACESSOS</div>
              <ul className="space-y-2 text-sm">
                {[
                  ["Salvos", "/salvos"],
                  ["Notificações", "/notificacoes"],
                  ["Praça Global", "/praca"],
                  ["Investigações FATО", "/fato"],
                ].map(([label, href]) => (
                  <li key={label}>
                    <Link href={href} className="text-ink2 hover:text-ink transition-colors inline-flex items-center gap-1.5">
                      {label} <ArrowUpRight size={12} />
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          </aside>
        </div>
      </div>
    </div>
  );
}
