"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Lock, LogIn } from "lucide-react";

export function AdminLogin() {
  const router = useRouter();
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      const res = await fetch("/api/admin/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ password }),
      });
      if (!res.ok) {
        const data = await res.json().catch(() => ({}));
        setError(data?.error ?? "Credenciais inválidas.");
        return;
      }
      router.refresh();
    } catch {
      setError("Falha de conexão.");
    } finally {
      setBusy(false);
    }
  };

  return (
    <form onSubmit={submit} className="border border-line bg-panel p-6">
      <div className="flex items-center gap-2">
        <Lock size={15} className="text-ink" />
        <span className="label text-ink">ENTRAR NO PAINEL</span>
      </div>

      <label className="label text-muted mt-5 block" htmlFor="admin-pass">
        SENHA OPERACIONAL
      </label>
      <input
        id="admin-pass"
        type="password"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
        className="mt-2 w-full h-11 px-3 bg-sunk border border-line text-ink outline-none focus:border-ink transition-colors"
        placeholder="••••••••"
      />

      <button
        type="submit"
        disabled={busy}
        className="label mt-4 w-full h-11 text-white inline-flex items-center justify-center gap-2 disabled:opacity-70"
        style={{ background: "var(--wire)" }}
      >
        <LogIn size={14} />
        {busy ? "VERIFICANDO…" : "AUTENTICAR"}
      </button>

      {error ? (
        <p className="label mt-3" style={{ color: "var(--wire)" }}>
          {error}
        </p>
      ) : null}

      <p className="text-xs text-muted mt-4 leading-relaxed">
        Ambiente de demonstração: a senha é definida em <span className="tnum">ADMIN_PASSWORD</span> no servidor
        (padrão: eson). A sessão usa cookie httpOnly verificado no servidor a cada requisição administrativa.
      </p>
    </form>
  );
}
