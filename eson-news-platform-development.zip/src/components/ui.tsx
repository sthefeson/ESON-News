import type { ReactNode } from "react";

/* ---------------- time helpers ---------------- */
export function timeAgo(input: Date | string) {
  const d = typeof input === "string" ? new Date(input) : input;
  const diff = Math.max(0, Date.now() - d.getTime());
  const m = Math.floor(diff / 60000);
  if (m < 1) return "agora há poucos segundos";
  if (m < 60) return `há ${m} min`;
  const h = Math.floor(m / 60);
  if (h < 24) return `há ${h} h`;
  const days = Math.floor(h / 24);
  if (days === 1) return "ontem";
  if (days < 30) return `há ${days} dias`;
  return d.toLocaleDateString("pt-BR", { day: "2-digit", month: "short", year: "numeric" });
}

export function clock(input: Date | string) {
  const d = typeof input === "string" ? new Date(input) : input;
  return d.toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" });
}

export function longDate(input: Date | string) {
  const d = typeof input === "string" ? new Date(input) : input;
  return d.toLocaleDateString("pt-BR", { day: "2-digit", month: "long", year: "numeric" });
}

export function fullStamp(input: Date | string) {
  const d = typeof input === "string" ? new Date(input) : input;
  return `${longDate(d)} · ${clock(d)}`;
}

/* ---------------- section label (01 / RADAR ESON) ---------------- */
export function SectionLabel({
  n,
  children,
  right,
  className = "",
}: {
  n?: string;
  children: ReactNode;
  right?: ReactNode;
  className?: string;
}) {
  return (
    <div className={`rule pt-3 flex items-baseline justify-between gap-4 ${className}`}>
      <div className="flex items-baseline gap-3 min-w-0">
        {n ? <span className="label tnum text-muted">{n}</span> : null}
        <span className="label text-ink truncate">{children}</span>
      </div>
      {right ? <div className="label text-muted shrink-0">{right}</div> : null}
    </div>
  );
}

/* ---------------- meters ---------------- */
export function Meter({ value, color = "var(--heat)", height = 3 }: { value: number; color?: string; height?: number }) {
  return (
    <div className="w-full bg-line overflow-hidden" style={{ height }}>
      <div
        className="h-full grow-x origin-left"
        style={{ width: `${Math.min(100, Math.max(0, value))}%`, background: color }}
      />
    </div>
  );
}

/* ---------------- pills & chips ---------------- */
export function Pill({
  children,
  tone = "neutral",
  className = "",
}: {
  children: ReactNode;
  tone?: "neutral" | "live" | "heat" | "cyano" | "outline";
  className?: string;
}) {
  const tones: Record<string, string> = {
    neutral: "bg-sunk text-ink2",
    live: "text-white",
    heat: "text-ink",
    cyano: "text-white",
    outline: "border border-line text-ink2",
  };
  const style: Record<string, React.CSSProperties> = {
    live: { background: "var(--wire)" },
    heat: { background: "var(--heat2)" },
    cyano: { background: "var(--cyano)" },
  };
  return (
    <span className={`label px-2 py-[6px] ${tones[tone]} ${className}`} style={style[tone]}>
      {children}
    </span>
  );
}

export function CategoryTag({ name, className = "" }: { name: string; className?: string }) {
  return <span className={`label text-muted ${className}`}>{name}</span>;
}

/* ---------------- FATO status ---------------- */
const STATUS_MAP: Record<string, { icon: string; label: string; fg: string; bg: string; desc: string }> = {
  confirmado: {
    icon: "✅",
    label: "CONFIRMADO",
    fg: "#1f9d55",
    bg: "rgba(31,157,85,.12)",
    desc: "Evidência sólida e verificável.",
  },
  bem_sustentado: {
    icon: "🟢",
    label: "BEM SUSTENTADO",
    fg: "#3f9c4d",
    bg: "rgba(63,156,77,.12)",
    desc: "Múltiplas evidências independentes apontam para a mesma conclusão.",
  },
  em_investigacao: {
    icon: "🟡",
    label: "EM INVESTIGAÇÃO",
    fg: "#a1760c",
    bg: "rgba(214,164,32,.16)",
    desc: "Existem indícios, mas ainda faltam confirmações.",
  },
  alegacao: {
    icon: "🟠",
    label: "ALEGAÇÃO",
    fg: "#c25708",
    bg: "rgba(226,122,26,.14)",
    desc: "Existe uma afirmação pública, mas não evidência suficiente.",
  },
  contradito: {
    icon: "🔴",
    label: "CONTRADITO",
    fg: "#d1342a",
    bg: "rgba(209,52,42,.12)",
    desc: "Existem evidências relevantes contrariando a afirmação.",
  },
  nao_verificavel: {
    icon: "⚫",
    label: "NÃO VERIFICÁVEL",
    fg: "#6b7280",
    bg: "rgba(107,114,128,.14)",
    desc: "Não há informação suficiente para concluir.",
  },
};

export function StatusChip({ status, className = "" }: { status: string; className?: string }) {
  const s = STATUS_MAP[status] ?? STATUS_MAP.nao_verificavel;
  return (
    <span
      className={`label inline-flex items-center gap-2 px-2.5 py-[7px] whitespace-nowrap ${className}`}
      style={{ color: s.fg, background: s.bg }}
    >
      <span aria-hidden>{s.icon}</span>
      {s.label}
    </span>
  );
}

export function statusMeta(status: string) {
  return STATUS_MAP[status] ?? STATUS_MAP.nao_verificavel;
}

/* ---------------- transparency ---------------- */
export function Transparency({ note, className = "" }: { note?: string; className?: string }) {
  return (
    <p className={`label leading-[1.7] text-muted border-l-2 pl-3 ${className}`} style={{ borderColor: "var(--cyano)" }}>
      {note ?? "Conteúdo sintetizado pelo Eson News a partir das fontes indicadas."}
    </p>
  );
}

export function DemoBadge({ className = "" }: { className?: string }) {
  return (
    <span
      className={`label px-2 py-[6px] border ${className}`}
      style={{ borderColor: "var(--heat)", color: "var(--heat)" }}
    >
      ● DEMONSTRAÇÃO
    </span>
  );
}

/* ---------------- empty state ---------------- */
export function EmptyState({
  eyebrow,
  title,
  hint,
  action,
}: {
  eyebrow: string;
  title: string;
  hint?: string;
  action?: ReactNode;
}) {
  return (
    <div className="hair bg-panel px-6 py-12 text-center">
      <div className="mx-auto max-w-md">
        <div className="mx-auto mb-5 h-10 w-10 border border-line relative">
          <span className="absolute left-1/2 top-1/2 h-3 w-px -translate-x-1/2 -translate-y-1/2 bg-muted" />
          <span className="absolute left-1/2 top-1/2 h-px w-3 -translate-x-1/2 -translate-y-1/2 bg-muted" />
        </div>
        <div className="label text-muted mb-3">{eyebrow}</div>
        <h3 className="display-md text-ink mb-3">{title}</h3>
        {hint ? <p className="text-sm text-ink2 leading-relaxed">{hint}</p> : null}
        {action ? <div className="mt-6 flex justify-center">{action}</div> : null}
      </div>
    </div>
  );
}

/* ---------------- skeleton ---------------- */
export function Skeleton({ className = "" }: { className?: string }) {
  return <div className={`skeleton ${className}`} />;
}

/* ---------------- avatar ---------------- */
export function Avatar({ name, size = 36 }: { name: string; size?: number }) {
  const initials = name
    .split(" ")
    .slice(0, 2)
    .map((w) => w[0])
    .join("")
    .toUpperCase();
  return (
    <span
      className="inline-flex items-center justify-center font-mono font-medium shrink-0"
      style={{
        width: size,
        height: size,
        fontSize: size * 0.34,
        background: "var(--sunk)",
        color: "var(--ink)",
        border: "1px solid var(--line)",
        letterSpacing: "0.04em",
      }}
      aria-hidden
    >
      {initials}
    </span>
  );
}
