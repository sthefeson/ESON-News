"use client";

import Link from "next/link";
import { usePathname, useRouter, useSearchParams } from "next/navigation";
import { useEffect, useState } from "react";
import {
  Bell,
  Bookmark,
  Compass,
  Globe2,
  Home,
  Radio,
  Search,
  ShieldHalf,
  User,
  X,
} from "lucide-react";
import { CATEGORIES, NAV_MOBILE, SLOGAN } from "@/lib/site";

/* ------------------------------------------------------------------ */
/* theme                                                               */
/* ------------------------------------------------------------------ */
function useTheme() {
  const [dark, setDark] = useState(false);
  useEffect(() => {
    setDark(document.documentElement.classList.contains("dark"));
  }, []);
  const toggle = () => {
    const next = !document.documentElement.classList.contains("dark");
    document.documentElement.classList.toggle("dark", next);
    try {
      localStorage.setItem("eson-theme", next ? "dark" : "light");
    } catch {
      /* ignore */
    }
    setDark(next);
  };
  return { dark, toggle };
}

/* ------------------------------------------------------------------ */
/* logo                                                                */
/* ------------------------------------------------------------------ */
export function Logo({ compact = false }: { compact?: boolean }) {
  return (
    <span className="inline-flex items-baseline gap-2.5 select-none">
      <span
        className="font-sans font-extrabold tracking-[-0.045em] text-ink"
        style={{ fontSize: compact ? 18 : 21 }}
      >
        ESON<span style={{ color: "var(--wire)" }}>NEWS</span>
      </span>
      <span
        className="label px-1.5 py-1 text-white leading-none"
        style={{ background: "var(--ink)", fontSize: 10 }}
      >
        EN
      </span>
    </span>
  );
}

/* ------------------------------------------------------------------ */
/* header                                                              */
/* ------------------------------------------------------------------ */
export function SiteHeader({ unread }: { unread: number }) {
  const pathname = usePathname();
  const router = useRouter();
  const params = useSearchParams();
  const { dark, toggle } = useTheme();
  const [q, setQ] = useState(params.get("q") ?? "");
  const [open, setOpen] = useState(false);

  useEffect(() => setOpen(false), [pathname]);

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!q.trim()) return;
    router.push(`/pesquisa?q=${encodeURIComponent(q.trim())}`);
  };

  const iconBtn =
    "grid place-items-center h-9 w-9 border border-line text-ink2 hover:text-ink hover:bg-sunk transition-colors";

  return (
    <header className="sticky top-0 z-50 backdrop-blur-md" style={{ background: "color-mix(in srgb, var(--paper) 88%, transparent)", borderBottom: "1px solid var(--line)" }}>
      {/* main bar */}
      <div className="flex items-center gap-4 px-4 md:px-6 h-14">
        <Link href="/" aria-label="ESON NEWS — início" className="shrink-0">
          <Logo />
        </Link>

        <span className="hidden xl:block label text-muted pl-4 border-l border-line truncate">
          {SLOGAN}
        </span>

        <form onSubmit={submit} className="ml-auto hidden md:flex items-center">
          <div className="flex items-center gap-2 border border-line h-9 px-3 w-52 lg:w-72 bg-panel focus-within:border-ink transition-colors">
            <Search size={14} className="text-muted shrink-0" />
            <input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="Pesquisar notícias, fatos, pessoas"
              className="bg-transparent text-sm w-full outline-none placeholder:text-muted text-ink"
            />
          </div>
        </form>

        <div className="ml-auto md:ml-0 flex items-center gap-2">
          <button className={`${iconBtn} md:hidden`} onClick={() => setOpen((v) => !v)} aria-label="Pesquisa">
            {open ? <X size={16} /> : <Search size={16} />}
          </button>
          <Link href="/pesquisa" className={`${iconBtn} hidden md:grid`} aria-label="Pesquisa global">
            <Search size={16} />
          </Link>
          <Link href="/notificacoes" className={`${iconBtn} relative`} aria-label="Notificações">
            <Bell size={16} />
            {unread > 0 ? (
              <span
                className="absolute -top-1.5 -right-1.5 tnum text-white grid place-items-center"
                style={{ minWidth: 17, height: 17, fontSize: 10, background: "var(--wire)", borderRadius: 99 }}
              >
                {unread}
              </span>
            ) : null}
          </Link>
          <Link href="/salvos" className={`${iconBtn} hidden sm:grid`} aria-label="Salvos">
            <Bookmark size={16} />
          </Link>
          <Link href="/perfil" className={iconBtn} aria-label="Perfil">
            <User size={16} />
          </Link>
          <button className={iconBtn} onClick={toggle} aria-label="Alternar modo claro e escuro">
            <span className="label" style={{ fontSize: 9 }}>
              {dark ? "CLARO" : "ESC"}
            </span>
          </button>
        </div>
      </div>

      {/* search sheet (mobile) */}
      {open ? (
        <form onSubmit={submit} className="md:hidden px-4 pb-3">
          <div className="flex items-center gap-2 border border-line h-10 px-3 bg-panel">
            <Search size={14} className="text-muted" />
            <input
              autoFocus
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="Pesquisar no Eson News"
              className="bg-transparent text-sm w-full outline-none placeholder:text-muted text-ink"
            />
          </div>
        </form>
      ) : null}

      {/* categories rail */}
      <nav
        className="hidden md:flex items-center gap-6 px-6 h-10 overflow-x-auto scrollbar-none border-t border-line"
        style={{ scrollbarWidth: "none" }}
      >
        <Link
          href="/"
          className="label whitespace-nowrap transition-colors"
          style={{ color: pathname === "/" ? "var(--wire)" : "var(--muted)" }}
        >
          Início
        </Link>
        {CATEGORIES.map((c) => {
          const active = pathname === `/categoria/${c.slug}`;
          return (
            <Link
              key={c.slug}
              href={`/categoria/${c.slug}`}
              className="label whitespace-nowrap transition-colors"
              style={{ color: active ? "var(--ink)" : "var(--muted)" }}
            >
              {c.name}
            </Link>
          );
        })}
        <span className="w-px h-4 bg-line shrink-0" />
        <Link
          href="/fato"
          className="label whitespace-nowrap font-semibold"
          style={{ color: pathname.startsWith("/fato") ? "var(--wire)" : "var(--ink)" }}
        >
          FATO
        </Link>
        <Link
          href="/praca"
          className="label whitespace-nowrap"
          style={{ color: pathname.startsWith("/praca") ? "var(--ink)" : "var(--muted)" }}
        >
          Praça Global
        </Link>
        <Link href="/admin" className="label whitespace-nowrap text-muted hover:text-ink flex items-center gap-1.5 ml-auto">
          <ShieldHalf size={13} /> Admin
        </Link>
      </nav>
    </header>
  );
}

/* ------------------------------------------------------------------ */
/* mobile bottom nav                                                   */
/* ------------------------------------------------------------------ */
export function MobileNav() {
  const pathname = usePathname();
  const icons: Record<string, React.ReactNode> = {
    home: <Home size={18} />,
    compass: <Compass size={18} />,
    searchcheck: <Radio size={18} />,
    globe: <Globe2 size={18} />,
    user: <User size={18} />,
  };
  const isActive = (href: string) =>
    href === "/" ? pathname === "/" : pathname.startsWith(href.split("/")[1] ?? "");

  return (
    <nav
      className="md:hidden fixed bottom-0 inset-x-0 z-50 border-t border-line backdrop-blur-md"
      style={{ background: "color-mix(in srgb, var(--paper) 94%, transparent)" }}
      aria-label="Navegação principal"
    >
      <ul className="grid grid-cols-5">
        {NAV_MOBILE.map((item) => {
          const active = isActive(item.href);
          const isFato = item.name === "Fato";
          return (
            <li key={item.name}>
              <Link
                href={item.href}
                className="flex flex-col items-center justify-center gap-1.5 py-2.5 transition-colors"
                style={{ color: active ? "var(--ink)" : "var(--muted)" }}
              >
                <span
                  className={isFato ? "grid place-items-center h-8 w-8 -mt-1 text-white" : "-mt-0.5"}
                  style={isFato ? { background: "var(--wire)" } : undefined}
                >
                  {icons[item.icon]}
                </span>
                <span className="label" style={{ fontSize: 9.5 }}>
                  {item.name}
                </span>
              </Link>
            </li>
          );
        })}
      </ul>
    </nav>
  );
}

/* ------------------------------------------------------------------ */
/* desktop wire rail                                                   */
/* ------------------------------------------------------------------ */
export function WireRail({ radarIndex }: { radarIndex: number }) {
  const [now, setNow] = useState<string>("--:--");
  useEffect(() => {
    const tick = () =>
      setNow(
        new Date().toLocaleTimeString("pt-BR", {
          hour: "2-digit",
          minute: "2-digit",
          timeZone: "UTC",
        }),
      );
    tick();
    const id = setInterval(tick, 15000);
    return () => clearInterval(id);
  }, []);

  return (
    <aside
      className="hidden lg:flex fixed left-0 top-0 bottom-0 w-[72px] z-40 flex-col items-center justify-between py-5 border-r border-line"
      style={{ background: "var(--panel)" }}
      aria-hidden
    >
      <div className="flex flex-col items-center gap-4">
        <span className="grid place-items-center h-9 w-9 label text-white" style={{ background: "var(--wire)" }}>
          EN
        </span>
        <span className="live-dot block h-2 w-2 rounded-full" style={{ background: "var(--wire)" }} />
      </div>

      <div className="flex flex-col items-center gap-6">
        <span
          className="label text-muted"
          style={{ writingMode: "vertical-rl", textOrientation: "mixed", letterSpacing: "0.34em" }}
        >
          ESON NEWS · AO VIVO
        </span>
        <span className="w-px h-10 bg-line" />
        <span className="label tnum text-muted" style={{ writingMode: "vertical-rl" }}>
          {now} UTC
        </span>
      </div>

      <div className="flex flex-col items-center gap-2">
        <span className="label text-muted" style={{ fontSize: 9 }}>
          RADAR
        </span>
        <span className="tnum text-ink" style={{ fontSize: 26, lineHeight: 1 }}>
          {radarIndex}
        </span>
        <span className="w-6 h-px" style={{ background: "var(--heat)" }} />
      </div>
    </aside>
  );
}
