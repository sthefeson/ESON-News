"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

export type AdminAction = { label: string; action: string; id?: number | string };

export function AdminActions({ actions }: { actions: AdminAction[] }) {
  const router = useRouter();
  const [busy, setBusy] = useState<string | null>(null);
  const [note, setNote] = useState<string | null>(null);

  const run = async (a: AdminAction) => {
    setBusy(a.action);
    setNote(null);
    try {
      const res = await fetch("/api/admin", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: a.action, id: a.id }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) {
        setNote(data?.error ?? "Ação recusada.");
      } else {
        setNote(data?.message ?? "Concluído.");
        router.refresh();
      }
    } catch {
      setNote("Falha de conexão.");
    } finally {
      setBusy(null);
      setTimeout(() => setNote(null), 3200);
    }
  };

  return (
    <span className="inline-flex flex-col items-end gap-1.5">
      <span className="inline-flex flex-wrap gap-2 justify-end">
        {actions.map((a) => (
          <button
            key={a.action + String(a.id ?? "")}
            type="button"
            onClick={() => run(a)}
            disabled={busy === a.action}
            className="label px-2.5 py-1.5 border border-line text-ink2 hover:text-ink hover:border-ink transition-colors disabled:opacity-50"
          >
            {busy === a.action ? "…" : a.label}
          </button>
        ))}
      </span>
      {note ? <span className="label text-muted" style={{ fontSize: 9.5 }}>{note}</span> : null}
    </span>
  );
}
