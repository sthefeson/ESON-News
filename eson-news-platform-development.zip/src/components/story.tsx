"use client";

import Link from "next/link";
import { useEffect, useRef, useState } from "react";
import { AnimatePresence, motion, useInView, useReducedMotion } from "framer-motion";
import { ArrowUpRight, Layers } from "lucide-react";
import { radarBand } from "@/lib/site";
import { Meter, Pill, timeAgo } from "@/components/ui";
import type { ArticleRow, EventRow } from "@/lib/data";

export function asset(path?: string | null) {
  if (!path) return null;
  return path.startsWith("/") || path.startsWith("http") ? path : `/${path}`;
}

/* ------------------------------------------------------------------ */
/* story cards                                                         */
/* ------------------------------------------------------------------ */
export function StoryCard({
  article,
  variant = "card",
  cluster,
}: {
  article: ArticleRow;
  variant?: "lead" | "card" | "row";
  cluster?: number;
}) {
  const href = `/noticia/${article.id}`;
  const src = asset(article.imageUrl);

  if (variant === "row") {
    return (
      <Link href={href} className="group flex gap-4 py-4 border-b border-line">
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-3">
            <span className="label text-muted">{article.category.replace("-", " ")}</span>
            <span className="label text-muted tnum">{timeAgo(article.publishedAt)}</span>
          </div>
          <h3 className="headline text-[15.5px] mt-2 text-ink group-hover:underline-grow inline">{article.title}</h3>
          <div className="label text-muted mt-2">
            {article.source}
            {cluster ? ` · +${cluster - 1} fontes` : ""}
          </div>
        </div>
        {src ? (
          <div className="w-24 h-20 shrink-0 overflow-hidden bg-sunk">
            <img src={src} alt="" className="w-full h-full object-cover grayscale-[0.15] group-hover:scale-[1.04] transition-transform duration-300" />
          </div>
        ) : null}
      </Link>
    );
  }

  if (variant === "lead") {
    return (
      <Link href={href} className="group block">
        <div className="relative overflow-hidden bg-sunk aspect-[16/9]">
          {src ? (
            <img
              src={src}
              alt=""
              className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-[1.03]"
            />
          ) : (
            <div className="w-full h-full grid place-items-center label text-muted">SEM IMAGEM</div>
          )}
          <div
            className="absolute inset-x-0 bottom-0 h-2/5"
            style={{ background: "linear-gradient(to top, rgba(0,0,0,.62), transparent)" }}
          />
          <div className="absolute left-4 top-4 flex gap-2">
            <Pill tone="live">AO VIVO</Pill>
            <Pill tone="neutral">{article.category.replace("-", " ")}</Pill>
          </div>
        </div>
        <div className="mt-4">
          <div className="flex items-center gap-3">
            <span className="label" style={{ color: "var(--wire)" }}>
              AGORA
            </span>
            <span className="label text-muted tnum">{timeAgo(article.publishedAt)}</span>
            {cluster ? <span className="label text-muted">{cluster} FONTES</span> : null}
          </div>
          <h2 className="display-lg mt-3 text-ink group-hover:underline-grow inline">{article.title}</h2>
          {article.description ? (
            <p className="mt-3 text-ink2 leading-relaxed measure">{article.description}</p>
          ) : null}
          <div className="label text-muted mt-4">
            {article.source}
            {article.author ? ` · ${article.author}` : ""}
          </div>
        </div>
      </Link>
    );
  }

  return (
    <Link href={href} className="group flex flex-col">
      <div className="relative overflow-hidden bg-sunk aspect-[3/2]">
        {src ? (
          <img
            src={src}
            alt=""
            loading="lazy"
            className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-[1.04]"
          />
        ) : (
          <div className="w-full h-full grid place-items-center label text-muted">SEM IMAGEM</div>
        )}
        {cluster && cluster > 1 ? (
          <span
            className="absolute right-0 top-0 label px-2 py-1.5 text-white flex items-center gap-1.5"
            style={{ background: "var(--ink)" }}
          >
            <Layers size={11} /> {cluster} FONTES
          </span>
        ) : null}
      </div>
      <div className="flex items-center gap-3 mt-3">
        <span className="label" style={{ color: "var(--wire)" }}>
          {article.category.replace("-", " ")}
        </span>
        <span className="label text-muted tnum">{timeAgo(article.publishedAt)}</span>
      </div>
      <h3 className="headline text-[19px] mt-2 text-ink group-hover:underline-grow">{article.title}</h3>
      {article.description ? (
        <p className="text-sm text-ink2 mt-2 leading-relaxed line-clamp-3">{article.description}</p>
      ) : null}
      <div className="label text-muted mt-3">{article.source}</div>
    </Link>
  );
}

/* ------------------------------------------------------------------ */
/* event card (ranked, no image)                                       */
/* ------------------------------------------------------------------ */
export function EventCard({ event, rank }: { event: EventRow; rank?: number }) {
  const band = radarBand(event.importanceScore);
  return (
    <Link href={`/acontecimento/${event.id}`} className="group block border-t border-line pt-4">
      <div className="flex items-start gap-4">
        <div className="tnum shrink-0 leading-none" style={{ fontSize: 40, letterSpacing: "-0.04em", color: band.color }}>
          {event.importanceScore}
        </div>
        <div className="min-w-0">
          {rank ? <span className="label text-muted">{String(rank).padStart(2, "0")} · </span> : null}
          <span className="label" style={{ color: band.color }}>
            {band.label}
          </span>
          <h3 className="headline text-[17px] mt-2 text-ink group-hover:underline-grow">{event.title}</h3>
          <p className="text-sm text-ink2 mt-2 leading-relaxed line-clamp-2">{event.summary}</p>
          <div className="mt-3 grid grid-cols-3 gap-3 max-w-md">
            <div>
              <div className="label text-muted" style={{ fontSize: 9.5 }}>
                FONTES
              </div>
              <div className="tnum text-sm mt-1">{event.sourcesCount}</div>
            </div>
            <div>
              <div className="label text-muted" style={{ fontSize: 9.5 }}>
                CRESCIMENTO
              </div>
              <div className="tnum text-sm mt-1">▲ {event.growth}%</div>
            </div>
            <div>
              <div className="label text-muted" style={{ fontSize: 9.5 }}>
                ALCANCE
              </div>
              <div className="tnum text-sm mt-1">{event.reach}%</div>
            </div>
          </div>
          <div className="mt-3">
            <Meter value={event.importanceScore} color={band.color} />
          </div>
        </div>
      </div>
    </Link>
  );
}

/* ------------------------------------------------------------------ */
/* MESMO ACONTECIMENTO — three headlines collapse into one story        */
/* ------------------------------------------------------------------ */
export type ClusterItem = { id: number; title: string; source: string; domain?: string | null };

export function ClusterCard({
  event,
  items,
}: {
  event: Pick<EventRow, "id" | "title" | "summary" | "sourcesCount" | "category" | "lastUpdate">;
  items: ClusterItem[];
}) {
  const reduce = useReducedMotion();
  const ref = useRef<HTMLDivElement>(null);
  const inView = useInView(ref, { once: true, amount: 0.5 });
  const [merged, setMerged] = useState(false);
  const shown = items.slice(0, 3);

  useEffect(() => {
    if (inView && !reduce) {
      const t = setTimeout(() => setMerged(true), 1100);
      return () => clearTimeout(t);
    }
    if (reduce) setMerged(true);
    return undefined;
  }, [inView, reduce]);

  return (
    <div ref={ref} className="border border-line bg-panel">
      <div className="flex items-center justify-between gap-4 px-4 sm:px-5 py-3 border-b border-line">
        <span className="label flex items-center gap-2" style={{ color: "var(--cyano)" }}>
          <Layers size={13} /> MESMO ACONTECIMENTO
        </span>
        <button
          type="button"
          onClick={() => setMerged((v) => !v)}
          className="label text-muted hover:text-ink transition-colors underline underline-offset-4 decoration-dotted"
        >
          {merged ? "ver as fontes" : "ver agrupado"}
        </button>
      </div>

      <div className="relative px-4 sm:px-5 py-5">
        <AnimatePresence mode="wait" initial={false}>
          {!merged ? (
            <motion.ul
              key="sources"
              initial={reduce ? false : { opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={reduce ? undefined : { opacity: 0, scale: 0.98, filter: "blur(3px)" }}
              transition={{ duration: 0.36, ease: [0.2, 0.7, 0.2, 1] }}
              className="space-y-3"
            >
              {shown.map((it) => (
                <li key={it.id} className="flex gap-3 items-baseline">
                  <span className="label text-muted w-28 shrink-0 truncate">{it.source}</span>
                  <span className="text-[15px] text-ink2 leading-snug">{it.title}</span>
                </li>
              ))}
            </motion.ul>
          ) : (
            <motion.div
              key="merged"
              initial={reduce ? false : { opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.4, ease: [0.2, 0.7, 0.2, 1] }}
            >
              <span className="label text-muted">
                {event.category.replace("-", " ")} · agrupado automaticamente
              </span>
              <Link href={`/acontecimento/${event.id}`} className="group block mt-2">
                <h3 className="display-md text-ink group-hover:underline-grow inline">{event.title}</h3>
              </Link>
              <p className="text-sm text-ink2 mt-2 leading-relaxed measure">{event.summary}</p>
              <div className="flex flex-wrap items-center gap-x-5 gap-y-2 mt-4">
                <span className="tnum text-ink" style={{ fontSize: 28, letterSpacing: "-0.03em" }}>
                  {event.sourcesCount}
                </span>
                <span className="label text-muted">FONTES RELACIONADAS</span>
                <span className="label text-muted">última atualização {event.lastUpdate ? timeAgo(event.lastUpdate) : "—"}</span>
                <Link
                  href={`/acontecimento/${event.id}`}
                  className="label inline-flex items-center gap-1.5 ml-auto hover:text-ink transition-colors"
                  style={{ color: "var(--cyano)" }}
                >
                  Ver cobertura completa <ArrowUpRight size={13} />
                </Link>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
