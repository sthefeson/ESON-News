"use client";

import Link from "next/link";
import { useMemo } from "react";
import { RADAR_NOTE, RADAR_SIGNALS, RELEVANCE_SIGNALS, radarBand, type Category } from "@/lib/site";
import { Meter, timeAgo } from "@/components/ui";

export type RadarItem = {
  id: number;
  title: string;
  category: string;
  importanceScore: number;
  sourcesCount: number;
  growth: number;
  reach: number;
  velocity: number;
  updatesCount: number;
  lastUpdate: string | Date | null;
};

/* ------------------------------------------------------------------ */
/* circular radar gauge                                                */
/* ------------------------------------------------------------------ */
export function RadarGauge({ items, size = 268 }: { items: RadarItem[]; size?: number }) {
  const top = items[0];
  const blips = useMemo(() => {
    const list = items.slice(0, 9);
    return list.map((it, i) => {
      const angle = (-90 + i * (360 / Math.max(list.length, 1)) + (i % 3) * 7) * (Math.PI / 180);
      const r = 104 - (it.importanceScore / 100) * 86;
      return {
        id: it.id,
        score: it.importanceScore,
        x: 130 + Math.cos(angle) * r,
        y: 130 + Math.sin(angle) * r,
        band: radarBand(it.importanceScore),
      };
    });
  }, [items]);

  if (!top) return null;

  return (
    <div className="relative shrink-0" style={{ width: size, height: size }}>
      <svg viewBox="0 0 260 260" width={size} height={size} role="img" aria-label="Indicador visual do Radar Eson">
        <defs>
          <linearGradient id="sweepGrad" x1="0" y1="0" x2="1" y2="0">
            <stop offset="0%" stopColor="var(--heat)" stopOpacity="0" />
            <stop offset="100%" stopColor="var(--heat)" stopOpacity="0.34" />
          </linearGradient>
        </defs>

        {[104, 78, 52, 26].map((r) => (
          <circle key={r} cx="130" cy="130" r={r} fill="none" stroke="var(--line)" strokeWidth="1" />
        ))}
        <line x1="130" y1="18" x2="130" y2="242" stroke="var(--line)" strokeWidth="1" />
        <line x1="18" y1="130" x2="242" y2="130" stroke="var(--line)" strokeWidth="1" />

        <g
          className="sweep"
          style={{ transformBox: "view-box", transformOrigin: "center" }}
        >
          <path d="M130 130 L130 26 A104 104 0 0 1 203 57 Z" fill="url(#sweepGrad)" />
          <line x1="130" y1="130" x2="130" y2="26" stroke="var(--heat)" strokeWidth="1.5" />
        </g>

        {blips.map((b) => (
          <g key={b.id}>
            <circle cx={b.x} cy={b.y} r="4.5" fill={b.band.color} />
            <circle cx={b.x} cy={b.y} r="9" fill="none" stroke={b.band.color} strokeOpacity="0.4" />
          </g>
        ))}

        <circle cx="130" cy="130" r="3" fill="var(--ink)" />
      </svg>

      <div className="absolute inset-0 grid place-items-center pointer-events-none">
        <div className="text-center -mt-1">
          <div className="tnum leading-none" style={{ fontSize: 64, fontWeight: 500, letterSpacing: "-0.05em" }}>
            {top.importanceScore}
          </div>
          <div className="label mt-2" style={{ color: radarBand(top.importanceScore).color }}>
            {radarBand(top.importanceScore).label}
          </div>
          <div className="label text-muted mt-1">ÍNDICE MÁX.</div>
        </div>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* ranked radar list                                                   */
/* ------------------------------------------------------------------ */
export function RadarList({ items, limit = 6 }: { items: RadarItem[]; limit?: number }) {
  const list = items.slice(0, limit);
  return (
    <ol className="divide-y divide-line">
      {list.map((it, i) => {
        const band = radarBand(it.importanceScore);
        return (
          <li key={it.id}>
            <Link
              href={`/acontecimento/${it.id}`}
              className="group block py-4 transition-colors hover:bg-[var(--sunk)] px-1 -mx-1"
            >
              <div className="flex items-start gap-4">
                <span className="tnum text-muted shrink-0" style={{ fontSize: 13, paddingTop: 6 }}>
                  {String(i + 1).padStart(2, "0")}
                </span>

                <div className="min-w-0 flex-1">
                  <div className="flex items-baseline gap-3">
                    <span
                      className="tnum shrink-0 leading-none"
                      style={{ fontSize: 44, fontWeight: 500, letterSpacing: "-0.04em", color: band.color }}
                    >
                      {it.importanceScore}
                    </span>
                    <span className="label" style={{ color: band.color }}>
                      {band.label}
                    </span>
                  </div>

                  <h3 className="headline text-[17px] mt-2 text-ink group-hover:underline-grow inline-block">
                    {it.title}
                  </h3>

                  <div className="mt-3"><Meter value={it.importanceScore} color={band.color} /></div>

                  <dl className="mt-3 grid grid-cols-2 sm:grid-cols-4 gap-x-4 gap-y-2">
                    {[
                      ["FONTES", it.sourcesCount],
                      ["VELOCIDADE", `${it.velocity}%`],
                      ["ALCANCE INT.", `${it.reach}%`],
                      ["ATUALIZ.", it.updatesCount],
                    ].map(([k, v]) => (
                      <div key={k as string}>
                        <dt className="label text-muted" style={{ fontSize: 9.5 }}>
                          {k}
                        </dt>
                        <dd className="tnum text-ink text-sm mt-1">{v}</dd>
                      </div>
                    ))}
                  </dl>

                  <div className="mt-3 flex items-center gap-3">
                    <span className="label" style={{ color: "var(--heat)" }}>
                      ▲ {it.growth}% crescimento
                    </span>
                    <span className="label text-muted">
                      {it.lastUpdate ? `atualizado ${timeAgo(it.lastUpdate)}` : "—" }
                    </span>
                  </div>
                </div>
              </div>
            </Link>
          </li>
        );
      })}
    </ol>
  );
}

/* ------------------------------------------------------------------ */
/* full panel                                                          */
/* ------------------------------------------------------------------ */
export function RadarPanel({ items, gaugeItems }: { items: RadarItem[]; gaugeItems?: RadarItem[] }) {
  return (
    <div className="grid lg:grid-cols-[auto_1fr] gap-8 lg:gap-10">
      <div className="flex flex-col items-center lg:items-start">
        <RadarGauge items={gaugeItems ?? items.slice(0, 5)} />
        <div className="mt-4 w-full max-w-[268px] space-y-2">
          {RADAR_SIGNALS.slice(0, 4).map((s) => (
            <div key={s.key} className="flex items-center justify-between gap-3">
              <span className="label text-muted" style={{ fontSize: 9.5 }}>
                {s.key}
              </span>
              <span className="h-px flex-1 bg-line" />
            </div>
          ))}
        </div>
      </div>

      <div className="min-w-0">
        <RadarList items={items} />

        <details className="mt-6 border border-line bg-panel">
          <summary className="label px-4 py-3 cursor-pointer text-ink hover:bg-[var(--sunk)]">
            Como o Radar calcula este indicador
          </summary>
          <div className="px-4 pb-4">
            <p className="text-sm leading-relaxed text-ink2 mb-4">
              O índice combina seis sinais normalizados, medidos a cada ciclo de coleta:
            </p>
            <ul className="grid sm:grid-cols-2 gap-x-6 gap-y-2 mb-4">
              {RADAR_SIGNALS.map((s, i) => (
                <li key={s.key} className="flex gap-3 text-sm border-t border-line pt-2">
                  <span className="tnum text-muted">{String(i + 1).padStart(2, "0")}</span>
                  <span>
                    <span className="text-ink font-medium">{s.key}</span>
                    <span className="block text-muted text-xs mt-0.5">{s.hint}</span>
                  </span>
                </li>
              ))}
            </ul>
            <div className="mt-4 border-t border-line pt-3">
              <div className="label text-muted mb-2">MOTOR DE RELEVÂNCIA · SINAIS CALCULADOS</div>
              <ul className="flex flex-wrap gap-x-4 gap-y-1.5">
                {RELEVANCE_SIGNALS.map((s) => (
                  <li key={s} className="label text-ink2" style={{ fontSize: 9.5 }}>
                    · {s}
                  </li>
                ))}
              </ul>
              <p className="label text-muted mt-2">
                Cliques não entram no cálculo. Popularidade nunca é usada como sinônimo de verdade.
              </p>
            </div>

            <p
              className="text-sm leading-relaxed border-l-2 pl-3 mt-4"
              style={{ borderColor: "var(--heat)", color: "var(--ink2)" }}
            >
              «{RADAR_NOTE}»
            </p>
          </div>
        </details>
      </div>
    </div>
  );
}

export function categoriesLabel(c: Category) {
  return c.name;
}
