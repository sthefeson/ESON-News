"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Loader2, SearchCheck } from "lucide-react";

const SUGGESTIONS = [
  "É verdade que X aconteceu?",
  "O que realmente está acontecendo em X?",
  "De onde surgiu esse rumor?",
  "O que sabemos sobre X?",
  "Quais são as evidências?",
];

export function FatoQuery() {
  const router = useRouter();
  const [q, setQ] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const ask = async (value?: string) => {
    const question = (value ?? q).trim();
    if (question.length < 8) {
      setError("Escreva uma pergunta com pelo menos 8 caracteres — assim dá para investigar de verdade.");
      return;
    }
    setBusy(true);
    setError(null);
    try {
      const res = await fetch("/api/fato", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ question }),
      });
      if (!res.ok) {
        const data = await res.json().catch(() => ({}));
        setError(data?.error ?? "Não foi possível abrir a investigação agora.");
        return;
      }
      const data = (await res.json()) as { id: number };
      router.push(`/fato/${data.id}`);
    } catch {
      setError("Falha de conexão. Tente novamente.");
    }
  };

  return (
    <div>
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="flex items-center gap-3 flex-1 border border-line bg-panel px-4 h-14 focus-within:border-ink transition-colors">
          <SearchCheck size={18} className="text-muted shrink-0" />
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter") ask();
            }}
            placeholder="Faça uma pergunta: “É verdade que…?”"
            className="bg-transparent w-full outline-none text-ink placeholder:text-muted text-[15px]"
          />
        </div>
        <button
          type="button"
          onClick={() => ask()}
          disabled={busy}
          className="label px-6 h-14 text-white inline-flex items-center justify-center gap-2 disabled:opacity-70"
          style={{ background: "var(--wire)" }}
        >
          {busy ? <Loader2 size={15} className="animate-spin" /> : null}
          {busy ? "INVESTIGANDO…" : "INVESTIGAR"}
        </button>
      </div>

      <div className="flex flex-wrap gap-2 mt-4">
        {SUGGESTIONS.map((s) => (
          <button
            key={s}
            type="button"
            onClick={() => {
              setQ(s);
              ask(s);
            }}
            className="label px-3 py-2 border border-line text-muted hover:text-ink hover:border-ink transition-colors"
          >
            {s}
          </button>
        ))}
      </div>

      {error ? <p className="label mt-4" style={{ color: "var(--wire)" }}>{error}</p> : null}
    </div>
  );
}
