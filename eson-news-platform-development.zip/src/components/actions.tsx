"use client";

import { useState } from "react";
import { Bookmark, BookmarkCheck, Link2, Share2 } from "lucide-react";

export function SaveButton({ itemType, itemId, initial = false }: { itemType: string; itemId: number; initial?: boolean }) {
  const [saved, setSaved] = useState(initial);
  const [busy, setBusy] = useState(false);

  const toggle = async () => {
    setBusy(true);
    setSaved((v) => !v);
    try {
      await fetch("/api/save", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ itemType, itemId, remove: saved }),
      });
    } catch {
      setSaved((v) => !v);
    } finally {
      setBusy(false);
    }
  };

  return (
    <button
      type="button"
      onClick={toggle}
      disabled={busy}
      className="label inline-flex items-center gap-2 px-3.5 py-2.5 border transition-colors disabled:opacity-60"
      style={{
        borderColor: saved ? "var(--ink)" : "var(--line)",
        color: saved ? "var(--paper)" : "var(--ink2)",
        background: saved ? "var(--ink)" : "transparent",
      }}
      aria-pressed={saved}
    >
      {saved ? <BookmarkCheck size={14} /> : <Bookmark size={14} />}
      {saved ? "SALVO" : "SALVAR"}
    </button>
  );
}

export function ShareButton({ title, text, url }: { title: string; text?: string; url?: string }) {
  const [copied, setCopied] = useState(false);

  const share = async () => {
    const href = url ?? (typeof window !== "undefined" ? window.location.href : "");
    try {
      if (navigator.share) {
        await navigator.share({ title, text, url: href });
        return;
      }
      await navigator.clipboard.writeText(`${title} — ${href}`);
      setCopied(true);
      setTimeout(() => setCopied(false), 2200);
    } catch {
      /* usuário cancelou */
    }
  };

  return (
    <button
      type="button"
      onClick={share}
      className="label inline-flex items-center gap-2 px-3.5 py-2.5 border border-line text-ink2 hover:text-ink hover:border-ink transition-colors"
    >
      <Share2 size={14} />
      {copied ? "LINK COPIADO" : "COMPARTILHAR"}
    </button>
  );
}

export function CopyLink() {
  const [copied, setCopied] = useState(false);
  return (
    <button
      type="button"
      onClick={async () => {
        try {
          await navigator.clipboard.writeText(window.location.href);
          setCopied(true);
          setTimeout(() => setCopied(false), 2000);
        } catch {
          /* ignore */
        }
      }}
      className="label inline-flex items-center gap-2 text-muted hover:text-ink transition-colors"
    >
      <Link2 size={13} />
      {copied ? "COPIADO" : "COPIAR LINK"}
    </button>
  );
}
