"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Flag, MessageSquare, ThumbsUp } from "lucide-react";
import { Avatar, timeAgo } from "@/components/ui";
import { COMMENT_TYPES, MODERATION_RULE } from "@/lib/site";

type ReplyDTO = {
  id: number;
  content: string;
  type: string;
  likes: number;
  createdAt: string | Date;
  user: { name: string; username: string } | null;
};

type CommentDTO = {
  id: number;
  content: string;
  type: string;
  likes: number;
  createdAt: string | Date;
  user: { name: string; username: string } | null;
  replies?: ReplyDTO[];
};

export function Discussion({
  comments,
  scope,
  heading = "DISCUSSÃO",
}: {
  comments: CommentDTO[];
  scope: { articleId?: number; eventId?: number; investigationId?: number };
  heading?: string;
}) {
  const router = useRouter();
  const [text, setText] = useState("");
  const [type, setType] = useState<string>("opiniao");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [likes, setLikes] = useState<Record<number, number>>({});

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (text.trim().length < 3) {
      setError("Escreva ao menos três caracteres.");
      return;
    }
    setBusy(true);
    setError(null);
    try {
      const res = await fetch("/api/comments", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ content: text.trim(), type, ...scope }),
      });
      if (!res.ok) {
        const data = await res.json().catch(() => ({}));
        setError(data?.error ?? "Não foi possível publicar agora.");
        return;
      }
      setText("");
      router.refresh();
    } catch {
      setError("Falha de conexão. Tente novamente.");
    } finally {
      setBusy(false);
    }
  };

  const report = async (targetType: string, targetId: number) => {
    try {
      await fetch("/api/reports", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ targetType, targetId, reason: "conteudo_suspeito" }),
      });
      alert("Denúncia registrada para revisão humana. Nada é removido automaticamente.");
    } catch {
      /* ignore */
    }
  };

  return (
    <section>
      <div className="rule pt-3 flex items-baseline justify-between gap-4">
        <span className="label text-ink">{heading}</span>
        <span className="label text-muted tnum">{comments.length} COMENTÁRIOS</span>
      </div>

      <form onSubmit={submit} className="mt-5 border border-line bg-panel p-4">
        <div className="flex flex-wrap gap-2">
          {Object.entries(COMMENT_TYPES).map(([key, meta]) => (
            <button
              key={key}
              type="button"
              onClick={() => setType(key)}
              className="label px-2.5 py-2 border transition-colors"
              style={{
                borderColor: type === key ? "var(--ink)" : "var(--line)",
                background: type === key ? "var(--ink)" : "transparent",
                color: type === key ? "var(--paper)" : "var(--muted)",
              }}
              title={`Marcar comentário como ${meta.label}`}
            >
              {meta.icon} {meta.label}
            </button>
          ))}
        </div>

        <textarea
          value={text}
          onChange={(e) => setText(e.target.value)}
          rows={3}
          placeholder="Contribua com contexto, fonte ou uma pergunta honesta."
          className="w-full mt-3 bg-transparent border border-line p-3 text-sm text-ink placeholder:text-muted outline-none focus:border-ink transition-colors resize-y"
        />

        <div className="mt-3 flex flex-wrap items-center gap-3 justify-between">
          <span className="label text-muted" style={{ fontSize: 9.5 }}>
            A etiqueta descreve o tipo de afirmação — não determina a verdade do comentário.
          </span>
          <button
            type="submit"
            disabled={busy}
            className="label px-4 py-2.5 text-white disabled:opacity-60"
            style={{ background: "var(--wire)" }}
          >
            {busy ? "PUBLICANDO…" : "PUBLICAR"}
          </button>
        </div>
        {error ? <p className="label mt-3" style={{ color: "var(--wire)" }}>{error}</p> : null}
      </form>

      <ul className="mt-6 divide-y divide-line">
        {comments.map((c) => {
          const liked = likes[c.id] ?? c.likes;
          return (
            <li key={c.id} className="py-5">
              <div className="flex gap-3">
                <Avatar name={c.user?.name ?? "Leitor"} size={34} />
                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-x-3 gap-y-1">
                    <span className="text-sm font-semibold text-ink">{c.user?.name ?? "Leitor"}</span>
                    <span className="label text-muted tnum">{timeAgo(c.createdAt)}</span>
                    <span
                      className="label px-2 py-1"
                      style={{ background: "var(--sunk)", color: "var(--ink2)" }}
                    >
                      {COMMENT_TYPES[c.type]?.icon} {COMMENT_TYPES[c.type]?.label ?? "COMENTÁRIO"}
                    </span>
                  </div>

                  <p className="text-[15px] text-ink2 leading-relaxed mt-2">{c.content}</p>

                  <div className="mt-3 flex flex-wrap items-center gap-x-5 gap-y-2">
                    <button
                      type="button"
                      onClick={() => setLikes((l) => ({ ...l, [c.id]: liked + 1 }))}
                      className="label inline-flex items-center gap-1.5 text-muted hover:text-ink transition-colors"
                    >
                      <ThumbsUp size={12} /> {liked}
                    </button>
                    <span className="label inline-flex items-center gap-1.5 text-muted">
                      <MessageSquare size={12} /> {(c.replies ?? []).length} RESPOSTAS
                    </span>
                    <button
                      type="button"
                      onClick={() => report("comentario", c.id)}
                      className="label inline-flex items-center gap-1.5 text-muted hover:text-ink transition-colors"
                    >
                      <Flag size={12} /> DENUNCIAR
                    </button>
                  </div>

                  {(c.replies ?? []).length ? (
                    <ul className="mt-4 pl-4 border-l border-line space-y-4">
                      {c.replies!.map((r) => (
                        <li key={r.id} className="flex gap-3">
                          <Avatar name={r.user?.name ?? "Leitor"} size={26} />
                          <div className="min-w-0">
                            <div className="flex flex-wrap items-center gap-x-3">
                              <span className="text-[13px] font-semibold text-ink">{r.user?.name ?? "Leitor"}</span>
                              <span className="label text-muted tnum" style={{ fontSize: 9.5 }}>
                                {timeAgo(r.createdAt)}
                              </span>
                              <span className="label text-muted" style={{ fontSize: 9.5 }}>
                                {COMMENT_TYPES[r.type]?.icon} {COMMENT_TYPES[r.type]?.label}
                              </span>
                            </div>
                            <p className="text-sm text-ink2 leading-relaxed mt-1.5">{r.content}</p>
                          </div>
                        </li>
                      ))}
                    </ul>
                  ) : null}
                </div>
              </div>
            </li>
          );
        })}
      </ul>

      <p className="label text-muted leading-[1.8] mt-6 border-t border-line pt-4">{MODERATION_RULE}</p>
    </section>
  );
}
