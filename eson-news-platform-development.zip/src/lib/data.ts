import { and, desc, eq, ilike, inArray, ne, or, sql } from "drizzle-orm";
import { db } from "@/db";
import {
  articles,
  collectionRuns,
  comments,
  discussions,
  events,
  investigationSources,
  investigations,
  claims,
  notifications,
  reports,
  replies,
  savedItems,
  sources,
  users,
} from "@/db/schema";

export const DEMO_USER_ID = 4;

/* ------------------------------------------------------------------ */
/* events                                                              */
/* ------------------------------------------------------------------ */
export type EventRow = typeof events.$inferSelect;
export type ArticleRow = typeof articles.$inferSelect;
export type InvestigationRow = typeof investigations.$inferSelect;
export type CommentRow = typeof comments.$inferSelect;
export type UserRow = typeof users.$inferSelect;

export async function getEvents(limit = 8, category?: string) {
  const rows = await db
    .select()
    .from(events)
    .where(category ? eq(events.category, category) : undefined)
    .orderBy(desc(events.importanceScore))
    .limit(limit);
  return rows;
}

export async function getLiveEvent() {
  const [row] = await db
    .select()
    .from(events)
    .where(eq(events.isLive, true))
    .orderBy(desc(events.importanceScore))
    .limit(1);
  return row ?? null;
}

export async function getEvent(id: number) {
  const [row] = await db.select().from(events).where(eq(events.id, id)).limit(1);
  return row ?? null;
}

/* ------------------------------------------------------------------ */
/* articles                                                            */
/* ------------------------------------------------------------------ */
export async function getArticles(opts: { category?: string; limit?: number; featured?: boolean; eventId?: number } = {}) {
  const conds = [ne(articles.isHidden, true)];
  if (opts.category) conds.push(eq(articles.category, opts.category));
  if (opts.eventId) conds.push(eq(articles.eventId, opts.eventId));
  if (opts.featured) conds.push(eq(articles.isFeatured, true));
  return db
    .select()
    .from(articles)
    .where(and(...conds))
    .orderBy(desc(articles.publishedAt))
    .limit(opts.limit ?? 12);
}

export async function getArticle(id: number) {
  const [row] = await db.select().from(articles).where(eq(articles.id, id)).limit(1);
  return row ?? null;
}

export async function getRelatedArticles(article: ArticleRow) {
  const sameEvent = await db
    .select()
    .from(articles)
    .where(and(eq(articles.eventId, article.eventId ?? -1), ne(articles.id, article.id), ne(articles.isHidden, true)))
    .orderBy(desc(articles.publishedAt))
    .limit(6);
  if (sameEvent.length >= 3) return sameEvent;
  const byCat = await db
    .select()
    .from(articles)
    .where(and(eq(articles.category, article.category), ne(articles.id, article.id), ne(articles.isHidden, true)))
    .orderBy(desc(articles.publishedAt))
    .limit(6);
  return [...sameEvent, ...byCat.filter((a) => a.eventId !== article.eventId)].slice(0, 5);
}

/** All articles grouped under one event — the "MESMO ACONTECIMENTO" cluster. */
export async function getEventCluster(eventId: number) {
  return db
    .select({
      article: articles,
      sourceName: sources.name,
      sourceDomain: sources.domain,
      sourceType: sources.type,
    })
    .from(articles)
    .leftJoin(sources, eq(articles.sourceId, sources.id))
    .where(and(eq(articles.eventId, eventId), ne(articles.isHidden, true)))
    .orderBy(desc(articles.publishedAt));
}

/* ------------------------------------------------------------------ */
/* investigations                                                      */
/* ------------------------------------------------------------------ */
export async function getInvestigations(limit = 10) {
  return db.select().from(investigations).orderBy(desc(investigations.updatedAt)).limit(limit);
}

export async function getInvestigation(id: number) {
  const [row] = await db.select().from(investigations).where(eq(investigations.id, id)).limit(1);
  return row ?? null;
}

export async function getInvestigationByRef(ref: string) {
  const [row] = await db.select().from(investigations).where(eq(investigations.ref, ref)).limit(1);
  return row ?? null;
}

export async function getClaims(investigationId: number) {
  return db.select().from(claims).where(eq(claims.investigationId, investigationId)).orderBy(claims.id);
}

export async function getInvestigationSources(investigationId: number) {
  return db
    .select()
    .from(investigationSources)
    .where(eq(investigationSources.investigationId, investigationId))
    .orderBy(investigationSources.id);
}

/* ------------------------------------------------------------------ */
/* community                                                           */
/* ------------------------------------------------------------------ */
export type CommentWithUser = CommentRow & { user: UserRow | null };

export async function getComments(scope: { articleId?: number; eventId?: number; investigationId?: number }) {
  const conds = [];
  if (scope.articleId) conds.push(eq(comments.articleId, scope.articleId));
  if (scope.eventId) conds.push(eq(comments.eventId, scope.eventId));
  if (scope.investigationId) conds.push(eq(comments.investigationId, scope.investigationId));
  if (!conds.length) return [] as CommentWithUser[];
  const rows = await db
    .select({ comment: comments, user: users })
    .from(comments)
    .leftJoin(users, eq(comments.userId, users.id))
    .where(or(...conds))
    .orderBy(desc(comments.createdAt))
    .limit(50);
  return rows.map((r) => ({ ...r.comment, user: r.user })) as CommentWithUser[];
}

export async function getReplies(commentIds: number[]) {
  if (!commentIds.length) return [];
  const ids = commentIds.map((id) => sql`${id}`);
  const rows = await db
    .select({ reply: replies, user: users })
    .from(replies)
    .leftJoin(users, eq(replies.userId, users.id))
    .where(sql`${replies.commentId} in (${sql.join(ids, sql`, `)})`)
    .orderBy(replies.id);
  return rows.map((r) => ({ ...r.reply, user: r.user }));
}

export async function getDiscussions(limit = 12) {
  return db
    .select({ discussion: discussions, author: users })
    .from(discussions)
    .leftJoin(users, eq(discussions.authorId, users.id))
    .orderBy(desc(discussions.heat))
    .limit(limit);
}

export async function getCommentsByUser(userId: number) {
  const rows = await db
    .select({ comment: comments, article: articles, investigation: investigations })
    .from(comments)
    .leftJoin(articles, eq(comments.articleId, articles.id))
    .leftJoin(investigations, eq(comments.investigationId, investigations.id))
    .where(eq(comments.userId, userId))
    .orderBy(desc(comments.createdAt))
    .limit(20);
  return rows;
}

/* ------------------------------------------------------------------ */
/* user state                                                          */
/* ------------------------------------------------------------------ */
export async function getCurrentUser() {
  const [row] = await db.select().from(users).where(eq(users.id, DEMO_USER_ID)).limit(1);
  return row ?? null;
}

export async function getSaved(userId: number) {
  return db.select().from(savedItems).where(eq(savedItems.userId, userId)).orderBy(desc(savedItems.createdAt));
}

export async function getNotifications(userId: number) {
  return db.select().from(notifications).where(eq(notifications.userId, userId)).orderBy(desc(notifications.createdAt));
}

export async function getUnreadCount(userId: number) {
  const [row] = await db
    .select({ n: sql<number>`count(*)::int` })
    .from(notifications)
    .where(and(eq(notifications.userId, userId), eq(notifications.read, false)));
  return row?.n ?? 0;
}

/* ------------------------------------------------------------------ */
/* search                                                              */
/* ------------------------------------------------------------------ */
export type SearchResults = {
  articles: ArticleRow[];
  events: EventRow[];
  investigations: InvestigationRow[];
  discussionsList: Awaited<ReturnType<typeof getDiscussions>>;
};

export async function searchAll(q: string): Promise<SearchResults> {
  const term = `%${q.trim()}%`;
  if (!q.trim()) return { articles: [], events: [], investigations: [], discussionsList: [] };
  const [arts, evs, invs, disc] = await Promise.all([
    db
      .select()
      .from(articles)
      .where(and(ne(articles.isHidden, true), or(ilike(articles.title, term), ilike(articles.description, term), ilike(articles.body, term))))
      .orderBy(desc(articles.publishedAt))
      .limit(20),
    db
      .select()
      .from(events)
      .where(or(ilike(events.title, term), ilike(events.summary, term)))
      .orderBy(desc(events.importanceScore))
      .limit(10),
    db
      .select()
      .from(investigations)
      .where(or(ilike(investigations.title, term), ilike(investigations.question, term), ilike(investigations.summary, term)))
      .orderBy(desc(investigations.updatedAt))
      .limit(10),
    db
      .select({ discussion: discussions, author: users })
      .from(discussions)
      .leftJoin(users, eq(discussions.authorId, users.id))
      .where(or(ilike(discussions.title, term), ilike(discussions.contextText, term)))
      .orderBy(desc(discussions.heat))
      .limit(10),
  ]);
  return { articles: arts, events: evs, investigations: invs, discussionsList: disc };
}

/* ------------------------------------------------------------------ */
/* admin                                                               */
/* ------------------------------------------------------------------ */
export async function getRecentComments(limit = 16) {
  const rows = await db
    .select({ comment: comments, user: users, article: articles, investigation: investigations, event: events })
    .from(comments)
    .leftJoin(users, eq(comments.userId, users.id))
    .leftJoin(articles, eq(comments.articleId, articles.id))
    .leftJoin(investigations, eq(comments.investigationId, investigations.id))
    .leftJoin(events, eq(comments.eventId, events.id))
    .orderBy(desc(comments.createdAt))
    .limit(limit);
  return rows;
}

export type SavedResolved = {
  id: number;
  itemType: string;
  createdAt: Date;
  title: string;
  href: string;
  meta: string;
};

export async function getSavedResolved(userId: number): Promise<SavedResolved[]> {
  const saved = await getSaved(userId);
  const ids = (type: string) => saved.filter((s) => s.itemType === type).map((s) => s.itemId);

  const artIds = ids("noticia");
  const invIds = ids("fato");
  const evIds = ids("acontecimento");
  const discIds = ids("discussao");

  const arts: ArticleRow[] = artIds.length
    ? await db.select().from(articles).where(inArray(articles.id, artIds))
    : [];
  const invs: InvestigationRow[] = invIds.length
    ? await db.select().from(investigations).where(inArray(investigations.id, invIds))
    : [];
  const evs: EventRow[] = evIds.length
    ? await db.select().from(events).where(inArray(events.id, evIds))
    : [];
  const disc = discIds.length ? await db.select().from(discussions).where(inArray(discussions.id, discIds)) : [];

  const out: SavedResolved[] = [];
  for (const s of saved) {
    if (s.itemType === "noticia") {
      const row = arts.find((a) => a.id === s.itemId);
      if (row)
        out.push({
          id: s.id,
          itemType: s.itemType,
          createdAt: s.createdAt,
          title: row.title,
          href: `/noticia/${row.id}`,
          meta: `${row.source} · ${row.category}`,
        });
    } else if (s.itemType === "fato") {
      const row = invs.find((a) => a.id === s.itemId);
      if (row)
        out.push({
          id: s.id,
          itemType: s.itemType,
          createdAt: s.createdAt,
          title: row.title,
          href: `/fato/${row.id}`,
          meta: `${row.ref} · investigação`,
        });
    } else if (s.itemType === "acontecimento") {
      const row = evs.find((a) => a.id === s.itemId);
      if (row)
        out.push({
          id: s.id,
          itemType: s.itemType,
          createdAt: s.createdAt,
          title: row.title,
          href: `/acontecimento/${row.id}`,
          meta: `acontecimento · ${row.sourcesCount} fontes`,
        });
    } else if (s.itemType === "discussao") {
      const row = disc.find((a) => a.id === s.itemId);
      if (row)
        out.push({
          id: s.id,
          itemType: s.itemType,
          createdAt: s.createdAt,
          title: row.title,
          href: "/praca",
          meta: `discussão · ${row.comments} comentários`,
        });
    }
  }
  return out;
}

export async function getAdminStats() {
  const [collected] = await db.select({ n: sql<number>`count(*)::int` }).from(articles);
  const [published] = await db
    .select({ n: sql<number>`count(*)::int` })
    .from(articles)
    .where(eq(articles.isHidden, false));
  const [activeEvents] = await db
    .select({ n: sql<number>`count(*)::int` })
    .from(events)
    .where(eq(events.status, "ativo"));
  const [invest] = await db.select({ n: sql<number>`count(*)::int` }).from(investigations);
  const [userCount] = await db.select({ n: sql<number>`count(*)::int` }).from(users);
  const [commentCount] = await db.select({ n: sql<number>`count(*)::int` }).from(comments);
  const [openReports] = await db
    .select({ n: sql<number>`count(*)::int` })
    .from(reports)
    .where(ne(reports.status, "rejeitada"));
  const [sourceCount] = await db.select({ n: sql<number>`count(*)::int` }).from(sources);
  const runs = await db.select().from(collectionRuns).orderBy(desc(collectionRuns.createdAt)).limit(12);
  return {
    collected: collected?.n ?? 0,
    published: published?.n ?? 0,
    activeEvents: activeEvents?.n ?? 0,
    investigations: invest?.n ?? 0,
    users: userCount?.n ?? 0,
    comments: commentCount?.n ?? 0,
    openReports: openReports?.n ?? 0,
    sources: sourceCount?.n ?? 0,
    runs,
    apiErrors: runs.filter((r) => r.status === "erro").length,
    queue: Math.max(0, (collected?.n ?? 0) - (published?.n ?? 0)),
  };
}

export async function getAdminSources() {
  return db.select().from(sources).orderBy(sources.name);
}

export async function getAdminReports() {
  return db
    .select({ report: reports, user: users })
    .from(reports)
    .leftJoin(users, eq(reports.userId, users.id))
    .orderBy(desc(reports.createdAt))
    .limit(30);
}

export async function getAdminUsers() {
  return db.select().from(users).orderBy(desc(users.reputation)).limit(30);
}

export async function getAdminArticles(limit = 30) {
  return db.select().from(articles).orderBy(desc(articles.publishedAt)).limit(limit);
}

export async function getAdminInvestigations() {
  return db.select().from(investigations).orderBy(desc(investigations.updatedAt));
}
