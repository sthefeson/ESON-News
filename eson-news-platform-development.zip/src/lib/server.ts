const buckets = new Map<string, { n: number; t: number }>();

/** Janela fixa em memória. Em produção, trocar por armazenamento compartilhado. */
export function rateLimit(key: string, limit = 12, windowMs = 60_000) {
  const now = Date.now();
  const bucket = buckets.get(key);
  if (!bucket || now - bucket.t > windowMs) {
    buckets.set(key, { n: 1, t: now });
    return { ok: true, remaining: limit - 1 };
  }
  bucket.n += 1;
  return { ok: bucket.n <= limit, remaining: Math.max(0, limit - bucket.n) };
}

export function clientIp(req: Request) {
  const fwd = req.headers.get("x-forwarded-for");
  if (fwd) return fwd.split(",")[0]!.trim();
  return req.headers.get("x-real-ip") ?? "local";
}

export function jsonError(message: string, status = 400) {
  return Response.json({ error: message }, { status });
}

/** Validacao de entrada: remove caracteres de controle e limita o tamanho. */
export function sanitizeText(value: unknown, max = 4000): string {
  if (typeof value !== "string") return "";
  const clean = value
    .split("")
    .filter((ch) => {
      const code = ch.charCodeAt(0);
      return code >= 32 && code !== 127;
    })
    .join("");
  return clean.trim().slice(0, max);
}
