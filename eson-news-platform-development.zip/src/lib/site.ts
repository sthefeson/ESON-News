export const SLOGAN = "O mundo em um só lugar.";

export type Category = {
  slug: string;
  name: string;
  blurb: string;
  sub: string[];
};

export const CATEGORIES: Category[] = [
  {
    slug: "brasil",
    name: "Brasil",
    blurb: "O país em camadas: poder, cidades, segurança, ciência e cultura.",
    sub: ["Política", "Economia", "Segurança pública", "Sociedade", "Ciência", "Cultura"],
  },
  {
    slug: "mundo",
    name: "Mundo",
    blurb: "Conflitos, diplomacia, eleições e desastres vistos de fora.",
    sub: ["Conflitos", "Diplomacia", "Economia internacional", "Desastres", "Eleições", "Relações internacionais"],
  },
  {
    slug: "economia",
    name: "Economia",
    blurb: "Mercados, inflação, juros, emprego e o que os números realmente dizem.",
    sub: ["Mercados", "Inflação", "Juros", "Emprego", "Empresas", "Moedas", "Investimentos"],
  },
  {
    slug: "politica",
    name: "Política",
    blurb: "Acontecimentos políticos apresentados de forma factual, com fontes e posições à vista.",
    sub: ["Congresso", "Governo", "Eleições", "Partidos", "Poderes", "Transparência"],
  },
  {
    slug: "saude",
    name: "Saúde",
    blurb: "Pesquisas, descobertas, políticas públicas e saúde coletiva.",
    sub: ["Pesquisas", "Descobertas", "Políticas públicas", "Epidemias", "Medicina"],
  },
  {
    slug: "esportes",
    name: "Esportes",
    blurb: "Futebol, basquete, vôlei, automobilismo, lutas e mais.",
    sub: ["Futebol", "Basquete", "Vôlei", "Automobilismo", "Lutas"],
  },
  {
    slug: "tecnologia",
    name: "Tecnologia",
    blurb: "IA, computadores, internet, segurança digital e inovação.",
    sub: ["IA", "Computadores", "Smartphones", "Internet", "Segurança digital"],
  },
  {
    slug: "ciencia",
    name: "Ciência",
    blurb: "Astronomia, física, biologia, espaço e descobertas.",
    sub: ["Astronomia", "Física", "Biologia", "Espaço", "Pesquisas"],
  },
  {
    slug: "meio-ambiente",
    name: "Meio Ambiente",
    blurb: "Clima, natureza, energia, desastres e sustentabilidade.",
    sub: ["Clima", "Natureza", "Energia", "Desastres", "Sustentabilidade"],
  },
  {
    slug: "cultura",
    name: "Cultura",
    blurb: "Cinema, música, televisão, literatura, arte e entretenimento.",
    sub: ["Cinema", "Música", "Televisão", "Literatura", "Arte"],
  },
];

export const NAV_DESKTOP = [
  { slug: "inicio", name: "Início", href: "/" },
  ...CATEGORIES.map((c) => ({ slug: c.slug, name: c.name, href: `/categoria/${c.slug}` })),
  { slug: "fato", name: "Fato", href: "/fato" },
  { slug: "praca", name: "Praça Global", href: "/praca" },
];

export const NAV_MOBILE = [
  { name: "Início", href: "/", icon: "home" },
  { name: "Explorar", href: "/explorar", icon: "compass" },
  { name: "Fato", href: "/fato", icon: "searchcheck" },
  { name: "Praça", href: "/praca", icon: "globe" },
  { name: "Perfil", href: "/perfil", icon: "user" },
];

/* ---------------- Radar Eson ---------------- */

export const RADAR_NOTE =
  "O Radar Eson combina sinais de cobertura, atualização, diversidade de fontes e alcance para organizar acontecimentos. O indicador não representa a verdade ou importância absoluta de uma notícia.";

export const RADAR_SIGNALS = [
  { key: "Intensidade da cobertura", hint: "volume relativo de publicações no período" },
  { key: "Número de fontes", hint: "fontes distintas relacionadas ao mesmo acontecimento" },
  { key: "Velocidade de crescimento", hint: "ritmo de novas publicações por hora" },
  { key: "Alcance internacional", hint: "quantos países e idiomas cobrem o tema" },
  { key: "Atualizações recentes", hint: "quantas revisões a história teve nas últimas horas" },
  { key: "Relevância temática", hint: "peso do assunto conforme a pauta editorial" },
];

export function radarBand(score: number) {
  if (score >= 90) return { label: "IMPACTO GLOBAL", color: "var(--wire)", cls: "🔥" };
  if (score >= 70) return { label: "ALTA RELEVÂNCIA", color: "var(--heat)", cls: "🟠" };
  if (score >= 55) return { label: "RELEVANTE", color: "var(--heat2)", cls: "🟡" };
  if (score >= 40) return { label: "EM OBSERVAÇÃO", color: "var(--muted)", cls: "🔵" };
  return { label: "BAIXA INTENSIDADE", color: "var(--muted)", cls: "⚪" };
}

/* ---------------- FATО ---------------- */

export const FATO_SUBTITLE = "Investigue antes de concluir.";

export const FATO_CLASSES = [
  { key: "confirmado", icon: "✅", name: "CONFIRMADO", desc: "Evidência sólida e verificável." },
  { key: "bem_sustentado", icon: "🟢", name: "BEM SUSTENTADO", desc: "Múltiplas evidências independentes apontam para a mesma conclusão." },
  { key: "em_investigacao", icon: "🟡", name: "EM INVESTIGAÇÃO", desc: "Existem indícios, mas ainda faltam confirmações." },
  { key: "alegacao", icon: "🟠", name: "ALEGAÇÃO", desc: "Existe uma afirmação pública, mas não evidência suficiente." },
  { key: "contradito", icon: "🔴", name: "CONTRADITO", desc: "Existem evidências relevantes contrariando a afirmação." },
  { key: "nao_verificavel", icon: "⚫", name: "NÃO VERIFICÁVEL", desc: "Não há informação suficiente para concluir." },
];

export const FATO_STAGES = [
  { n: "01", t: "Entender a pergunta", d: "Identificamos assunto, pessoas, organizações, local, período, a afirmação principal e possíveis afirmações secundárias." },
  { n: "02", t: "Buscar informações", d: "Documentos oficiais, órgãos públicos, pesquisas acadêmicas, dados primários, agências, veículos reconhecidos, especialistas e comunidades — estas últimas apenas para mapear rumores." },
  { n: "03", t: "Cruzamento", d: "Comparamos quem afirma, quando afirmou, que evidência apresentou, se fontes independentes confirmam, se existe documento, se há contradições e se informação antiga está sendo apresentada como nova." },
  { n: "04", t: "Classificação", d: "Cada afirmação recebe uma situação explícita. Volume de publicações nunca é tratado como prova." },
];

export const RUMOR_NOTE = "Volume de circulação não representa veracidade.";

export const AI_DISCLOSURE =
  "Conteúdo sintetizado pelo Eson News a partir das fontes indicadas.";
export const UNCERTAINTY_NOTE =
  "As informações disponíveis ainda não permitem uma conclusão definitiva.";
export const DEMO_NOTE =
  "Dados de demonstração — conteúdo fictício exibido para exercício de interface. Nenhuma manchete desta página é jornalismo real.";

/* ---------------- Praça Global ---------------- */

export const COMMENT_TYPES: Record<string, { icon: string; label: string }> = {
  opiniao: { icon: "💭", label: "OPINIÃO" },
  fonte: { icon: "🔗", label: "FONTE" },
  pergunta: { icon: "❓", label: "PERGUNTA" },
  dado: { icon: "📊", label: "DADO" },
  alegacao: { icon: "⚠️", label: "ALEGAÇÃO" },
};

export const MODERATION_ACTIONS = [
  "Denunciar",
  "Bloquear usuário",
  "Silenciar discussão",
  "Solicitar revisão",
  "Suspensão (moderação)",
  "Banimento (moderação)",
];

export const MODERATION_RULE =
  "A moderação age sobre spam, flood, discurso abusivo, ameaças, links suspeitos, tentativa de manipulação, conteúdo ilegal e contas automatizadas. Nenhum conteúdo é removido automaticamente por discordar de uma opinião.";

export const REPUTATION_RULE =
  "Reputação é construída por comportamento: fontes citadas, participação consistente, correções reconhecidas e ausência de infrações. Nunca por concordância política.";

/* ---------------- relevância ---------------- */

export const RELEVANCE_SIGNALS = [
  "Quantidade de fontes",
  "Independência das fontes",
  "Recência",
  "Velocidade de crescimento",
  "Alcance geográfico",
  "Atualizações",
  "Importância temática",
  "Existência de fontes primárias",
];
