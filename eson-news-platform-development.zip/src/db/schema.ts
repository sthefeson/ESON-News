import {
  pgTable,
  serial,
  varchar,
  text,
  integer,
  boolean,
  timestamp,
  jsonb,
  index,
  unique,
} from "drizzle-orm/pg-core";

/* ------------------------------------------------------------------ */
/* users                                                               */
/* ------------------------------------------------------------------ */
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 160 }).notNull(),
  username: varchar("username", { length: 64 }).notNull().unique(),
  email: varchar("email", { length: 200 }).notNull().unique(),
  avatar: text("avatar"),
  bio: text("bio"),
  role: varchar("role", { length: 32 }).notNull().default("reader"),
  reputation: integer("reputation").notNull().default(0),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

/* ------------------------------------------------------------------ */
/* sources                                                             */
/* ------------------------------------------------------------------ */
export const sources = pgTable("sources", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 160 }).notNull(),
  domain: varchar("domain", { length: 200 }).notNull(),
  url: text("url").notNull(),
  type: varchar("type", { length: 40 }).notNull().default("agencia"),
  country: varchar("country", { length: 64 }),
  language: varchar("language", { length: 16 }).default("pt"),
  reliabilityMetadata: jsonb("reliability_metadata").$type<Record<string, unknown>>(),
  active: boolean("active").notNull().default(true),
});

/* ------------------------------------------------------------------ */
/* events  (agrupamento inteligente)                                   */
/* ------------------------------------------------------------------ */
export const events = pgTable("events", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  summary: text("summary").notNull(),
  category: varchar("category", { length: 64 }).notNull(),
  importanceScore: integer("importance_score").notNull().default(0),
  status: varchar("status", { length: 32 }).notNull().default("ativo"),
  sourcesCount: integer("sources_count").notNull().default(0),
  growth: integer("growth").notNull().default(0),
  reach: integer("reach").notNull().default(0),
  velocity: integer("velocity").notNull().default(0),
  updatesCount: integer("updates_count").notNull().default(0),
  primarySourceCount: integer("primary_source_count").notNull().default(0),
  heroImage: text("hero_image"),
  isLive: boolean("is_live").notNull().default(false),
  lastUpdate: timestamp("last_update"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

/* ------------------------------------------------------------------ */
/* articles                                                            */
/* ------------------------------------------------------------------ */
export const articles = pgTable(
  "articles",
  {
    id: serial("id").primaryKey(),
    title: text("title").notNull(),
    subtitle: text("subtitle"),
    description: text("description"),
    url: text("url").notNull(),
    sourceId: integer("source_id").references(() => sources.id),
    source: varchar("source", { length: 160 }).notNull(),
    domain: varchar("domain", { length: 200 }),
    author: varchar("author", { length: 160 }),
    imageUrl: text("image_url"),
    publishedAt: timestamp("published_at").notNull(),
    discoveredAt: timestamp("discovered_at").notNull().defaultNow(),
    category: varchar("category", { length: 64 }).notNull(),
    language: varchar("language", { length: 16 }).notNull().default("pt"),
    eventId: integer("event_id").references(() => events.id),
    body: text("body"),
    entities: jsonb("entities").$type<string[]>(),
    keywords: jsonb("keywords").$type<string[]>(),
    isFeatured: boolean("is_featured").notNull().default(false),
    isHidden: boolean("is_hidden").notNull().default(false),
    demo: boolean("demo").notNull().default(true),
  },
  (t) => [index("articles_event_idx").on(t.eventId), index("articles_category_idx").on(t.category)],
);

/* ------------------------------------------------------------------ */
/* investigations  (FATО)                                              */
/* ------------------------------------------------------------------ */
export const investigations = pgTable("investigations", {
  id: serial("id").primaryKey(),
  ref: varchar("ref", { length: 16 }).notNull().unique(),
  question: text("question").notNull(),
  title: text("title").notNull(),
  summary: text("summary").notNull(),
  status: varchar("status", { length: 40 }).notNull().default("aberta"),
  category: varchar("category", { length: 64 }).notNull(),
  coverImage: text("cover_image"),
  intro: text("intro"),
  confirmed: jsonb("confirmed").$type<string[]>(),
  unconfirmed: jsonb("unconfirmed").$type<string[]>(),
  contested: jsonb("contested").$type<string[]>(),
  circulating: jsonb("circulating").$type<string[]>(),
  timeline: jsonb("timeline").$type<{ at: string; text: string }[]>(),
  methodology: jsonb("methodology").$type<Record<string, unknown>>(),
  rumor: jsonb("rumor").$type<Record<string, unknown>>(),
  versions: jsonb("versions").$type<{ v: number; at: string; text: string }[]>(),
  sourcesAnalyzed: integer("sources_analyzed").notNull().default(0),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const investigationSources = pgTable("investigation_sources", {
  id: serial("id").primaryKey(),
  investigationId: integer("investigation_id")
    .notNull()
    .references(() => investigations.id),
  sourceId: integer("source_id").references(() => sources.id),
  name: varchar("name", { length: 160 }).notNull(),
  url: text("url").notNull(),
  title: text("title"),
  relevance: varchar("relevance", { length: 40 }).notNull().default("apoio"),
  note: text("note"),
});

export const claims = pgTable("claims", {
  id: serial("id").primaryKey(),
  investigationId: integer("investigation_id")
    .notNull()
    .references(() => investigations.id),
  claim: text("claim").notNull(),
  status: varchar("status", { length: 32 }).notNull(),
  evidenceSummary: text("evidence_summary").notNull(),
});

/* ------------------------------------------------------------------ */
/* community                                                           */
/* ------------------------------------------------------------------ */
export const comments = pgTable("comments", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  articleId: integer("article_id").references(() => articles.id),
  eventId: integer("event_id").references(() => events.id),
  investigationId: integer("investigation_id").references(() => investigations.id),
  content: text("content").notNull(),
  type: varchar("type", { length: 24 }).notNull().default("opiniao"),
  likes: integer("likes").notNull().default(0),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const replies = pgTable("replies", {
  id: serial("id").primaryKey(),
  commentId: integer("comment_id")
    .notNull()
    .references(() => comments.id),
  userId: integer("user_id").references(() => users.id),
  content: text("content").notNull(),
  type: varchar("type", { length: 24 }).notNull().default("opiniao"),
  likes: integer("likes").notNull().default(0),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const discussions = pgTable("discussions", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  contextText: text("context_text").notNull(),
  contextType: varchar("context_type", { length: 24 }).notNull().default("noticia"),
  contextId: integer("context_id"),
  authorId: integer("user_id").references(() => users.id),
  comments: integer("comments").notNull().default(0),
  participants: integer("participants").notNull().default(0),
  heat: integer("heat").notNull().default(0),
  lastActivity: timestamp("last_activity").notNull().defaultNow(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

/* ------------------------------------------------------------------ */
/* user state                                                          */
/* ------------------------------------------------------------------ */
export const savedItems = pgTable(
  "saved_items",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id")
      .notNull()
      .references(() => users.id),
    itemType: varchar("item_type", { length: 24 }).notNull(),
    itemId: integer("item_id").notNull(),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [unique("saved_unique").on(t.userId, t.itemType, t.itemId)],
);

export const notifications = pgTable("notifications", {
  id: serial("id").primaryKey(),
  userId: integer("user_id")
    .notNull()
    .references(() => users.id),
  type: varchar("type", { length: 32 }).notNull(),
  title: varchar("title", { length: 200 }).notNull(),
  content: text("content").notNull(),
  read: boolean("read").notNull().default(false),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const reports = pgTable("reports", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  targetType: varchar("target_type", { length: 24 }).notNull(),
  targetId: integer("target_id").notNull(),
  reason: varchar("reason", { length: 64 }).notNull(),
  detail: text("detail"),
  status: varchar("status", { length: 24 }).notNull().default("aberta"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

/* ------------------------------------------------------------------ */
/* aggregation / pipeline                                               */
/* ------------------------------------------------------------------ */
export const collectionRuns = pgTable("collection_runs", {
  id: serial("id").primaryKey(),
  adapter: varchar("adapter", { length: 40 }).notNull(),
  status: varchar("status", { length: 24 }).notNull().default("ok"),
  fetched: integer("fetched").notNull().default(0),
  grouped: integer("grouped").notNull().default(0),
  published: integer("published").notNull().default(0),
  message: text("message"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});
