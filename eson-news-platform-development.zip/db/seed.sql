-- ESON NEWS EN — dados de demonstração (FICTÍCIOS, marcados como demo).
-- Nunca apresentar estes registros como jornalismo real.

TRUNCATE TABLE
  collection_runs, reports, notifications, saved_items, discussions, replies,
  comments, claims, investigation_sources, investigations, articles, events,
  sources, users
RESTART IDENTITY CASCADE;

-- ---------------------------------------------------------------- users
INSERT INTO users (name, username, email, avatar, bio, role, reputation, created_at) VALUES
 ('Marina Alvarenga','marina.a','marina@eson.news',NULL,'Editora de checagem. Interesse em dados públicos e transparência.','editor',842, now() - interval '400 days'),
 ('Rafael Tavares','rafa.t','rafa@eson.news',NULL,'Cobertura de economia internacional.','editor',760, now() - interval '380 days'),
 ('Lia Okonkwo','lia.ok','lia@eson.news',NULL,'Correspondente de mundo. Diplomacia e conflitos.',  'editor',690, now() - interval '300 days'),
 ('Bruno Sato','bruno.sato','bruno@exemplo.com',NULL,'Leitor de ciência e tecnologia.','reader',310, now() - interval '220 days'),
 ('Helena Duarte','helena.d','helena@exemplo.com',NULL,'Professora de saúde pública.',  'reader',268, now() - interval '190 days'),
 ('Caio Menezes','caio.m','caio@exemplo.com',NULL,'Acompanho mercados e política fiscal.',  'reader',154, now() - interval '120 days'),
 ('Sistema de Moderação','moderacao','mod@eson.news',NULL,'Conta operacional de moderação.','admin',1000, now() - interval '500 days');

-- -------------------------------------------------------------- sources
INSERT INTO sources (name, domain, url, type, country, language, reliability_metadata, active) VALUES
 ('Reuters','reuters.com','https://www.reuters.com','agencia','Internacional','en','{"filiacao":"agencia internacional","cobertura":"global","transparencia":"editorial publicada"}', true),
 ('BBC News','bbc.com','https://www.bbc.com/news','veiculo','Reino Unido','en','{"filiacao":"servico publico","cobertura":"global","transparencia":"manual editorial publicado"}', true),
 ('Agência Brasil','agenciabrasil.ebc.com.br','https://agenciabrasil.ebc.com.br','agencia','Brasil','pt','{"filiacao":"agencia publica federal","cobertura":"Brasil","transparencia":"carta editorial"}', true),
 ('Reuters Brasil','reuters.com','https://www.reuters.com/portugues','agencia','Brasil','pt','{"filiacao":"agencia internacional","cobertura":"global","transparencia":"editorial publicada"}', true),
 ('Folha de S.Paulo','folha.uol.com.br','https://www1.folha.uol.com.br','veiculo','Brasil','pt','{"filiacao":"jornal impresso","cobertura":"Brasil","transparencia":"manual editorial"}', true),
 ('Valor Econômico','valor.globo.com','https://valor.globo.com','veiculo','Brasil','pt','{"filiacao":"jornal economico","cobertura":"Brasil","transparencia":"manual editorial"}', true),
 ('Agência FAPESP','agencia.fapesp.br','https://agencia.fapesp.br','pesquisa','Brasil','pt','{"filiacao":"agencia de noticias cientifica","cobertura":"Brasil","transparencia":"vinculo institucional declarado"}', true),
 ('Nature','nature.com','https://www.nature.com','pesquisa','Internacional','en','{"filiacao":"periodico cientifico revisado por pares","cobertura":"global","transparencia":"politica de revisao"}', true),
 ('El País','elpais.com','https://elpais.com','veiculo','Espanha','es','{"filiacao":"jornal impresso","cobertura":"global","transparencia":"manual editorial"}', true),
 ('Nikkei','nikkei.com','https://www.nikkei.com','veiculo','Japao','ja','{"filiacao":"jornal economico","cobertura":"Asia","transparencia":"manual editorial"}', true),
 ('G1','g1.globo.com','https://g1.globo.com','veiculo','Brasil','pt','{"filiacao":"rede televisiva","cobertura":"Brasil","transparencia":"manual editorial"}', true),
 ('Ministério da Saúde','gov.br/saude','https://www.gov.br/saude','oficial','Brasil','pt','{"filiacao":"orgao publico federal","cobertura":"Brasil","transparencia":"dados abertos"}', true),
 ('Banco Central do Brasil','bcb.gov.br','https://www.bcb.gov.br','oficial','Brasil','pt','{"filiacao":"orgao publico federal","cobertura":"Brasil","transparencia":"dados abertos e atas publicadas"}', true),
 ('IPCC','ipcc.ch','https://www.ipcc.ch','oficial','Internacional','en','{"filiacao":"painel intergovernamental","cobertura":"global","transparencia":"relatorios revisados"}', true),
 ('NASA','nasa.gov','https://www.nasa.gov','oficial','Estados Unidos','en','{"filiacao":"agencia espacial publica","cobertura":"global","transparencia":"dados abertos"}', true),
 ('Fórum Aberto (comunidade)','forum.aberto.example','https://forum.aberto.example','comunidade','Internacional','multi','{"filiacao":"espaco de discussao publico","cobertura":"variavel","transparencia":"sem revisao editorial"}', true);

-- -------------------------------------------------------------- events
INSERT INTO events (id, title, summary, category, importance_score, status, sources_count, growth, reach, velocity, updates_count, primary_source_count, hero_image, is_live, last_update, created_at, updated_at) VALUES
 (1,'Nova medida econômica anunciada pelo governo','O anúncio foi feito nesta manhã e altera metas fiscais e linhas de crédito. Fontes oficiais confirmam o texto; a reação de mercados ainda está em avaliação.','economia',94,'ativo',27,62,88,91,12,3,'images/hero-agora.jpg', true, now() - interval '9 minutes', now() - interval '6 hours', now() - interval '9 minutes'),
 (2,'Cúpula climática fecha acordo sobre financiamento','Delegações aprovaram um mecanismo de financiamento após negociação prolongada. O texto final tem linguagem ambígua em dois pontos.','meio-ambiente',88,'ativo',19,47,94,74,9,4,'images/story-climate.jpg', false, now() - interval '34 minutes', now() - interval '14 hours', now() - interval '34 minutes'),
 (3,'Avanço de modelo de IA gera debate regulatório','Laboratórios publicaram novos resultados e parlamentos discutem regras de transparência e de divulgação de dados de treinamento.','tecnologia',76,'ativo',23,55,72,68,11,2,'images/story-tech.jpg', false, now() - interval '21 minutes', now() - interval '9 hours', now() - interval '21 minutes'),
 (4,'Pesquisas eleitorais apontam cenário disputado','Novos levantamentos foram divulgados com margens de erro amplas. Institutos divergem em critérios de amostragem.','politica',71,'ativo',16,33,58,52,7,5,NULL, false, now() - interval '52 minutes', now() - interval '1 day', now() - interval '52 minutes'),
 (5,'Surto de dengue mobiliza redes de saúde','Municípios relatam aumento de casos e campanhas de vacinação foram ampliadas. Dados oficiais são atualizados semanalmente.','saude',63,'ativo',14,41,44,49,8,3,NULL, false, now() - interval '1 hour', now() - interval '1 day', now() - interval '1 hour'),
 (6,'Mercados reagem à decisão de juros','Índices oscilaram após a divulgação do comunicado. Analistas divergem sobre o próximo movimento.','economia',58,'ativo',21,28,66,44,6,2,'images/story-economy.jpg', false, now() - interval '2 hours', now() - interval '1 day', now() - interval '2 hours'),
 (9,'Projeto de segurança pública avança no Congresso','A proposta foi aprovada em comissão e segue para plenário. Texto ainda pode mudar.','brasil',68,'ativo',15,36,52,47,7,2,NULL, false, now() - interval '44 minutes', now() - interval '2 days', now() - interval '44 minutes'),
 (7,'Seleção convoca elenco para as eliminatórias','Lista tem novidades oficiais divulgadas pela federação. Amistoso será no próximo mês.','esportes',51,'estavel',12,19,61,33,4,1,NULL, false, now() - interval '3 hours', now() - interval '2 days', now() - interval '3 hours'),
 (8,'Telescópio mapeia atmosfera de exoplaneta','Resultado foi publicado em periódico revisado por pares e reproduzido por equipes independentes.','ciencia',46,'estavel',9,24,70,29,3,2,NULL, false, now() - interval '5 hours', now() - interval '3 days', now() - interval '5 hours'),
 (10,'Temporada de festivais consolida calendário cultural','Instituições divulgaram programação e números de público das edições anteriores.','cultura',41,'estavel',8,12,35,22,2,1,NULL, false, now() - interval '7 hours', now() - interval '3 days', now() - interval '7 hours');

-- ------------------------------------------------------------ articles
INSERT INTO articles (id, title, subtitle, description, url, source_id, source, domain, author, image_url, published_at, discovered_at, category, language, event_id, body, entities, keywords, is_featured, is_hidden, demo) VALUES
 (1,'Governo anuncia nova medida econômica com mudança em metas fiscais','Anúncio foi feito em coletiva e altera regras de crédito direto','O texto apresentado muda cronograma de metas e cria linhas de crédito direcionadas. Economistas pedem leitura dos números completos.',
  'https://www.reuters.com/example-economica-1',1,'Reuters','reuters.com','Ana Ribeiro','images/hero-agora.jpg', now() - interval '58 minutes', now() - interval '55 minutes','economia','pt',1,
  'A equipe econômica anunciou nesta manhã um pacote que ajusta o cronograma de metas fiscais e cria duas linhas de crédito direcionadas a setores específicos. O documento oficial foi disponibilizado junto ao anúncio e contém a matriz de números referenciada pelos ministros.',
  '["Governo","Ministério da Fazenda","Banco Central"]','["metas fiscais","crédito","política econômica"]', true, false, true),

 (2,'New economic measures announced as government sets fiscal timetable','Officials published the full document alongside the announcement','The package adjusts the fiscal timetable and creates two targeted credit lines, according to the official text.',
  'https://www.bbc.com/news/example-economica-1',2,'BBC News','bbc.com','James Whitfield','images/hero-agora.jpg', now() - interval '52 minutes', now() - interval '50 minutes','economia','en',1,
  'Officials published the full document alongside the announcement, including the figures referenced during the press conference. Independent economists asked for the complete dataset before assessing the medium-term effects.',
  '["Government","Treasury"]','["fiscal policy","credit","markets"]', false, false, true),

 (3,'Governo apresenta novas medidas econômicas em coletiva','Agência divulga íntegra do documento apresentado','A publicação traz a matriz de números e o calendário de implementação das medidas.',
  'https://agenciabrasil.ebc.com.br/example-economica-1',3,'Agência Brasil','agenciabrasil.ebc.com.br','Paula Mendes','images/hero-agora.jpg', now() - interval '47 minutes', now() - interval '45 minutes','economia','pt',1,
  'A agência publicou a íntegra do documento apresentado na coletiva, incluindo o calendário de implementação e a matriz de números citada durante a fala dos ministros.',
  '["Governo","Agência Brasil"]','["medidas econômicas","crédito"]', false, false, true),

 (4,'Ministério publica íntegra do documento com números das novas regras','Texto oficial permite conferência das citações feitas na coletiva','A publicação traz anexos técnicos que não foram lidos durante o anúncio.',
  'https://www.gov.br/example-economica-integra',13,'Banco Central do Brasil','bcb.gov.br',NULL,'images/story-economy.jpg', now() - interval '40 minutes', now() - interval '38 minutes','economia','pt',1,
  'O texto oficial inclui anexos técnicos com a série histórica usada como base, informação que não foi reproduzida na fala pública. A comparação entre anexo e discurso é o principal ponto citado por analistas.',
  '["Banco Central"]','["dados abertos","metas"]', false, false, true),

 (5,'Análise: o que muda no bolso com o novo pacote econômico','Especialistas apontam efeitos diferidos por renda','Leitura preliminar depende dos anexos técnicos ainda em avaliação.',
  'https://valor.globo.com/example-economica-1',6,'Valor Econômico','valor.globo.com','Renata Coelho','images/story-economy.jpg', now() - interval '33 minutes', now() - interval '31 minutes','economia','pt',1,
  'A leitura preliminar de economistas consultados indica efeitos diferidos por faixa de renda. Não há consenso sobre o tamanho do impacto enquanto os anexos técnicos não forem conferidos integralmente.',
  '["Valor Econômico","economistas"]','["inflação","renda","crédito"]', false, false, true),

 (6,'Cúpula climática aprova mecanismo de financiamento após negociação prolongada','Texto final mantém ambiguidade em dois pontos','Delegações aprovaram o mecanismo no fim da madrugada; detalhes de implementação seguem em aberto.',
  'https://www.reuters.com/example-clima-1',1,'Reuters','reuters.com','Marion Petit','images/story-climate.jpg', now() - interval '2 hours', now() - interval '2 hours','meio-ambiente','en',2,
  'O texto final aprovado cria um mecanismo de financiamento com metas não vinculantes em dois parágrafos. Delegações confirmaram o acordo; especialistas apontam que a linguagem permite interpretações distintas sobre prazos.',
  '["Cúpula climática","IPCC","delegações"]','["financiamento climático","acordo"]', true, false, true),

 (7,'Acordo climático é aprovado, mas prazos seguem sem consenso','Versão final traz redação aberta a duas leituras','Organizações pedem esclarecimento sobre o calendário de execução.',
  'https://www1.folha.uol.com.br/example-clima-1',5,'Folha de S.Paulo','folha.uol.com.br','Diego Salles','images/story-climate.jpg', now() - interval '100 minutes', now() - interval '95 minutes','meio-ambiente','pt',2,
  'A versão final traz redação aberta a duas leituras sobre o calendário. Organizações da sociedade civil pediram esclarecimento oficial, pedido que ainda não teve resposta publicada.',
  '["Folha de S.Paulo","sociedade civil"]','["clima","prazos"]', false, false, true),

 (8,'IPCC destaca que relatórios anteriores seguem válidos para a base do acordo','Documento técnico serve de referência para as negociações','Publicações anteriores do painel são a base citada pelas delegações.',
  'https://www.ipcc.ch/example-clima-base',14,'IPCC','ipcc.ch',NULL,NULL, now() - interval '3 hours', now() - interval '3 hours','meio-ambiente','en',2,
  'Os relatórios anteriores do painel continuam sendo a base técnica citada pelas delegações. A publicação não se refere ao acordo específico, e sim aos dados usados como insumo.',
  '["IPCC"]','["relatório","financiamento"]', false, false, true),

 (9,'Novos modelos de IA intensificam debate sobre regras de transparência','Parlamentos discutem obrigação de divulgar dados de treinamento','Laboratórios publicaram resultados; texto de proposta legislativa circula em versão preliminar.',
  'https://www.reuters.com/example-ia-1',1,'Reuters','reuters.com','Tom Hargreaves','images/story-tech.jpg', now() - interval '130 minutes', now() - interval '125 minutes','tecnologia','en',3,
  'Laboratórios publicaram resultados de novos modelos enquanto parlamentos discutem regras de transparência. A proposta legislativa em circulação é preliminar e pode mudar antes do texto final.',
  '["parlamento","laboratórios de IA"]','["regulação","transparência","modelos"]', true, false, true),

 (10,'Proposta de regulação de IA avança e pede divulgação de dados de treinamento','Texto é preliminar e pode mudar','Versão atual não define método de auditoria externa.',
  'https://agenciafapesp.example/ia-regulacao',7,'Agência FAPESP','agencia.fapesp.br','Sofia Tanaka','images/story-tech.jpg', now() - interval '110 minutes', now() - interval '105 minutes','tecnologia','pt',3,
  'A versão atual da proposta pede divulgação de dados de treinamento, mas não define método de auditoria externa. Especialistas ouvidos apontam que a ausência de método enfraquece a exigência.',
  '["Agência FAPESP","pesquisadores"]','["IA","regulação","auditoria"]', false, false, true),

 (11,'Startups brasileiras avaliam impacto das regras em discussão','Setor pede clareza sobre prazos de adequação','Associações enviaram documentos à consulta pública.',
  'https://g1.globo.com/example-ia-startups',11,'G1','g1.globo.com','Luana Prado',NULL, now() - interval '90 minutes', now() - interval '88 minutes','tecnologia','pt',3,
  'Associações do setor enviaram documentos à consulta pública pedindo clareza sobre prazos. A resposta oficial ainda não foi publicada.',
  '["startups","associações"]','["consultas públicas","prazos"]', false, false, true),

 (12,'Institutos divergem sobre metodologia em novas pesquisas eleitorais','Amostras e critérios de escolha mudam entre levantamentos','Levantamentos foram divulgados na mesma semana com resultados próximos.',
  'https://www1.folha.uol.com.br/example-pesquisas',5,'Folha de S.Paulo','folha.uol.com.br','Marcos Mota',NULL, now() - interval '4 hours', now() - interval '4 hours','politica','pt',4,
  'Dois levantamentos divulgados na mesma semana mostram resultados próximos com metodologias diferentes. A comparação direta entre eles é considerada inadequada pelos próprios institutos.',
  '["institutos de pesquisa","eleições"]','["pesquisa eleitoral","amostragem"]', true, false, true),

 (13,'TSE divulga calendário oficial e regras de propaganda eleitoral','Documento traz prazos e limites vigentes','Consulta pública sobre regras segue aberta.',
  'https://www.tse.jus.br/example-calendario',3,'Agência Brasil','agenciabrasil.ebc.com.br','Carla Nunes',NULL, now() - interval '6 hours', now() - interval '6 hours','politica','pt',4,
  'O documento oficial traz o calendário e os limites vigentes. A consulta pública segue aberta e pode alterar pontos específicos do texto.',
  '["TSE","eleições"]','["calendário","propaganda"]', false, false, true),

 (14,'Municípios ampliam campanha de vacinação contra dengue','Prefeituras relatam aumento de casos nas últimas semanas','Dados oficiais são atualizados semanalmente, com defasagem declarada.',
  'https://www.gov.br/saude/dengue-campanha',12,'Ministério da Saúde','gov.br/saude',NULL,NULL, now() - interval '5 hours', now() - interval '5 hours','saude','pt',5,
  'A pasta informou ampliação da campanha em municípios com aumento de casos. Os dados são atualizados semanalmente e a defasagem é declarada na própria publicação.',
  '["Ministério da Saúde","prefeituras"]','["dengue","vacinação","saúde pública"]', true, false, true),

 (15,'Serviços de saúde relatam pressão sobre leitos em regiões metropolitanas','Ocupação varia por município segundo dado oficial','Números são divulgados em base semanal.',
  'https://agenciafapesp.example/dengue-leitos',7,'Agência FAPESP','agencia.fapesp.br','Igor Palma',NULL, now() - interval '7 hours', now() - interval '7 hours','saude','pt',5,
  'A ocupação varia bastante entre municípios da mesma região metropolitana, segundo o dado oficial. A publicação não permite inferir tendência de longo prazo.',
  '["hospitais","regiões metropolitanas"]','["leitos","ocupação"]', false, false, true),

 (16,'Banco Central mantém taxa e sinaliza avaliação de dados futuros','Comunicado usa linguagem condicional sobre próximos passos','Mercados oscilaram antes e depois da divulgação.',
  'https://www.bcb.gov.br/example-taxa',13,'Banco Central do Brasil','bcb.gov.br',NULL,'images/story-economy.jpg', now() - interval '3 hours', now() - interval '3 hours','economia','pt',6,
  'O comunicado mantém a taxa e usa linguagem condicional sobre os próximos passos, condicionando a decisão a dados futuros. A ata completa costuma ser publicada com atraso de uma semana.',
  '["Banco Central","mercados"]','["juros","selic","inflação"]', true, false, true),

 (17,'Índices oscilam após comunicado e fecham sem direção definida','Volatilidade diminui no fim do pregão','Analistas divergem sobre o próximo movimento.',
  'https://valor.globo.com/example-mercados',6,'Valor Econômico','valor.globo.com','Renata Coelho','images/story-economy.jpg', now() - interval '2 hours 30 minutes', now() - interval '2 hours 35 minutes','economia','pt',6,
  'A volatilidade caiu no fim do pregão, mas a direção do dia ficou indefinida. Analistas consultados divergem sobre o próximo movimento, sem consenso entre eles.',
  '["bolsa","mercados"]','["índices","volatilidade"]', false, false, true),

 (18,'Wall Street abre em alta moderada após decisão','Mercados asiáticos já reagiram na abertura anterior','Movimento é descrito como tático por operadores.',
  'https://www.reuters.com/example-mercados-global',1,'Reuters','reuters.com','Emily Carter',NULL, now() - interval '4 hours', now() - interval '4 hours','economia','en',6,
  'A abertura foi em alta moderada, depois de reação similar nos mercados asiáticos. Operadores descrevem o movimento como tático e de curto prazo.',
  '["Wall Street","mercados"]','["abertura","alta"]', false, false, true),

 (19,'Proposta de segurança pública é aprovada em comissão e segue ao plenário','Texto ainda pode ser alterado durante votação','Aprovada por maioria em reunião de comissão; emendas são aceitas até o plenário.',
  'https://agenciabrasil.ebc.com.br/example-seguranca',3,'Agência Brasil','agenciabrasil.ebc.com.br','Paula Mendes',NULL, now() - interval '5 hours', now() - interval '5 hours','brasil','pt',9,
  'A proposta foi aprovada por maioria em reunião de comissão e segue ao plenário, onde emendas ainda podem alterar pontos do texto. A votação final não tem data confirmada.',
  '["Congresso","comissão"]','["segurança pública","legislação"]', true, false, true),

 (20,'Governo e oposição divergem sobre impacto da proposta em comissão','Cada lado apresentou números diferentes','Os números citados têm origens distintas e não são diretamente comparáveis.',
  'https://www1.folha.uol.com.br/example-seguranca',5,'Folha de S.Paulo','folha.uol.com.br','Diego Salles',NULL, now() - interval '6 hours', now() - interval '6 hours','brasil','pt',9,
  'Os números apresentados por cada lado têm origens distintas e não são diretamente comparáveis. A reportagem indica as fontes de cada alegação sem concluir sobre qual é correta.',
  '["Governo","oposição"]','["comissão","números"]', false, false, true),

 (21,'Federação divulga lista oficial de convocados para as eliminatórias','Título tem três estreias e dois retornos','Lista publicada no site oficial da entidade.',
  'https://g1.globo.com/example-convocados',11,'G1','g1.globo.com','Sérgio Almeida',NULL, now() - interval '9 hours', now() - interval '9 hours','esportes','pt',7,
  'A lista oficial tem três estreias e dois retornos. A entidade publicou a convocação no site próprio, com nota técnica sobre cada atleta.',
  '["federação","seleção"]','["convocação","eliminatórias"]', true, false, true),

 (22,'Técnico explica critérios da lista em coletiva','Comissão técnica cita desempenho em clubes','Próximo amistoso está marcado para o mês que vem.',
  'https://www.reuters.com/example-convocados',4,'Reuters Brasil','reuters.com','Marion Petit',NULL, now() - interval '8 hours', now() - interval '8 hours','esportes','pt',7,
  'A comissão técnica citou desempenho em clubes como critério principal. O amistoso está marcado para o mês que vem, com local confirmado.',
  '["comissão técnica"]','["critérios","amistoso"]', false, false, true),

 (23,'Estudo revisado por pares mapeia composição da atmosfera de exoplaneta','Resultado foi reproduzido por duas equipes independentes','Artigo traz limitações declaradas dos instrumentos.',
  'https://www.nature.com/example-exoplaneta',8,'Nature','nature.com','H. Nakamura',NULL, now() - interval '12 hours', now() - interval '12 hours','ciencia','en',8,
  'O artigo descreve o método, as limitações declaradas dos instrumentos e a faixa de incerteza dos resultados. Duas equipes independentes relataram reprodução parcial do achado.',
  '["Nature","equipas de pesquisa"]','["exoplaneta","atmosfera","astronomia"]', true, false, true),

 (24,'NASA confirma dados da missão que sustentam parte da descoberta','Arquivo de dados é público e datado','Conjunto de dados permite conferência independente.',
  'https://www.nasa.gov/example-dados',15,'NASA','nasa.gov',NULL,NULL, now() - interval '11 hours', now() - interval '11 hours','ciencia','en',8,
  'O arquivo de dados é público e datado, permitindo conferência independente. A agência não afirma ter replicado a análise completa, apenas fornecido os dados de base.',
  '["NASA"]','["dados públicos","missão"]', false, false, true),

 (25,'Festivais divulgam programação e números da edição anterior','Público cresceu em relação à última temporada','Instituições publicaram relatórios com números auditados.',
  'https://elpais.com/example-festivais',9,'El País','elpais.com','Lucía Ferrer',NULL, now() - interval '16 hours', now() - interval '16 hours','cultura','es',10,
  'As instituições publicaram relatórios com números auditados da edição anterior. A programação da próxima temporada foi divulgada em conjunto.',
  '["festivais","instituições culturais"]','["cinema","público"]', true, false, true),

 (26,'Calendário cultural de 2026 concentra eventos em três cidades','Distribuição desigual preocupa organizadores','Levantamento reúne dados das principais casas.',
  'https://agenciafapesp.example/calendario-cultural',7,'Agência FAPESP','agencia.fapesp.br','Sofia Tanaka',NULL, now() - interval '18 hours', now() - interval '18 hours','cultura','pt',10,
  'O levantamento reúne dados das principais casas e mostra concentração em três cidades. Organizadores apontam desigualdade na distribuição dos eventos.',
  '["casas de cultura"]','["calendário","eventos"]', false, false, true),

 (27,'Japão e União Europeia assinam acordo comercial parcial','Documento reduz tarifas em itens específicos','Acordo não cobre setores de serviços.',
  'https://www.nikkei.com/example-acordo',10,'Nikkei','nikkei.com','K. Sato',NULL, now() - interval '10 hours', now() - interval '10 hours','mundo','ja',NULL,
  'O acordo reduz tarifas em itens específicos e não cobre setores de serviços. A implementação depende de ratificação nos dois blocos.',
  '["Japão","União Europeia"]','["comércio","tarifas"]', false, false, true),

 (28,'Missão humanitária recebe corredor autorizado por acordo regional','Organização informou início das operações','Prazo do corredor é de 30 dias, segundo comunicado.',
  'https://www.bbc.com/news/example-corredor',2,'BBC News','bbc.com','James Whitfield',NULL, now() - interval '2 hours 10 minutes', now() - interval '2 hours 15 minutes','mundo','en',NULL,
  'A organização informou o início das operações após autorização regional. O prazo do corredor é de 30 dias, segundo o comunicado oficial.',
  '["organização humanitária","região"]','["corredor humanitário","acordo"]', true, false, true),

 (29,'Comunidades discutem relato de apagão em fórum; não há confirmação oficial','Publicações descrevem blecaute em bairros específicos','Não localizamos documento oficial sobre o episódio.',
  'https://forum.aberto.example/apagao-relato',16,'Fórum Aberto (comunidade)','forum.aberto.example',NULL,NULL, now() - interval '3 hours 20 minutes', now() - interval '3 hours 20 minutes','mundo','multi',NULL,
  'Várias publicações relatam um apagão em bairros específicos. Não localizamos documento oficial nem confirmação de concessionária sobre o episódio, e o fórum não possui revisão editorial.',
  '["fórum","comunidade"]','["apagão","rumor"]', false, false, true);

-- ------------------------------------------------------- investigations
INSERT INTO investigations (id, ref, question, title, summary, status, category, cover_image, intro, confirmed, unconfirmed, contested, circulating, timeline, methodology, rumor, versions, sources_analyzed, created_at, updated_at) VALUES
 (1,'FATО #000184',
  'É verdade que a nova medida econômica foi aprovada sem consulta pública?',
  'O que realmente sabemos sobre a nova medida econômica',
  'Investigação sobre a origem, o conteúdo e as evidências disponíveis em torno da alegação de que o pacote fiscal foi aprovado sem qualquer consulta pública.',
  'atualizada','economia','images/fato-cover.jpg',
  'A pergunta circula em publicações desde a manhã da divulgação do pacote. Reunimos documentos oficiais, declarações públicas e a cobertura de agências para separar o que está comprovado do que ainda é alegação.',
  '["O documento oficial do pacote foi publicado no mesmo ato do anúncio e está disponível para conferência.","A ata da reunião que precedeu o anúncio foi divulgada com parte das informações redigidas.","Duas agências independentes descreveram o mesmo calendário de implementação.","O texto da proposta legislativa relacionada é preliminar e pode mudar."]',
  '["Não foi possível localizar registro de audiência pública específica sobre as duas linhas de crédito.","Não há, até o momento, publicação oficial sobre eventual impacto por faixa de renda.","A data de vigência das novas regras ainda não aparece em documento assinado."]',
  '["Alegação de que não houve nenhuma consulta: dois documentos oficiais citam período de contribuição técnica, mas não especificam quem participou.","Alegação de efeito imediato sobre preços: fontes oficiais descrevem cronograma escalonado, enquanto análises de mercado citam prazo mais curto."]',
  '["Versão A: o pacote teria sido aprovado sem nenhuma consulta, segundo publicações em rede social com alto volume de compartilhamentos.","Versão B: o pacote incluiria imposto novo sobre remessas, alegação ausente do documento oficial.","Versão C: a medida valeria a partir de imediato, em contradição com o calendário do anexo técnico."]',
  '[{"at":"D-1 · 18h40","text":"Publicações em fórum citam possível mudança de metas sem documento."},{"at":"D0 · 09h05","text":"Ministério anuncia o pacote e publica o texto oficial."},{"at":"D0 · 09h47","text":"Agência Brasil divulga a íntegra do documento."},{"at":"D0 · 10h20","text":"Reuters e BBC descrevem o mesmo calendário de implementação."},{"at":"D0 · 11h30","text":"Circulação da versão B (remessas), não encontrada em documento oficial."},{"at":"D0 · 14h00","text":"Banco Central publica anexos técnicos com série histórica."},{"at":"D+1 · 08h15","text":"Nova informação: ata parcialmente redigida é localizada."}]',
  '{"fontes_analisadas":41,"tipos":{"documentos_oficiais":6,"orgaos_publicos":4,"pesquisas":3,"agencias":9,"veiculos":8,"especialistas":7,"comunidades":4},"documentos":6,"concordancias":4,"divergencias":2,"limitacoes":"Não foi possível obter resposta formal sobre a composição do período de contribuição técnica; parte da ata está redigida. A investigação permanece aberta."}',
  '{"circulacao":"ALTA","aprox_fontes":340,"evolucao":[40,90,160,210,300,340],"onde":["rede social","fórum aberto","mensageiro público","grupos regionais"],"versoes":3,"evidencias_independentes":2,"confirmacao_oficial":"não localizada","status":"não confirmado"}',
  '[{"v":1,"at":"D0 · 15h00","text":"Publicação inicial com 22 fontes e 3 claims."},{"v":2,"at":"D0 · 21h30","text":"Inclusão dos anexos técnicos e revisão do claim sobre prazos."},{"v":3,"at":"D+1 · 08h15","text":"Nova informação encontrada: ata parcialmente redigida; seção O QUE ESTÁ CIRCULANDO atualizada."}]',
  41, now() - interval '1 day', now() - interval '3 hours'),

 (2,'FATО #000191',
  'O que sabemos sobre o acordo climático e os prazos citados?',
  'O que realmente sabemos sobre o acordo de financiamento climático',
  'Investigação sobre a linguagem ambígua do texto final e sobre quais prazos estão de fato comprometidos.',
  'atualizada','meio-ambiente','images/story-climate.jpg',
  'Duas interpretações do mesmo parágrafo circulam desde a aprovação do texto. Cruzamos o documento final, as notas das delegações e os relatórios técnicos usados como base.',
  '["O texto final foi aprovado e está publicado na íntegra.","Dois parágrafos usam linguagem não vinculante sobre prazos.","Relatórios anteriores do painel técnico são a base citada pelas delegações."]',
  '["A data de entrada em vigor do mecanismo de financiamento não consta em documento.","Não há lista pública de contribuintes iniciais."]',
  '["Alegação de que o acordo é de cumprimento obrigatório: o texto final usa linguagem não vinculante em dois pontos."]',
  '["Versão A: o acordo teria prazos obrigatórios de 12 meses.","Versão B: o financiamento teria sido integralmente alocado, o que não aparece no texto."]',
  '[{"at":"D-2 · 22h10","text":"Negociação entra em recesso sem texto."},{"at":"D-1 · 03h40","text":"Versão preliminar do texto vaza em canal de delegados."},{"at":"D0 · 06h00","text":"Texto final é aprovado e publicado."},{"at":"D0 · 10h30","text":"Organizações pedem esclarecimento sobre prazos; sem resposta publicada."}]',
  '{"fontes_analisadas":27,"tipos":{"documentos_oficiais":5,"orgaos_publicos":3,"pesquisas":4,"agencias":6,"veiculos":5,"especialistas":3,"comunidades":1},"documentos":5,"concordancias":3,"divergencias":2,"limitacoes":"Duas partes do texto permanecem sem interpretação consensual e nenhuma fonte oficial respondeu ao pedido de esclarecimento."}',
  '{"circulacao":"MÉDIA","aprox_fontes":120,"evolucao":[10,25,60,95,120],"onde":["rede social","veículo regional"],"versoes":2,"evidencias_independentes":1,"confirmacao_oficial":"parcial","status":"em investigação"}',
  '[{"v":1,"at":"D0 · 09h00","text":"Publicação inicial."},{"v":2,"at":"D0 · 18h00","text":"Inclusão do parágrafo ambíguo e dos relatórios técnicos."}]',
  27, now() - interval '2 days', now() - interval '8 hours'),

 (3,'FATО #000197',
  'De onde surgiu o rumor do apagão generalizado?',
  'O que realmente sabemos sobre o rumor de apagão generalizado',
  'Investigação sobre a origem das publicações que descrevem um blecaute em vários bairros ao mesmo tempo.',
  'aberta','mundo','images/praca.jpg',
  'As publicações apareceram quase simultaneamente em fórum e em grupos de mensageiro. Procuramos documento oficial, dado de concessionária e registro de ocorrência.',
  '["As publicações tiveram início em um fórum aberto, sem revisão editorial.","Não localizamos documento oficial sobre o episódio.","O conteúdo foi republicado com texto praticamente idêntico em ao menos três espaços."]',
  '["Não há, até o momento, confirmação de concessionária sobre interrupção.","Não foi possível estabelecer a autoria inicial das publicações."]',
  '["Alegação de apagão simultâneo em quatro cidades: sem registro em fonte oficial até esta atualização."]',
  '["Versão A: blecaute de seis horas em quatro cidades.","Versão B: variação com três cidades e duração de duas horas.","Versão C: relato com imagem antiga reaproveitada, datada de ano anterior."]',
  '[{"at":"D0 · 21h12","text":"Primeira publicação em fórum aberto."},{"at":"D0 · 22h05","text":"Republicação com texto idêntico em grupo de mensageiro."},{"at":"D+1 · 07h40","text":"Imagem associada é identificada como sendo de ano anterior."},{"at":"D+1 · 12h00","text":"Pedido de confirmação enviado a fonte oficial; sem resposta."}]',
  '{"fontes_analisadas":18,"tipos":{"documentos_oficiais":0,"orgaos_publicos":2,"pesquisas":0,"agencias":3,"veiculos":4,"especialistas":1,"comunidades":8},"documentos":0,"concordancias":1,"divergencias":3,"limitacoes":"Nenhum documento oficial foi localizado. Não há base suficiente para concluir se houve interrupção."}',
  '{"circulacao":"MÉDIA","aprox_fontes":85,"evolucao":[5,30,55,70,85],"onde":["fórum aberto","mensageiro público","rede social"],"versoes":3,"evidencias_independentes":0,"confirmacao_oficial":"não localizada","status":"não confirmado"}',
  '[{"v":1,"at":"D+1 · 09h00","text":"Publicação inicial com status EM INVESTIGAÇÃO."}]',
  18, now() - interval '1 day', now() - interval '5 hours');

INSERT INTO investigation_sources (investigation_id, source_id, name, url, title, relevance, note) VALUES
 (1,13,'Banco Central do Brasil','https://www.bcb.gov.br/example-economica-integra','Anexos técnicos do pacote econômico','apoio','Documento primário com série histórica citada na coletiva.'),
 (1,3,'Agência Brasil','https://agenciabrasil.ebc.com.br/example-economica-1','Íntegra do documento apresentado','apoio','Publicação da íntegra permite conferência das citações.'),
 (1,1,'Reuters','https://www.reuters.com/example-economica-1','Governo anuncia nova medida econômica','apoio','Descreve o mesmo calendário de implementação.'),
 (1,2,'BBC News','https://www.bbc.com/news/example-economica-1','New economic measures announced','apoio','Cobertura independente com descrição equivalente.'),
 (1,6,'Valor Econômico','https://valor.globo.com/example-economica-1','Análise: o que muda no bolso','contradiz','Aponta efeito divergente em relação ao prazo do anexo.'),
 (1,16,'Fórum Aberto (comunidade)','https://forum.aberto.example/apagao-relato','Publicações sobre consulta pública','neutro','Fórum sem revisão editorial; usado apenas para mapear a narrativa.'),
 (2,14,'IPCC','https://www.ipcc.ch/example-clima-base','Base técnica citada pelas delegações','apoio','Relatórios usados como insumo das negociações.'),
 (2,1,'Reuters','https://www.reuters.com/example-clima-1','Cúpula aprova mecanismo de financiamento','apoio','Descreve a ambiguidade de dois parágrafos.'),
 (2,5,'Folha de S.Paulo','https://www1.folha.uol.com.br/example-clima-1','Acordo aprovado, prazos sem consenso','contradiz','Indica prazo não comprometido em contraditório com alegação oficial.'),
 (3,16,'Fórum Aberto (comunidade)','https://forum.aberto.example/apagao-relato','Relato de apagão em bairros','neutro','Origem da narrativa; não é confirmação.'),
 (3,11,'G1','g1.globo.com','Busca por registro oficial','contradiz','Nenhum registro oficial localizado na busca.'),
 (3,2,'BBC News','https://www.bbc.com/news/example-corredor','Cobertura regional sem menção ao episódio','neutro','Ausência de cobertura não é evidência, mas é registrada.');

INSERT INTO claims (investigation_id, claim, status, evidence_summary) VALUES
 (1,'O documento oficial do pacote foi publicado no mesmo ato do anúncio','confirmado','Texto disponível no portal oficial desde 09h05, com anexos técnicos publicados depois.'),
 (1,'Não houve nenhuma consulta antes do anúncio','contradito','Dois documentos oficiais citam período de contribuição técnica; a composição dos participantes não é pública.'),
 (1,'A medida vigora a partir de imediato','contradito','O anexo técnico descreve calendário escalonado de vigência.'),
 (1,'Impacto imediato sobre preços ao consumidor','em_investigacao','Duas análises de mercado divergem sobre o prazo; não há dado oficial consolidado.'),
 (1,'A proposta legislativa relacionada está aprovada','alegacao','Texto em circulação é preliminar; não há registro de votação final.'),
 (2,'O texto final do acordo foi publicado','confirmado','Documento na íntegra disponível no portal da cúpula.'),
 (2,'O acordo tem prazos obrigatórios de doze meses','contradito','Dois parágrafos usam linguagem não vinculante.'),
 (2,'O financiamento está integralmente alocado','contradito','Não há tabela de alocação no texto final.'),
 (2,'Contribuintes iniciais já estão definidos','nao_verificavel','Nenhuma lista pública localizada até esta atualização.'),
 (3,'Houve apagão simultâneo em quatro cidades','nao_verificavel','Nenhum documento oficial ou registro de concessionária localizado.'),
 (3,'As publicações começaram em fórum aberto','bem_sustentado','Registro datado no fórum e republicações com texto idêntico em três espaços.'),
 (3,'A imagem associada ao relato é recente','contradito','A imagem é datada de ano anterior segundo metadados verificáveis.');

-- ------------------------------------------------------ discussions/comments
INSERT INTO discussions (id, title, context_text, context_type, context_id, author_id, comments, participants, heat, last_activity) VALUES
 (1,'O que muda de fato no novo pacote econômico?','Leio o documento oficial e vejo pontos diferentes do que circula nas redes.','noticia',1,4,48,31,92, now() - interval '12 minutes'),
 (2,'Concordam que o acordo climático deixou os prazos vagos?','Duas leituras do mesmo parágrafo estão circulando.','noticia',6,3,37,24,74, now() - interval '41 minutes'),
 (3,'Alguém tem fonte oficial sobre o apagão?','Não encontrei documento até agora, apenas republicações.','fato',3,5,26,19,66, now() - interval '1 hour'),
 (4,'Regulação de IA: quem auditaria os dados de treinamento?','A proposta não define método de auditoria externa.','noticia',9,7,22,17,58, now() - interval '2 hours'),
 (5,'Pesquisas eleitorais: comparar metodologias faz sentido?','Os institutos avisam que a comparação direta é inadequada.','noticia',12,6,19,15,47, now() - interval '3 hours');

INSERT INTO comments (id, user_id, article_id, event_id, investigation_id, content, type, likes, created_at) VALUES
 (1,4,1,1,NULL,'Li o anexo técnico e o calendário está descrito em três etapas. Deixei o link da página na discussão.','fonte',24, now() - interval '35 minutes'),
 (2,6,1,1,NULL,'Alguém sabe dizer se vale para contratos já assinados? Não achei essa parte no documento.','pergunta',11, now() - interval '28 minutes'),
 (3,5,1,1,NULL,'Minha leitura é que o efeito depende do prazo de vigência, que ainda não foi publicado. Opinião pessoal.','opiniao',8, now() - interval '20 minutes'),
 (4,7,14,5,NULL,'A atualização dos dados é semanal e isso atrasa a leitura dos números.','dado',15, now() - interval '2 hours'),
 (5,3,6,2,NULL,'O parágrafo 14 usa linguagem não vinculante — isso está no próprio texto, não é interpretação minha.','fonte',31, now() - interval '1 hour'),
 (6,4,23,8,NULL,'Duas equipes reproduziram apenas parte do achado; vale registrar essa diferença.','dado',19, now() - interval '4 hours'),
 (7,6,NULL,1,NULL,'Estou tentando confirmar a alegação sobre remessas e não encontrei nada no documento oficial.','alegacao',7, now() - interval '50 minutes');

INSERT INTO replies (comment_id, user_id, content, type, likes, created_at) VALUES
 (1,6,'Confirmo: a etapa 2 começa depois da publicação do decreto, que ainda não saiu.','fonte',6, now() - interval '25 minutes'),
 (2,3,'Pelo anexo, contratos assinados depois da vigência entram na regra. Antes, não.','fonte',9, now() - interval '18 minutes'),
 (5,4,'Agradeço por citar o parágrafo — dá para conferir sem depender de resumo.','opiniao',5, now() - interval '40 minutes');

-- --------------------------------------------------------------- estados
INSERT INTO saved_items (user_id, item_type, item_id, created_at) VALUES
 (4,'noticia',1, now() - interval '30 minutes'),
 (4,'fato',1, now() - interval '25 minutes'),
 (4,'acontecimento',1, now() - interval '20 minutes'),
 (5,'discussao',3, now() - interval '2 hours'),
 (6,'noticia',16, now() - interval '1 hour');

INSERT INTO notifications (user_id, type, title, content, read, created_at) VALUES
 (4,'atualizacao','FATО #000184 foi atualizado','Nova informação encontrada: ata parcialmente redigida localizada. Versão 3 publicada.', false, now() - interval '3 hours'),
 (4,'acontecimento','Nova cobertura no acontecimento que você acompanha','27 fontes relacionadas ao acontecimento “Nova medida econômica anunciada pelo governo”.', false, now() - interval '5 hours'),
 (4,'resposta','Rafael Tavares respondeu ao seu comentário','“Confirmo: a etapa 2 começa depois da publicação do decreto...”', true, now() - interval '24 minutes'),
 (4,'mencao','Você foi citado na Praça Global','Bruno Sato citou sua fonte na discussão sobre regulação de IA.', false, now() - interval '2 hours'),
 (5,'relevante','Investigação que você salvou mudou','FATО #000191 teve a seção O QUE ESTÁ CONFIRMADO revisada.', false, now() - interval '8 hours');

INSERT INTO reports (user_id, target_type, target_id, reason, detail, status, created_at) VALUES
 (5,'comentario',7,'alegacao_sem_fonte','Alegação sobre remessas sem documento de apoio.','em_revisao', now() - interval '40 minutes'),
 (4,'comentario',3,'divergencia_de_opiniao','Apenas discordo do conteúdo; não há violação aparente.','rejeitada', now() - interval '3 hours'),
 (6,'usuario',7,'flood','Mesma mensagem repetida em três discussões.','aberta', now() - interval '1 hour');

INSERT INTO collection_runs (adapter, status, fetched, grouped, published, message, created_at) VALUES
 ('gdelt','ok',412,58,31,'Descoberta via GDELT: usado para localizar cobertura, não como prova de veracidade.', now() - interval '10 minutes'),
 ('newsapi','ok',260,34,22,'Normalização de metadados concluída.', now() - interval '40 minutes'),
 ('rss','ok',180,12,9,'12 feeds atualizados.', now() - interval '1 hora'),
 ('rss','erro',0,0,0,'Feed indisponível: timeout após 8s (fonte 9). Retentativa em 5 minutos.', now() - interval '55 minutes'),
 ('oficial','ok',46,6,6,'Fontes oficiais consultadas: 6 documentos novos.', now() - interval '20 minutes');

SELECT setval('users_id_seq', 100);
SELECT setval('sources_id_seq', 100);
SELECT setval('events_id_seq', 100);
SELECT setval('articles_id_seq', 100);
SELECT setval('investigations_id_seq', 100);
SELECT setval('comments_id_seq', 100);
SELECT setval('replies_id_seq', 100);
SELECT setval('discussions_id_seq', 100);
SELECT setval('reports_id_seq', 100);
SELECT setval('notifications_id_seq', 100);
